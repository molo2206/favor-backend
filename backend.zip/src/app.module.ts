import { MiddlewareConsumer, Module, RequestMethod } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CurrentUserMiddleware } from './users/utility/middlewares/current-user.middleware';
import { TypeOrmModule } from '@nestjs/typeorm';
import { dataSourceOptions } from 'db/data-source';
import { UsersModule } from './users/users.module';
import { VehicleTechnicalControlModule } from './vehicle-technical-control/vehicle-technical-control.module';
import { OrganizationVehicleRentalModule } from './organization-vehicle-rental/organization-vehicle-rental.module';
import { OtpModule } from './otp/otp.module';
import { CompanyModule } from './company/company.module';
import { UserHasCompanyModule } from './user_has_company/user_has_company.module';
import { TypeCompanyModule } from './type_company/type_company.module';
import { CategoryModule } from './category/category.module';
import { ProductModule } from './products/products.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { DeliveryModule } from './delivery/delivery.module';
import { SignatureModule } from './signature/signature.module';
import { TrackingModule } from './tracking/tracking.module';
import { MailerModule } from '@nestjs-modules/mailer';
import { join } from 'path';
import { TravelReservationModule } from './travel_reservation/travel_reservation.module';
import { MeasureModule } from './measure/measure.module';
import { EventsModule } from './events/events.module';
import { AddressUserModule } from './address-user/address-user.module';
import { OrderModule } from './order/order.module';
import { OrderItemModule } from './order-item/order-item.module';
import { SubOrderModule } from './sub-order/sub-order.module';
import { SubOrderItemModule } from './sub-order-item/sub-order-item.module';
import { ServiceModule } from './service/service.module';
import { RoomImageModule } from './room-image/room-image.module';
import { RoomModule } from './room/room.module';
import { BookingModule } from './booking/booking.module';
import { TauxCompanyModule } from './taux-company/taux-company.module';
import { AppSettingModule } from './app-setting/app-setting.module';
import { UserPaymentMethodsModule } from './users/payment-methods/user-payment-methods.module';
import { RoleModule } from './users/role.module';
import { PlatformModule } from './users/platform.module';
import { UserPlatformRoleModule } from './users/user-platform-role.module';
import { SpecificationModule } from './specification/specification.module';
import { CategorySpecificationModule } from './specification/category-specification.module';
import { ProductSpecificationValueModule } from './specification/product-specification.module';
import { SmsHelper } from './users/utility/helpers/sms.helper';
import { AttributeModule } from './AttributGlobal/attribute.module';
import { OpenaiModule } from './open-ai/openai.module';
import { ResourceModule } from './ressource/resource.module';
import { BranchModule } from './branch/branch.module';
import { RoomAvailabilityModule } from './HotelRoomAvailability/hotelRoomAvailability.module';
import { BackupModule } from './backup/backup.module';
import { ColisModule } from './logistique/colis.module';
import { ShipmentModule } from './shipment/shipment.module';
import { LtaModule } from './shipment/Lta/lta.module';
import { PawapayModule } from './pawapay/pawapay.module';
import { OperationModule } from './operation/operation.module';
import { AuditModule } from './audit/audit.module';
import { UserSessionsModule } from './users/sessions/user-sessions.module';
import { WorkSchedulesModule } from './work-schedules/work-schedules.module';
import { EmployeeSignaturesModule } from './backOffice/hr/signatures/employee-signatures.module';
import { EmployeeDocumentsModule } from './backOffice/hr/employee-documents/employee-documents.module';
import { SystemSettingsModule } from './system-settings/system-settings.module';
import { StorageAdminModule } from './storage-admin/storage-admin.module';
import { ImageSearchModule } from './products/image-search/image-search.module';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AuditInterceptor } from './audit/interceptor/audit.interceptor';
import { AuditContextMiddleware } from './audit/context/audit-context.middleware';
import { HttpModule } from '@nestjs/axios';
import { CacheModule } from '@nestjs/cache-manager';
import * as redisStore from 'cache-manager-redis-store';
import { GoogleModule } from './Course et Taxi/google-maps/google-maps.module';
import { ProxyBlockModule } from './common/security/proxy-block/proxy-block.module';
import { ProxyBlockMiddleware } from './common/security/proxy-block/proxy-block.middleware';
import { ServiceZonesModule } from './Course et Taxi/ServiceZone/service-zones.module';
import { DriverVehicleModule } from './Course et Taxi/DriverVehicle/driver-vehicle.module';
import { PricingModule } from './Course et Taxi/Pricing/pricing.module';
import { DriverLocationModule } from './Course et Taxi/DriverLocation/driver-location.module';
import { RideModule } from './Course et Taxi/Ride/ride.module';
import { CompanyDashboardModule } from './company-dashboard/company-dashboard.module'; // ✅ dashboard par type d'entreprise
import { DriverCashoutModule } from './Course et Taxi/DriverCashout/driver-cashout.module';
import { DriverAssociationModule } from './Course et Taxi/DriverAssociation/driver-association.module';
import { RideChatModule } from './Course et Taxi/RideChat/ride-chat.module';
import { ImageModule } from './imagesTraitement/images.module';
import { FilesModule } from './files/files.module';
import { NotificationsModule } from './notification/notifications.module';
import { DeviceToken } from './firebase/entities/device-token.entity';
import { UserNotification } from './firebase/entities/user-notification.entity';
import { FcmService } from './notification/fcm.service';
import { VehiclesModule } from './voyage/vehicles/vehicles.module';
import { TripsModule } from './voyage/trips/trips.module';
import { SeatsModule } from './voyage/seats/seats.module';
import { BaggageModule } from './voyage/baggage/baggage.module';
import { BaggageRulesModule } from './voyage/baggage-rules/baggage-rules.module';
import { ReservationsVehiclesModule } from './voyage/reservations-vehicles/reservations-vehicles.module';
import { PaymentResTravelModule } from './voyage/payment_res_travel/payment_res_travel.module';
import { CompanyHasResourceModule } from './company_has_usrResource/company_has_resource.module';
import { FilesService } from './files/files.service';
import { CommonModule } from './libs/common/src/common.module';
import { CompanyTariffModule } from './company_tariff/company-tariff.module';
// ✅ Module indépendant : tarifs de ramassage de colis (paliers dynamiques par pays/ville)
import { PickupTariffModule } from './pickup-tariff/pickup-tariff.module';
import { PushNotificationCronModule } from './cron/push-notification-cron.module';
import { CronModule } from './cron/cron.module';
import { MealsModule } from './voyage/meal/meals.module';
import { ScheduleModule } from '@nestjs/schedule';
import { I18nModule } from './libs/common/src';
import { FpayModule } from './fpay/fpay.module';
import { ExchangeRateModule } from './Exchange/exchange-rate.module';
import { ServiceClientModule } from './backOffice/service-client/service-client.module';
import { HrModule } from './backOffice/hr/hr.module';
import { CommercialModule } from './backOffice/commercial/commercial.module';
import { SmsModule } from './users/utility/sms/sms.module';
import { AgentPaymentsModule } from './backOffice/hr/payment/agent-payments.module';
import { ChatModule } from './backOffice/chat/chat.module';
import { SupplyModule } from './supply/supply.module';
import { BranchStockModule } from './branch-stock/branch-stock.module';
import { LogisticsModule } from './backOffice/logistics/logistics.module';
import { MediaModule } from './backOffice/media/media.module';
import { FinanceModule } from './backOffice/finance/finance.module';
import { NeedsModule } from './backOffice/needs/needs.module';
// ✅ AJOUT : annonces type Jiji (publication payante, tarifs par ville)
import { ClassifiedsModule } from './classifieds/classifieds.module';
import { VehicleRegistrationModule } from './vehicle-registration/vehicle-registration.module';
// import { WhatsAppModule } from './users/utility/helpers/whatsapp.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      // ✅ Le .env est déjà chargé par le préchargement des paramètres (main.ts) : ConfigService lit process.env,
      //    donc les valeurs de la table system_settings sont aussi visibles par config.get('X')
      ignoreEnvFile: true,
    }),
    ScheduleModule.forRoot(),
    TypeOrmModule.forRoot({
      ...dataSourceOptions,
      // ✅ Requêtes lentes signalées dans les logs (DB_SLOW_QUERY_MS, 1000 ms par défaut)
      maxQueryExecutionTime: Number(process.env.DB_SLOW_QUERY_MS || 1000),
      extra: {
        charset: 'utf8mb4',
        // ✅ Connexions MySQL simultanées (10 par défaut chez mysql2) : plus de requêtes en parallèle
        connectionLimit: Number(process.env.DB_POOL_SIZE || 20),
        enableKeepAlive: true,
        keepAliveInitialDelay: 10000,
      },
    }),
    // Enregistrement des entités Firebase
    TypeOrmModule.forFeature([DeviceToken, UserNotification]),
    CacheModule.register({
      store: redisStore,
      host: 'localhost',
      port: 6379,
      ttl: 0,
      isGlobal: true,
    }),
    HttpModule,
    MailerModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        transport: {
          host: configService.get<string>('MAILER_HOST'),
          port: parseInt(configService.get<string>('MAILER_PORT') ?? '587', 10),
          secure: false,
          auth: {
            user: configService.get<string>('MAILER_USER'),
            pass: configService.get<string>('MAILER_PASS'),
          },
        },
        defaults: {
          from: `"FavorHelp" <favorhelp31@gmail.com>`,
        },
        template: {
          dir: join(__dirname, 'templates'),
          options: {
            strict: true,
          },
        },
      }),
    }),
    CommonModule,
    UsersModule,
    VehicleTechnicalControlModule,
    OrganizationVehicleRentalModule,
    TauxCompanyModule,
    OtpModule,
    CompanyModule,
    UserHasCompanyModule,
    TypeCompanyModule,
    CategoryModule,
    ProductModule,
    DeliveryModule,
    SignatureModule,
    TrackingModule,
    TravelReservationModule,
    MeasureModule,
    EventsModule,
    AddressUserModule,
    OrderModule,
    OrderItemModule,
    SubOrderModule,
    SubOrderItemModule,
    ServiceModule,
    RoomImageModule,
    RoomModule,
    BookingModule,
    TauxCompanyModule,
    AppSettingModule,
    UserPaymentMethodsModule, // ✅ moyens de paiement des utilisateurs (Mobile Money, FPay, Cash)
    RoleModule,
    PlatformModule,
    UserPlatformRoleModule,
    SpecificationModule,
    CategorySpecificationModule,
    ProductSpecificationValueModule,
    AttributeModule,
    OpenaiModule,
    ResourceModule,
    BranchModule,
    RoomAvailabilityModule,
    BackupModule,
    ColisModule,
    ShipmentModule,
    LtaModule,
    PawapayModule,
    OperationModule,
    AuditModule,
    UserSessionsModule, // ✅ Sessions de connexion
    WorkSchedulesModule, // ✅ Horaires et programmes de travail (contrôle d'accès)
    EmployeeSignaturesModule, // ✅ Signatures des employés (états de besoins…)
    EmployeeDocumentsModule, // ✅ Dossiers des employés (CV, pièces d'identité, diplômes…)
    SystemSettingsModule, // ✅ Paramètres système : clés du .env gérées en base
    StorageAdminModule, // ✅ Gestionnaire de fichiers, corbeille, orphelins, purge des rejetés
    ImageSearchModule, // ✅ Recherche par image (visuelle + IA)
    GoogleModule,
    ProxyBlockModule, // ✅ Filtre VPN / proxy / Tor (PROXY_BLOCK_MODE)
    ServiceZonesModule,
    DriverVehicleModule,
    DriverLocationModule,
    PricingModule,
    RideModule,
    CompanyDashboardModule,
    DriverCashoutModule, // ✅ retrait des gains des chauffeurs via F-Pay (taxi/driver/cashout)
    DriverAssociationModule, // ✅ chauffeurs privés / membres d'une association
    RideChatModule, // ✅ chat chauffeur ↔ client (texte + vocal) + historique admin
    ImageModule,
    FilesModule,
    NotificationsModule,
    VehiclesModule,
    TripsModule,
    ReservationsVehiclesModule,
    SeatsModule,
    BaggageModule,
    BaggageRulesModule,
    PaymentResTravelModule,
    CompanyHasResourceModule,
    CompanyTariffModule,
    PickupTariffModule,
    PushNotificationCronModule,
    CronModule,
    MealsModule,
    I18nModule,
    CommonModule,
    FpayModule,
    ExchangeRateModule,
    // WhatsAppModule
    CommercialModule,
    ServiceClientModule,
    HrModule,
    SmsModule,
    AgentPaymentsModule,
    // 💬 Chat back-office (WebSocket principal + FCM + FilesService + user_notifications)
    ChatModule,
    // Approvisionnement : stock des branches, Supply, logistique interne + charroi
    BranchStockModule,
    SupplyModule,
    LogisticsModule,
    // BackOffice — Média (filmage, photographie, services digitaux)
    MediaModule,
    FinanceModule, // ✅ BackOffice — Trésorerie (cash flow)
    NeedsModule, // ✅ BackOffice — États de besoins (validation hiérarchique, décaissement, exécution)
    ClassifiedsModule,
    VehicleRegistrationModule, // ✅ enregistrement des véhicules (propriétaire + commissionnaire)
  ],
  controllers: [AppController],
  exports: [FilesService],
  providers: [
    AppService,
    SmsHelper,
    FilesService,
    FcmService,
    {
      provide: APP_INTERCEPTOR,
      useClass: AuditInterceptor,
    },
  ],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    // ✅ Journal d'audit : identifiant de requête + contexte, en tout premier (écriture à la fin de chaque réponse)
    consumer
      .apply(AuditContextMiddleware)
      .forRoutes({ path: '*', method: RequestMethod.ALL });

    // ✅ Filtre VPN / proxy / Tor en premier (rien n'est bloqué tant que PROXY_BLOCK_MODE n'est pas « block »)
    consumer
      .apply(ProxyBlockMiddleware)
      .forRoutes({ path: '*', method: RequestMethod.ALL });

    consumer
      .apply(CurrentUserMiddleware)
      .forRoutes({ path: '*', method: RequestMethod.ALL });
  }
}
