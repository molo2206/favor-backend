﻿/* eslint-disable prefer-const */
import { ConfigService } from '@nestjs/config';
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  Injectable,
  BadRequestException,
  NotFoundException,
  InternalServerErrorException,
  Inject,
  forwardRef,
  ForbiddenException,
  Optional,
} from '@nestjs/common';
import { UserSessionsService } from './sessions/user-sessions.service';
import { WorkSchedulesService } from 'src/work-schedules/work-schedules.service';
import { SessionRevokeReason } from './sessions/user-session.entity';
import { currentAudit } from 'src/audit/context/audit-context';
import { InjectRepository } from '@nestjs/typeorm';
import { FindOptionsRelations, In, MoreThan, Repository, SelectQueryBuilder } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import { UserEntity } from './entities/user.entity';
import { OtpEntity } from 'src/otp/entities/otp.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { LoginUserDto } from './dto/login-user.dto';
import { validate } from 'class-validator';
import { instanceToPlain, plainToInstance } from 'class-transformer';
import { VerifyOtpDto } from 'src/otp/dto/verify-otp.dto';
import { ResetPasswordDto } from 'src/otp/dto/reset-password.dto';
import * as speakeasy from 'speakeasy';
import * as qrcode from 'qrcode';
import { UpdateUserDto } from './dto/update-profile';
import { UpdateEmailDto, UpdatePhoneDto } from './dto/update-contact.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { JwtService } from '@nestjs/jwt';
import { UserRole } from './enum/user-role-enum';
import { MailService } from 'src/email/email.service';
import { GoogleLoginDto } from './dto/googleLoginDto.dto';
import { SmsHelper } from './utility/helpers/sms.helper';
import validator from 'validator';
import { Resource } from 'src/ressource/entity/resource.entity';
import { UserHasResourceEntity } from './entities/user-has-resource.entity';
import { DeviceToken } from 'src/firebase/entities/device-token.entity';
import { CompanyEntity } from 'src/company/entities/company.entity';
import { FilesService } from 'src/files/files.service';
import { UserSettingsEntity } from './entities/user-settings.entity';
import { UpdateUserSettingsDto } from './dto/update-user-settings.dto';
import { I18nService } from 'src/libs/common/src';
import { LoyaltyTier, UserLoyaltyEntity } from './entities/user-loyalty.entity';
import { v4 as uuidv4 } from 'uuid';
import { ReferralEntity, ReferralStatus } from './entities/referral.entity';
import { OrderStatus } from 'src/order/enum/order.status.enum';
import { FpayService } from 'src/fpay/fpay.service';
import { PaginatedResponseDto } from 'src/products/dto/paginated-response.dto';
import { CreateUserByAdminDto } from './dto/create-user-by-admin.dto';
import { UpdateUserByAdminDto } from './dto/update-user-by-admin.dto';
import { Shipment } from 'src/shipment/entity/shipment.entity';
import { OrderEntity } from 'src/order/entities/order.entity';
import { SmsService } from './utility/sms/sms.service';
import { SmsCategory } from './utility/sms/entity/sms-recharge.entity';
import { SmsQuotaService } from './utility/sms/sms-quota.service';
import { isStoredFileUrl } from 'src/files/media-url.util';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(UserEntity)
    private readonly usersRepository: Repository<UserEntity>,
    @InjectRepository(OtpEntity)
    private readonly otpRepository: Repository<OtpEntity>,

    @InjectRepository(Shipment)
    private shipmentRepo: Repository<Shipment>,

    @InjectRepository(OrderEntity) private readonly orderRepo: Repository<OrderEntity>,

    @InjectRepository(Resource)
    private readonly resourcesRepository: Repository<Resource>,

    @InjectRepository(DeviceToken)
    private readonly deviceTokenRepo: Repository<DeviceToken>,

    @InjectRepository(ReferralEntity)
    private readonly referralRepository: Repository<ReferralEntity>,
    @InjectRepository(UserHasResourceEntity)
    private readonly userHasResourceRepository: Repository<UserHasResourceEntity>,
    @InjectRepository(CompanyEntity)
    private readonly companyRepository: Repository<CompanyEntity>,

    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly mailService: MailService,
    private readonly smsService: SmsService,
    private readonly smsHelper: SmsHelper,
    private readonly filesService: FilesService,

    @InjectRepository(UserSettingsEntity)
    private readonly settingsRepo: Repository<UserSettingsEntity>,



    @InjectRepository(UserLoyaltyEntity)
    private readonly loyaltyRepository: Repository<UserLoyaltyEntity>,



    private readonly i18n: I18nService,

    @Inject(forwardRef(() => FpayService))  // âœ… Utiliser forwardRef
    private readonly fpayService: FpayService,

    private readonly smsQuotaService: SmsQuotaService,

    // ✅ Sessions de connexion (module global)
    @Optional() private readonly sessions?: UserSessionsService,
    @Optional() private readonly workSchedules?: WorkSchedulesService,
  ) { }

  /**
   * ✅ Vérifie le quota SMS sans jamais bloquer le traitement métier.
   * Retourne true si un SMS peut être envoyé (quota OK),
   * false si le quota est épuisé OU en cas d'erreur technique.
   *
   * ⚠️ IMPORTANT : contrairement à l'ancienne version, un retour `false`
   * ne doit PAS faire échouer l'appelant. Il doit juste logger et continuer.
   */
  private async consumeSmsQuotas(
    referenceId: string | undefined,
    referenceType: string,
    // ✅ Numéro du destinataire : le quota de SON pays est décompté
    phone?: string | null,
  ): Promise<boolean> {
    try {
      const result = await this.smsQuotaService.tryConsume(SmsCategory.SERVICE_CLIENT, 1, phone);
      if (!result.allowed) {
        console.warn(
          `[ServiceClient] Quota SMS SERVICE_CLIENT épuisé (remaining: ${result.quotaBefore}) -> SMS non envoyé [${referenceType}]`,
        );
        return false;
      }
      console.log(
        `[ServiceClient] Quota décompté (avant: ${result.quotaBefore}, après: ${result.quotaAfter}) [${referenceType}]`,
      );
      return true;
    } catch (error: any) {
      // ⚠️ En cas d'erreur technique, on ne bloque pas non plus.
      console.error(`[ServiceClient] Erreur quota SMS:`, error.message);
      return false;
    }
  }

  /**
   * ✅ Idem pour AUTH : ne bloque jamais le traitement métier.
   */
  private async consumeSmsQuota(
    referenceId: string | undefined,
    referenceType: string,
    // ✅ Numéro du destinataire : le quota de SON pays est décompté
    phone?: string | null,
  ): Promise<boolean> {
    try {
      const result = await this.smsQuotaService.tryConsume(SmsCategory.AUTH, 1, phone);
      if (!result.allowed) {
        console.warn(
          `[Auth] Quota SMS AUTH épuisé (remaining: ${result.quotaBefore}) -> SMS non envoyé [${referenceType}]`,
        );
        return false;
      }
      console.log(
        `[Auth] Quota décompté (avant: ${result.quotaBefore}, après: ${result.quotaAfter}) [${referenceType}]`,
      );
      return true;
    } catch (error: any) {
      console.error(`[Auth] Erreur quota SMS:`, error.message);
      return false;
    }
  }

  /**
   * ✅ Helper : envoi SMS sécurisé.
   * - Vérifie le quota
   * - Envoie si OK
   * - Ne throw JAMAIS
   * - Retourne true si le SMS est parti, false sinon
   */
  private async safeSendAuthSms(
    phone: string,
    message: string,
    referenceType: string,
  ): Promise<boolean> {
    try {
      const allowed = await this.consumeSmsQuota(undefined, referenceType, phone);
      if (!allowed) {
        console.warn(`[Auth] SMS non envoyé (quota épuisé) [${referenceType}] -> ${phone}`);
        return false;
      }
      const sent = await this.smsService.sendSms(phone, message);
      if (!sent) {
        console.warn(`[Auth] SMS échec d'envoi [${referenceType}] -> ${phone}`);
        return false;
      }
      return true;
    } catch (error: any) {
      console.error(`[Auth] safeSendAuthSms error [${referenceType}]:`, error?.message);
      return false;
    }
  }

  private async applyActiveCompanyByPlatform(
    user: any,
    platform?: string,
  ): Promise<void> {
    // ============================================================
    // 0. Aucune company du tout → vider activeCompany
    // ============================================================
    if (!user?.userHasCompany || user.userHasCompany.length === 0) {
      if (user.activeCompanyId || user.activeBranchId) {
        user.activeCompanyId = null;
        user.activeBranchId = null;
        await this.usersRepository.save(user);
      }
      return;
    }

    // ============================================================
    // 1. admin → FavorHelp | group → FavorGroup
    // ============================================================
    if (platform === 'admin' || platform === 'group') {
      const expectedPlatform = platform === 'admin' ? 'FavorHelp' : 'FavorGroup';

      // 1️⃣ Priorité 1 : company isMain=true avec le bon typePlatform VALIDATED
      const mainUhc = user.userHasCompany.find(
        (u: any) =>
          u.company?.typePlatform === expectedPlatform &&
          u.company?.status === 'VALIDATED' &&
          u.company?.isMain === true,
      );

      // 2️⃣ Priorité 2 : 1ère company avec le bon typePlatform VALIDATED
      const matchingUhc =
        mainUhc ??
        user.userHasCompany.find(
          (u: any) =>
            u.company?.typePlatform === expectedPlatform &&
            u.company?.status === 'VALIDATED',
        );

      // 3️⃣ FALLBACK : aucune company sur la plateforme demandée
      //    → prendre la 1ère company VALIDATED disponible (autre plateforme)
      const fallbackUhc =
        user.userHasCompany.find((u: any) => u.company?.status === 'VALIDATED');

      // 4️⃣ Sélection finale
      const targetCompany =
        matchingUhc?.company ?? fallbackUhc?.company ?? null;

      // Si même le fallback échoue (aucune company VALIDATED) → vider
      if (!targetCompany) {
        if (user.activeCompanyId || user.activeBranchId) {
          console.warn(
            `[applyActiveCompanyByPlatform] Aucune company VALIDATED pour user ${user.id} → activeCompany vidée`,
          );
          user.activeCompanyId = null;
          user.activeBranchId = null;
          await this.usersRepository.save(user);
        }
        return;
      }

      // 5️⃣ Appliquer la company cible
      if (user.activeCompanyId !== targetCompany.id) {
        user.activeCompanyId = targetCompany.id;

        if (
          targetCompany.branches?.length > 0 &&
          !targetCompany.branches.some((b: any) => b.id === user.activeBranchId)
        ) {
          user.activeBranchId = targetCompany.branches[0].id;
        }

        await this.usersRepository.save(user);
      } else if (
        // Si activeCompanyId est bon mais activeBranchId pas cohérent
        targetCompany.branches?.length > 0 &&
        !targetCompany.branches.some((b: any) => b.id === user.activeBranchId)
      ) {
        user.activeBranchId = targetCompany.branches[0].id;
        await this.usersRepository.save(user);
      }

      return;
    }

    // ============================================================
    // 2. ios / android / web (ou aucune platform)
    //    → Garde l'activeCompany actuelle OU prend la 1ère
    // ============================================================
    if (!user.activeCompanyId) {
      const firstCompany = user.userHasCompany[0].company;
      if (firstCompany) {
        user.activeCompanyId = firstCompany.id;
        if (firstCompany.branches?.length > 0 && !user.activeBranchId) {
          user.activeBranchId = firstCompany.branches[0].id;
        }
        await this.usersRepository.save(user);
      }
    }
  }
  private async generateReferralCode(
    userId: string,
    existingCodes?: string[],
  ): Promise<string> {
    const userIdShort = userId.substring(0, 4).toUpperCase();

    let code: string;
    let exists = true;
    let attempts = 0;
    const maxAttempts = 10;

    // ✅ Liste des codes déjà connus (fournie par l'appelant)
    const codesToCheck = new Set(existingCodes || []);

    do {
      const random = Math.random()
        .toString(36)
        .substring(2, 8)
        .toUpperCase()
        .padStart(6, '0');

      code = `${userIdShort}${random}`;

      // ✅ Vérif rapide locale d'abord (Set O(1) au lieu de Array.includes)
      if (codesToCheck.has(code)) {
        attempts++;
        continue;
      }

      // ✅ Vérif DB uniquement si pas dans la liste locale
      const existingUser = await this.usersRepository.findOne({
        where: { referralCode: code },
        select: ['id'],   // ✅ AJOUT : ne récupère que l'id (plus rapide)
      });

      exists = !!existingUser;
      attempts++;

    } while (exists && attempts < maxAttempts);

    // ✅ Fallback si collision après 10 tentatives
    if (exists) {
      const timestamp = Date.now().toString(36).toUpperCase();
      const randomSuffix = Math.random()
        .toString(36)
        .substring(2, 4)
        .toUpperCase();
      code = `${timestamp.slice(-6)}${randomSuffix}`;

      const existingUser = await this.usersRepository.findOne({
        where: { referralCode: code },
        select: ['id'],
      });

      if (existingUser) {
        const uuidPart = uuidv4().substring(0, 8).toUpperCase();
        code = `${uuidPart}`;
      }
    }

    return code;
  }

  private async getOrCreateLoyaltyAccount(userId: string): Promise<UserLoyaltyEntity> {
    // ✅ 1. VÉRIFIER SI ÇA EXISTE
    const existingLoyalty = await this.loyaltyRepository.findOne({
      where: { userId },
    });

    // ✅ 2. SI EXISTE → NE PAS CRÉER, RETOURNER
    if (existingLoyalty) {
      return existingLoyalty;
    }

    // ✅ 3. SINON → GÉNÉRER UN CODE UNIQUE ET CRÉER
    let code: string;
    let exists: UserLoyaltyEntity | null = null;
    let attempts = 0;
    const maxAttempts = 10;

    do {
      code = Math.floor(10000000 + Math.random() * 90000000).toString();
      exists = await this.loyaltyRepository.findOne({
        where: { loyaltyCode: code },
        select: ['id'],   // ✅ AJOUT : ne récupère que l'id
      });
      attempts++;
    } while (exists && attempts < maxAttempts);

    if (exists) {
      code = Date.now().toString().slice(-8);
    }

    const loyalty = this.loyaltyRepository.create({
      userId,
      loyaltyCode: code,
      pointsBalance: 0,
      pointsTotalEarned: 0,
      pointsTotalSpent: 0,
      currentTier: LoyaltyTier.BRONZE,
      isActive: true,
    });

    try {
      return await this.loyaltyRepository.save(loyalty);
    } catch (error: any) {
      // âœ… 4. Si erreur de doublon (concurrence) â†’ retourner l'existant
      if (error.code === 'ER_DUP_ENTRY' || error.message?.includes('Duplicate')) {
        const existing = await this.loyaltyRepository.findOne({
          where: { userId },
        });
        if (existing) return existing;
      }
      throw error;
    }
  }

  async changePassword(
    userId: string,
    changePasswordDto: ChangePasswordDto,
    lang: string = 'fr',
  ): Promise<{ message: string }> {
    const { currentPassword, newPassword } = changePasswordDto;
    const user = await this.usersRepository.findOne({
      where: { id: userId },
      select: ['id', 'password'],
    });

    if (!user) {
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );
    }

    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      throw new BadRequestException(
        await this.i18n.translate('user.current_password_incorrect', lang),
      );
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedNewPassword;
    await this.usersRepository.save(user);

    // ✅ Sécurité : les autres appareils sont déconnectés (la session actuelle reste ouverte)
    await this.sessions?.revokeAllForUser(user.id, SessionRevokeReason.PASSWORD_CHANGED, {
      exceptSid: currentAudit()?.sessionId ?? null,
      byId: user.id,
    });

    return {
      message: await this.i18n.translate('user.password_updated', lang),
    };
  }

  async signup(
    createUserDto: CreateUserDto & { platform?: string },
    lang: string = 'fr',
  ): Promise<{
    message: string;
    data: Omit<UserEntity, 'password'> | { email?: string; phone?: string };
    access_token: string | null;
    refresh_token: string | null;
    fcmToken?: string;
    platform?: string;
  }> {
    const {
      email,
      phone,
      otpCode,
      password,
      fcmToken: clientFcmToken,
      platform,
      referralCode,
    } = createUserDto;

    const hasEmail = email && email !== '';
    const hasPhone = phone && phone !== '';

    if (!hasEmail && !hasPhone) {
      throw new BadRequestException(
        await this.i18n.translate('user.email_or_phone_required', lang),
      );
    }

    if (hasEmail && !validator.isEmail(email)) {
      throw new BadRequestException(
        await this.i18n.translate('user.valid_email', lang),
      );
    }

    if (hasPhone && !validator.isMobilePhone(phone, 'any')) {
      throw new BadRequestException(
        await this.i18n.translate('user.valid_phone', lang),
      );
    }

    const destination = email || phone;
    if (!destination) {
      throw new BadRequestException(
        await this.i18n.translate('user.email_or_phone_required', lang),
      );
    }

    // ============================================================
    // ✅ VÉRIFICATION DU CODE DE PARRAINAGE
    // ============================================================
    let referrer: UserEntity | null = null;

    if (referralCode) {
      referrer = await this.usersRepository.findOne({
        where: { referralCode },
      });

      if (!referrer) {
        throw new BadRequestException(
          await this.i18n.translate('referral.invalid_code', lang)
        );
      }

      if (!referrer.isActive || referrer.deleted) {
        throw new BadRequestException(
          await this.i18n.translate('referral.referrer_inactive', lang)
        );
      }

      if (email && referrer.email === email) {
        throw new BadRequestException(
          await this.i18n.translate('referral.self_referral_not_allowed', lang)
        );
      }

      if (phone && referrer.phone === phone) {
        throw new BadRequestException(
          await this.i18n.translate('referral.self_referral_not_allowed', lang)
        );
      }
    }

    // ============================================================
    // 1️⃣ Vérification doublons
    // ✅ OPTIMISATION : select uniquement id (plus rapide)
    // ============================================================
    const userExists = await this.usersRepository.findOne({
      where: [{ email: email || undefined }, { phone: phone || undefined }],
      select: ['id'],
    });

    if (userExists) {
      throw new BadRequestException(
        await this.i18n.translate('user.account_exists', lang),
      );
    }

    // ============================================================
    // 2️⃣ Envoi OTP si non fourni
    // ============================================================
    if (!otpCode) {
      const generatedOtpCode = Math.floor(
        1000 + Math.random() * 9000,
      ).toString();
      const otp = this.otpRepository.create({
        email: destination,
        otpCode: generatedOtpCode,
        expiresAt: new Date(Date.now() + 10 * 60 * 1000),
      });
      await this.otpRepository.save(otp);

      // ✅ Le même code est envoyé PARTOUT : par e-mail ET par SMS quand les deux sont renseignés
      let emailSent = false;
      let smsSent = false;
      let emailError: any = null;

      if (hasEmail) {
        try {
          const translations = {
            title: await this.i18n.translate('email.otp.title', lang),
            description: await this.i18n.translate('email.otp.description', lang),
            label: await this.i18n.translate('email.otp.label', lang),
            expiry: await this.i18n.translate('email.otp.expiry', lang),
            footerCopyright: await this.i18n.translate('email.otp.footerCopyright', lang),
            footerSecurity: await this.i18n.translate('email.otp.footerSecurity', lang),
            legalNote: await this.i18n.translate('email.otp.legalNote', lang),
          };
          await this.mailService.sendHtmlEmail(
            email as string,
            await this.i18n.translate('user.otp_code_subject', lang),
            'sendOtp.html',
            {
              otpCode: generatedOtpCode,
              year: new Date().getFullYear(),
              lang: lang,
              translations: translations,
            },
          );
          emailSent = true;
        } catch (err: any) {
          emailError = err;
          console.error('❌ [signup] OTP e-mail error:', err?.message);
        }
      }

      if (hasPhone) {
        const smsMessage = await this.i18n.translate('user.otp_sms_body', lang, {
          otpCode: generatedOtpCode,
        });
        // ✅ Best effort : on tente, mais on ne bloque JAMAIS l'inscription
        smsSent = await this.safeSendAuthSms(phone as string, smsMessage, 'SIGNUP_OTP');
      }

      // Aucun canal n'a fonctionné et l'e-mail a échoué : on remonte l'erreur (comme avant)
      if (emailError && !smsSent) throw emailError;

      return {
        message:
          emailSent && smsSent
            ? await this.i18n.translate('user.otp_sent_email_sms', lang)
            : emailSent
              ? await this.i18n.translate('user.otp_sent_email', lang)
              : await this.i18n.translate('user.otp_sent_sms', lang),
        data: { ...(email ? { email } : {}), ...(phone ? { phone } : {}) },
        access_token: null,
        refresh_token: null,
      };
    }

    // ============================================================
    // 3️⃣ Vérification OTP
    // ✅ OPTIMISATION : select uniquement les champs utiles
    // ============================================================
    const otpEntry = await this.otpRepository.findOne({
      where: { email: destination, otpCode, isUsed: false },
    });
    if (!otpEntry || new Date() > otpEntry.expiresAt) {
      throw new BadRequestException(
        await this.i18n.translate('user.invalid_otp', lang),
      );
    }

    // ============================================================
    // 4️⃣ CRÉATION UTILISATEUR
    // ✅ OPTIMISATION : un seul save (avec referralCode généré avant)
    // ============================================================
    const hashedPassword = password
      ? await bcrypt.hash(password, 10)
      : undefined;

    const newUser = this.usersRepository.create({
      fullName: createUserDto.fullName,
      email: email || undefined,
      phone: phone || undefined,
      password: hashedPassword,
      role: UserRole.CUSTOMER,
      isActive: true,
      provider: 'otp',
      country: createUserDto.country,
      city: createUserDto.city,
      fcmToken: clientFcmToken,
    });

    const savedUser = await this.usersRepository.save(newUser);

    // ============================================================
    // 🔥 GÉNÉRATION DU CODE DE PARRAINAGE
    // ✅ OPTIMISATION : 1 seul save (au lieu de 2)
    // ============================================================
    const referralCodeGenerated = await this.generateReferralCode(savedUser.id);
    savedUser.referralCode = referralCodeGenerated;

    // ============================================================
    // ✅ TRAITEMENT DU PARRAINAGE
    // ============================================================
    if (referralCode && referrer) {
      if (referrer.id === savedUser.id) {
        throw new BadRequestException(
          await this.i18n.translate('referral.self_referral_not_allowed', lang)
        );
      }

      referrer.referralCount = (referrer.referralCount || 0) + 1;
      referrer.lastReferralDate = new Date();

      savedUser.referredBy = referrer.id;
    }

    await this.usersRepository.save(savedUser);

    if (referralCode && referrer) {
      await this.usersRepository.save(referrer);

      const referral = this.referralRepository.create({
        referrerId: referrer.id,
        referredId: savedUser.id,
        referralCode: referralCode,
        status: ReferralStatus.COMPLETED,
        rewardAmount: 0,
        rewardType: 'POINTS',
        completedAt: new Date(),
      });
      await this.referralRepository.save(referral);
    }

    // ============================================================
    // 5️⃣ CRÉATION DU COMPTE FIDÉLITÉ
    // ============================================================
    const loyalty = await this.getOrCreateLoyaltyAccount(savedUser.id);
    await this.loyaltyRepository.save(loyalty);

    // ============================================================
    // 6️⃣ GESTION DU FCM TOKEN
    // ============================================================
    let savedFcmToken: string | undefined;
    if (clientFcmToken && platform) {
      const existingToken = await this.deviceTokenRepo.findOne({
        where: { token: clientFcmToken },
        select: ['id'],
      });

      if (existingToken) {
        await this.deviceTokenRepo.update(
          { token: clientFcmToken },
          {
            userId: savedUser.id,
            platform,
            updatedAt: new Date(),
          },
        );
      } else {
        const newToken = this.deviceTokenRepo.create({
          token: clientFcmToken,
          userId: savedUser.id,
          platform,
        });
        await this.deviceTokenRepo.save(newToken);
        savedFcmToken = newToken.token;
      }
    }

    // ============================================================
    // 7️⃣ MARQUER L'OTP COMME UTILISÉ
    // ============================================================
    otpEntry.isUsed = true;
    otpEntry.user = savedUser;
    await this.otpRepository.save(otpEntry);

    // ============================================================
    // 8️⃣ RECHARGER L'UTILISATEUR AVEC SES RELATIONS
    // ============================================================
    const userFull = await this.usersRepository.findOne({
      where: { id: savedUser.id },
      relations: [
        'activeCompany',
        'activeCompany.country',
        'activeCompany.city',
        'userHasCompany',
        'userHasCompany.company',
        'userHasCompany.company.tauxCompanies',
        'userPlatformRoles',
        'userPlatformRoles.platform',
        'userPlatformRoles.role',
        'loyalty',
      ],
    });
    if (!userFull)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    const { password: _pw, ...userWithoutPassword } = userFull;

    // ============================================================
    // 9️⃣ ENVOI EMAIL DE BIENVENUE
    // ============================================================
    if (email && email !== '' && validator.isEmail(email)) {
      const userData = {
        fullName:
          userWithoutPassword.fullName ||
          userWithoutPassword.email ||
          'Utilisateur',
        email: userWithoutPassword.email || 'Non renseigné',
        phone: userWithoutPassword.phone || 'Non renseigné',
        role: userWithoutPassword.role || 'Client',
        referralCode: savedUser.referralCode,
        createdAt: userWithoutPassword.createdAt
          ? new Date(
            typeof userWithoutPassword.createdAt === 'string'
              ? userWithoutPassword.createdAt
              : (userWithoutPassword.createdAt as any).toDate?.() ||
              userWithoutPassword.createdAt,
          ).toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
          })
          : "Aujourd'hui",
      };

      (async () => {
        try {
          const emailTranslations = {
            welcome_title: await this.i18n.translate('user.welcome_title', lang),
            welcome_subtitle: await this.i18n.translate('user.welcome_subtitle', lang),
            account_created: await this.i18n.translate('user.account_created', lang),
            email_label: await this.i18n.translate('user.email_label', lang),
            phone_label: await this.i18n.translate('user.phone_label', lang),
            role_label: await this.i18n.translate('user.role_label', lang),
            date_label: await this.i18n.translate('user.date_label', lang),
            discover_platform: await this.i18n.translate('user.discover_platform', lang),
            contact_whatsapp: await this.i18n.translate('user.contact_whatsapp', lang),
            need_help: await this.i18n.translate('user.need_help', lang),
            contact_us: await this.i18n.translate('user.contact_us', lang),
            footer_copyright: await this.i18n.translate('user.footer_copyright', lang),
            footer_legal: await this.i18n.translate('user.footer_legal', lang),
            referral_code_title: await this.i18n.translate('referral.referral_code_title', lang),
            share_referral: await this.i18n.translate('referral.share_referral', lang),
          };

          await this.mailService.sendHtmlEmail(
            email,
            await this.i18n.translate('user.welcome_subject', lang),
            'createCount.html',
            {
              user: userData,
              appUrl: process.env.APP_URL || 'https://favorhelp.com',
              year: new Date().getFullYear(),
              translations: emailTranslations,
              lang: lang,
            },
          );
        } catch (err: any) {
          console.error('❌ [signup] Welcome email error:', err.message);
        }
      })();
    }

    // ============================================================
    // 9️⃣ bis SMS DE BIENVENUE (téléphone renseigné) — en plus de l'e-mail
    // ============================================================
    if (hasPhone) {
      (async () => {
        try {
          const welcomeSms = await this.i18n.translate('user.welcome_sms_body', lang, {
            name: userWithoutPassword.fullName || '',
            referralCode: savedUser.referralCode || '',
          });
          await this.safeSendAuthSms(phone as string, welcomeSms, 'SIGNUP_WELCOME');
        } catch (err: any) {
          console.error('❌ [signup] Welcome SMS error:', err?.message);
        }
      })();
    }

    // ============================================================
    // 🔟 GÉNÉRATION DES TOKENS
    // ============================================================
    const [access_token, refresh_token] = await Promise.all([
      this.accessToken(savedUser),
      this.refreshToken(savedUser),
    ]);

    return {
      message: await this.i18n.translate('user.signup_success', lang),
      data: {
        ...userWithoutPassword,
        referralCode: savedUser.referralCode,
      },
      access_token,
      refresh_token,
      fcmToken: savedFcmToken,
      platform,
    };
  }
  async signin(
    userSignInDto: LoginUserDto & { platform?: string },
    lang: string = 'fr',
  ): Promise<any> {
    console.log('🔍 Langue reçue dans signin :', lang);
    const { fcmToken, platform } = userSignInDto;

    // ============================================================
    // ⏱️ TIMERS DEBUG (à retirer en prod si nécessaire)
    // ============================================================
    console.time('⏱️ signin TOTAL');
    console.time('⏱️ 1. query user');

    let user = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('company.settings', 'companySettings')
      .leftJoinAndSelect('company.invoiceConfiguration', 'invoiceConfiguration')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('defaultAddress.country', 'defaultAddressCountry')
      .leftJoinAndSelect('defaultAddress.city', 'defaultAddressCity')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.activeBranch', 'activeBranch')
      .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
      .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
      .leftJoinAndSelect('users.loyalty', 'loyalty')
      .leftJoinAndSelect('users.referrals', 'referrals')
      .leftJoinAndSelect('users.referrer', 'referrer')
      .where('users.email = :login OR users.phone = :login', {
        login: userSignInDto.email,
      })
      .getOne();

    console.timeEnd('⏱️ 1. query user');

    if (!user) {
      throw new BadRequestException(
        await this.i18n.translate('user.user_not_found', lang),
      );
    }

    if (user.deleted) {
      throw new BadRequestException(
        await this.i18n.translate('user.account_deleted', lang),
      );
    }

    console.time('⏱️ 2. bcrypt');
    const isPasswordValid = await bcrypt.compare(
      userSignInDto.password,
      user.password,
    );
    console.timeEnd('⏱️ 2. bcrypt');

    if (!isPasswordValid) {
      throw new BadRequestException(
        await this.i18n.translate('user.password_incorrect', lang),
      );
    }

    // ============================================================
    // 🔥 GARANTIR LE referralCode ET LE COMPTE FIDÉLITÉ
    // ============================================================
    console.time('⏱️ 3. referral + loyalty');

    if (!user.referralCode || user.referralCode.trim() === '') {
      console.warn(
        `⚠️ [signin] Utilisateur ${user.id} sans referralCode, génération...`,
      );

      const newCode = await this.generateReferralCode(user.id);

      if (!newCode || newCode.trim() === '') {
        console.error(
          `❌ [signin] Impossible de générer un referralCode pour ${user.id}`,
        );
        throw new InternalServerErrorException(
          await this.i18n.translate('user.referral_code_generation_failed', lang),
        );
      }

      user.referralCode = newCode;
      await this.usersRepository.save(user);
      console.log(`✅ [signin] referralCode généré: ${newCode}`);
    }

    if (!user.loyalty || user.loyalty.length === 0) {
      const loyalty = await this.getOrCreateLoyaltyAccount(user.id);
      await this.loyaltyRepository.save(loyalty);
      user.loyalty = [loyalty];
    }

    console.timeEnd('⏱️ 3. referral + loyalty');

    // ============================================================
    // ✅ SÉLECTION DE L'ENTREPRISE ACTIVE SELON x-platform
    //    admin → FavorHelp | group → FavorGroup
    // ============================================================
    await this.applyActiveCompanyByPlatform(user, platform);

    // ============================================================
    // ✅ JWT : parallélisation
    // ============================================================
    console.time('⏱️ 4. JWT');
    const [access_token, refresh_token] = await Promise.all([
      this.accessToken(user),
      this.refreshToken(user),
    ]);
    console.timeEnd('⏱️ 4. JWT');

    const { password, ...userWithoutPassword } = user;

    // ============================================================
    // ✅ FCM token : en ARRIÈRE-PLAN (non bloquant)
    // ============================================================
    if (fcmToken && platform) {
      this.deviceTokenRepo
        .findOne({ where: { token: fcmToken } })
        .then(async (existingToken): Promise<void> => {
          if (existingToken) {
            await this.deviceTokenRepo.update(
              { token: fcmToken },
              {
                userId: user.id,
                platform,
                updatedAt: new Date(),
              },
            );
            return;
          }

          await this.deviceTokenRepo.save(
            this.deviceTokenRepo.create({
              token: fcmToken,
              userId: user.id,
              platform,
            }),
          );
        })
        .catch((err) =>
          console.error('❌ [signin] FCM token save error:', err.message),
        );
    }
    const loyaltyPoints = user.loyalty?.[0]?.pointsBalance ?? 0;
    const loyaltyTier = user.loyalty?.[0]?.currentTier ?? null;
    const loyaltyCode = user.loyalty?.[0]?.loyaltyCode ?? null;

    console.time('⏱️ 5. build response');

    const userHasCompany =
      userWithoutPassword.userHasCompany?.map((uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,
        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,
            settings: (uhc.company as any).settings ?? null,
            invoiceConfiguration:
              (uhc.company as any).invoiceConfiguration ?? null,
          }
          : null,
        branch: uhc.branch
          ? {
            id: uhc.branch.id,
            name: uhc.branch.name,
          }
          : null,
        userResources:
          uhc.resources?.map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,
            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })) ?? [],
      })) ?? [];

    const activeUserHasCompany = user.userHasCompany?.find(
      (uhc) => uhc.company?.id === user.activeCompanyId,
    );
    const activeCompanyEntity = activeUserHasCompany?.company ?? null;

    const userResourcesForActiveCompany =
      activeUserHasCompany?.resources?.map((r) => ({
        id: r.id,
        canCreate: r.canCreate,
        canRead: r.canRead,
        canUpdate: r.canUpdate,
        canDelete: r.canDelete,
        canManage: r.canManage,
        status: r.status,
        resource: r.resource
          ? {
            id: r.resource.id,
            name: r.resource.name,
            label: r.resource.label,
          }
          : null,
      })) ?? [];

    const activeCompanyBranch = activeUserHasCompany?.branch
      ? {
        id: activeUserHasCompany.branch.id,
        name: activeUserHasCompany.branch.name,
      }
      : null;

    const activeCompany = activeCompanyEntity
      ? {
        ...activeCompanyEntity,
        tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
        country: activeCompanyEntity.country ?? null,
        city: activeCompanyEntity.city ?? null,
        category: activeCompanyEntity.category ?? null,
        settings: (activeCompanyEntity as any).settings ?? null,
        invoiceConfiguration:
          (activeCompanyEntity as any).invoiceConfiguration ?? null,
        branch: activeCompanyBranch,
        companyResources:
          activeCompanyEntity.companyResources?.map((r) => ({
            id: r.id,
            canCreate: r.can_create,
            canRead: r.can_read,
            canUpdate: r.can_update,
            canDelete: r.can_delete,
            canManage: r.can_manage,
            status: r.status,
            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })) ?? [],
        userResources: userResourcesForActiveCompany,
        branches: (activeCompanyEntity.branches ?? []).map((b) => ({
          id: b.id,
          name: b.name,
          address: b.address,
          phone: b.phone,
          email: b.email,
          status: b.status,
          deleted: b.deleted,
          country: b.country
            ? { id: b.country.id, name: b.country.name }
            : null,
          city: b.city ? { id: b.city.id, name: b.city.name } : null,
        })),
      }
      : null;

    const userPlatformRoles =
      userWithoutPassword.userPlatformRoles?.map((upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      })) ?? [];

    const referralData = {
      referralCode: user.referralCode,
      referralCount: user.referralCount || 0,
      referralPoints: user.referralPoints || 0,
      referredBy: user.referredBy,
      referrerName: user.referrer?.fullName || null,
      referralActive: user.referralActive !== false,
      totalReferrals: user.referrals?.length || 0,
    };

    console.timeEnd('⏱️ 5. build response');
    console.timeEnd('⏱️ signin TOTAL');

    return {
      message: await this.i18n.translate('user.login_success', lang),
      data: instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        activeCompany,
        userPlatformRoles,
        loyalty: {
          points: loyaltyPoints,
          tier: loyaltyTier,
          code: loyaltyCode,
        },
        referral: referralData,
      }),
      access_token,
      refresh_token,
      fcmToken,
    };
  }
  // ==================== GOOGLE LOGIN ====================
  async appleLogin(
    dto: {
      appleUserId: string;
      fullName?: string;
      email?: string;
      fcmToken?: string;
      platform?: string, // ✅ accepte tous les types
    },
    lang: string = 'fr',
  ): Promise<{
    message: string;
    data: any;
    access_token: string;
    refresh_token: string;
    fcmToken?: string;
  }> {
    const {
      appleUserId,
      fullName: rawFullName,
      email: rawEmail,
      fcmToken,
      platform,
    } = dto;
    if (!appleUserId)
      throw new BadRequestException(
        await this.i18n.translate('user.apple_user_id_required', lang),
      );
    const fullName = rawFullName?.trim() || 'Utilisateur Apple';
    const email = rawEmail?.trim() || undefined;

    let user = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('company.settings', 'companySettings')
      .leftJoinAndSelect('company.invoiceConfiguration', 'invoiceConfiguration')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.activeBranch', 'activeBranch')
      .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
      .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
      .leftJoinAndSelect('users.loyalty', 'loyalty')
      .leftJoinAndSelect('users.referrals', 'referrals')
      .leftJoinAndSelect('users.referrer', 'referrer')
      .where('users.appleUserId = :appleUserId', { appleUserId })
      .getOne();

    let isNewUser = false;

    if (!user && email) {
      const existingUserByEmail = await this.usersRepository.findOne({
        where: { email },
        select: ['id'],
      });
      if (existingUserByEmail) {
        throw new BadRequestException(
          await this.i18n.translate('user.email_already_exists', lang),
        );
      }
    }

    if (!user) {
      const newUser = this.usersRepository.create({
        appleUserId,
        fullName,
        email,
        provider: 'APPLE',
        role: UserRole.CUSTOMER,
        password: '',
        isActive: true,
      });
      user = await this.usersRepository.save(newUser);
      isNewUser = true;

      console.log(`🔍 [appleLogin] Nouvel utilisateur: ${user.id}, génération du referralCode...`);

      const referralCodeGenerated = await this.generateReferralCode(user.id);

      if (!referralCodeGenerated || referralCodeGenerated.trim() === '') {
        throw new InternalServerErrorException(
          await this.i18n.translate('user.referral_code_generation_failed', lang),
        );
      }

      user.referralCode = referralCodeGenerated;
      await this.usersRepository.save(user);
      console.log(`✅ [appleLogin] Nouveau user créé avec referralCode: ${referralCodeGenerated}`);

      const loyalty = await this.getOrCreateLoyaltyAccount(user.id);
      await this.loyaltyRepository.save(loyalty);
      user.loyalty = [loyalty];

      if (user.email) {
        const userEmail = user.email;
        const userSnapshot = { ...user };
        (async () => {
          try {
            await this.mailService.sendHtmlEmail(
              userEmail,
              await this.i18n.translate('user.welcome_subject', lang),
              'createCount.html',
              { userWithoutPassword: userSnapshot, year: new Date().getFullYear() },
            );
          } catch (err: any) {
            console.error('❌ [appleLogin] Welcome email error:', err.message);
          }
        })();
      }

      user = await this.usersRepository
        .createQueryBuilder('users')
        .addSelect('users.password')
        .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
        .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
        .leftJoinAndSelect('userHasCompany.company', 'company')
        .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
        .leftJoinAndSelect('company.country', 'country')
        .leftJoinAndSelect('company.city', 'city')
        .leftJoinAndSelect('company.category', 'category')
        .leftJoinAndSelect('company.companyResources', 'companyResources')
        .leftJoinAndSelect('companyResources.resource', 'resource')
        .leftJoinAndSelect('company.branches', 'branches')
        .leftJoinAndSelect('company.settings', 'companySettings')
        .leftJoinAndSelect('company.invoiceConfiguration', 'invoiceConfiguration')
        .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
        .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
        .leftJoinAndSelect('userPlatformRoles.role', 'role')
        .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
        .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
        .leftJoinAndSelect(
          'userCompanyResources.resource',
          'userCompanyResourceDetail',
        )
        .leftJoinAndSelect('users.activeBranch', 'activeBranch')
        .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
        .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
        .leftJoinAndSelect('users.loyalty', 'loyalty')
        .leftJoinAndSelect('users.referrals', 'referrals')
        .leftJoinAndSelect('users.referrer', 'referrer')
        .where('users.id = :id', { id: user.id })
        .getOne();
    } else {
      console.log(`🔍 [appleLogin] Utilisateur existant: ${user.id}`);

      if (user.provider !== 'APPLE') {
        throw new BadRequestException(
          await this.i18n.translate('user.apple_account_not_linked', lang, {
            provider: user.provider,
          }),
        );
      }

      let shouldUpdate = false;

      if (fullName && fullName !== user.fullName) {
        user.fullName = fullName;
        shouldUpdate = true;
      }

      if (email && email !== user.email) {
        const existingUserByEmail = await this.usersRepository.findOne({
          where: { email },
          select: ['id'],
        });
        if (existingUserByEmail && existingUserByEmail.id !== user.id) {
          throw new BadRequestException(
            await this.i18n.translate('user.email_already_exists', lang),
          );
        }
        user.email = email;
        shouldUpdate = true;
      }

      if (!user.referralCode || user.referralCode.trim() === '') {
        console.warn(`⚠️ [appleLogin] Utilisateur ${user.id} sans referralCode, génération...`);

        const newCode = await this.generateReferralCode(user.id);

        if (!newCode || newCode.trim() === '') {
          throw new InternalServerErrorException(
            await this.i18n.translate('user.referral_code_generation_failed', lang),
          );
        }

        user.referralCode = newCode;
        shouldUpdate = true;
        console.log(`✅ [appleLogin] referralCode généré: ${newCode}`);
      }

      if (!user.loyalty || user.loyalty.length === 0) {
        console.log(`⚠️ [appleLogin] Utilisateur ${user.id} sans loyalty, création...`);
        const loyalty = await this.getOrCreateLoyaltyAccount(user.id);
        await this.loyaltyRepository.save(loyalty);
        user.loyalty = [loyalty];
      }

      if (shouldUpdate) {
        await this.usersRepository.save(user);
      }
    }

    if (!user)
      throw new InternalServerErrorException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    // ✅ SÉLECTION DE L'ENTREPRISE ACTIVE SELON x-platform
    await this.applyActiveCompanyByPlatform(user, platform);

    if (fcmToken && platform) {
      const userId = user.id;
      (async () => {
        try {
          const existingToken = await this.deviceTokenRepo.findOne({
            where: { token: fcmToken },
            select: ['id'],
          });

          if (existingToken) {
            await this.deviceTokenRepo.update(
              { token: fcmToken },
              { userId, platform, updatedAt: new Date() },
            );
          } else {
            await this.deviceTokenRepo.save(
              this.deviceTokenRepo.create({
                token: fcmToken,
                userId,
                platform,
              }),
            );
          }
        } catch (err: any) {
          console.error('❌ [appleLogin] FCM token save error:', err.message);
        }
      })();
    }

    const [access_token, refresh_token] = await Promise.all([
      this.accessToken(user),
      this.refreshToken(user),
    ]);

    const { password, ...userWithoutPassword } = user;

    const userHasCompany =
      userWithoutPassword.userHasCompany?.map((uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,
        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,
            settings: (uhc.company as any).settings ?? null,
            invoiceConfiguration:
              (uhc.company as any).invoiceConfiguration ?? null,
            branches: (uhc.company.branches ?? []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,
              country: b.country
                ? { id: b.country.id, name: b.country.name }
                : null,
              city: b.city ? { id: b.city.id, name: b.city.name } : null,
            })),
          }
          : null,
        branch: uhc.branch
          ? { id: uhc.branch.id, name: uhc.branch.name }
          : null,
        userResources:
          uhc.resources?.map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,
            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })) ?? [],
      })) ?? [];

    const activeUserHasCompany = user.userHasCompany?.find(
      (uhc) => uhc.company?.id === user.activeCompanyId,
    );
    const activeCompanyEntity = activeUserHasCompany?.company ?? null;

    const userResourcesForActiveCompany =
      activeUserHasCompany?.resources?.map((r) => ({
        id: r.id,
        canCreate: r.canCreate,
        canRead: r.canRead,
        canUpdate: r.canUpdate,
        canDelete: r.canDelete,
        canManage: r.canManage,
        status: r.status,
        resource: r.resource
          ? {
            id: r.resource.id,
            name: r.resource.name,
            label: r.resource.label,
          }
          : null,
      })) ?? [];

    const activeCompanyBranch = activeUserHasCompany?.branch
      ? {
        id: activeUserHasCompany.branch.id,
        name: activeUserHasCompany.branch.name,
      }
      : null;

    const activeCompany = activeCompanyEntity
      ? {
        ...activeCompanyEntity,
        tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
        country: activeCompanyEntity.country ?? null,
        city: activeCompanyEntity.city ?? null,
        category: activeCompanyEntity.category ?? null,
        settings: (activeCompanyEntity as any).settings ?? null,
        invoiceConfiguration:
          (activeCompanyEntity as any).invoiceConfiguration ?? null,
        branch: activeCompanyBranch,
        companyResources:
          activeCompanyEntity.companyResources?.map((cr) => ({
            id: cr.id,
            canCreate: cr.can_create,
            canRead: cr.can_read,
            canUpdate: cr.can_update,
            canDelete: cr.can_delete,
            canManage: cr.can_manage,
            status: cr.status,
            resource: cr.resource
              ? {
                id: cr.resource.id,
                name: cr.resource.name,
                label: cr.resource.label,
              }
              : null,
          })) ?? [],
        userResources: userResourcesForActiveCompany,
        branches: (activeCompanyEntity.branches ?? []).map((b) => ({
          id: b.id,
          name: b.name,
          address: b.address,
          phone: b.phone,
          email: b.email,
          status: b.status,
          deleted: b.deleted,
          country: b.country
            ? { id: b.country.id, name: b.country.name }
            : null,
          city: b.city ? { id: b.city.id, name: b.city.name } : null,
        })),
      }
      : null;

    const userPlatformRoles =
      userWithoutPassword.userPlatformRoles?.map((upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      })) ?? [];

    const activeBranch = userWithoutPassword.activeBranch
      ? {
        id: userWithoutPassword.activeBranch.id,
        name: userWithoutPassword.activeBranch.name,
        address: userWithoutPassword.activeBranch.address,
        phone: userWithoutPassword.activeBranch.phone,
        email: userWithoutPassword.activeBranch.email,
        status: userWithoutPassword.activeBranch.status,
        deleted: userWithoutPassword.activeBranch.deleted,
        country: userWithoutPassword.activeBranch.country
          ? {
            id: userWithoutPassword.activeBranch.country.id,
            name: userWithoutPassword.activeBranch.country.name,
          }
          : null,
        city: userWithoutPassword.activeBranch.city
          ? {
            id: userWithoutPassword.activeBranch.city.id,
            name: userWithoutPassword.activeBranch.city.name,
          }
          : null,
      }
      : null;

    const referralData = {
      referralCode: user.referralCode,
      referralCount: user.referralCount || 0,
      referralPoints: user.referralPoints || 0,
      referredBy: user.referredBy,
      referrerName: user.referrer?.fullName || null,
      referralActive: user.referralActive !== false,
      totalReferrals: user.referrals?.length || 0,
    };

    return {
      message: isNewUser
        ? await this.i18n.translate('user.apple_account_created', lang)
        : await this.i18n.translate('user.apple_login_success', lang),
      data: instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        activeCompany,
        userPlatformRoles,
        activeBranch,
        loyalty: {
          points: user.loyalty?.[0]?.pointsBalance ?? 0,
          tier: user.loyalty?.[0]?.currentTier ?? null,
          code: user.loyalty?.[0]?.loyaltyCode ?? null,
        },
        referral: referralData,
      }),
      access_token,
      refresh_token,
      fcmToken,
    };
  }

  async googleLoginByClientData(
    dto: GoogleLoginDto & { platform?: string },
    lang: string = 'fr',
  ): Promise<{
    message: string;
    data: any;
    access_token: string;
    refresh_token: string;
    fcmToken?: string;
  }> {
    const { email, fullName, image, fcmToken, platform } = dto;
    if (!email)
      throw new BadRequestException(
        await this.i18n.translate('user.email_required', lang),
      );

    let user = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('company.settings', 'companySettings')
      .leftJoinAndSelect('company.invoiceConfiguration', 'invoiceConfiguration')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.activeBranch', 'activeBranch')
      .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
      .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
      .leftJoinAndSelect('users.loyalty', 'loyalty')
      .leftJoinAndSelect('users.referrals', 'referrals')
      .leftJoinAndSelect('users.referrer', 'referrer')
      .where('users.email = :email', { email: email.toLowerCase() })
      .getOne();

    let isNewUser = false;

    if (user) {
      console.log(`🔍 [googleLogin] Utilisateur existant: ${user.id}`);

      if (user.provider !== 'google' && user.password) {
        throw new BadRequestException(
          await this.i18n.translate('user.account_with_password_exists', lang),
        );
      }
      if (user.provider !== 'google') {
        await this.usersRepository.update(user.id, { provider: 'google' });
      }

      if (!user.referralCode || user.referralCode.trim() === '') {
        console.warn(`⚠️ [googleLogin] Utilisateur ${user.id} sans referralCode, génération...`);

        const newCode = await this.generateReferralCode(user.id);

        if (!newCode || newCode.trim() === '') {
          throw new InternalServerErrorException(
            await this.i18n.translate('user.referral_code_generation_failed', lang),
          );
        }

        user.referralCode = newCode;
        await this.usersRepository.save(user);
        console.log(`✅ [googleLogin] referralCode généré: ${newCode}`);
      }

      if (!user.loyalty || user.loyalty.length === 0) {
        console.log(`⚠️ [googleLogin] Utilisateur ${user.id} sans loyalty, création...`);
        const loyalty = await this.getOrCreateLoyaltyAccount(user.id);
        await this.loyaltyRepository.save(loyalty);
        user.loyalty = [loyalty];
      }

    } else {
      const newUser = this.usersRepository.create({
        email,
        fullName,
        role: UserRole.CUSTOMER,
        provider: dto.provider || 'google',
        password: '',
        isActive: true,
        image: image || undefined,
        phone: '',
      });
      user = await this.usersRepository.save(newUser);
      isNewUser = true;

      const referralCodeGenerated = await this.generateReferralCode(user.id);

      if (!referralCodeGenerated || referralCodeGenerated.trim() === '') {
        throw new InternalServerErrorException(
          await this.i18n.translate('user.referral_code_generation_failed', lang),
        );
      }

      user.referralCode = referralCodeGenerated;
      await this.usersRepository.save(user);
      console.log(`✅ [googleLogin] Nouveau user créé avec referralCode: ${referralCodeGenerated}`);

      const loyalty = await this.getOrCreateLoyaltyAccount(user.id);
      await this.loyaltyRepository.save(loyalty);
      user.loyalty = [loyalty];

      (async () => {
        try {
          await this.mailService.sendHtmlEmail(
            email,
            await this.i18n.translate('user.welcome_subject', lang),
            'createCount.html',
            { userWithoutPassword: user, year: new Date().getFullYear() },
          );
        } catch (err: any) {
          console.error('❌ [googleLogin] Welcome email error:', err.message);
        }
      })();

      user = await this.usersRepository
        .createQueryBuilder('users')
        .addSelect('users.password')
        .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
        .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
        .leftJoinAndSelect('userHasCompany.company', 'company')
        .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
        .leftJoinAndSelect('company.country', 'country')
        .leftJoinAndSelect('company.city', 'city')
        .leftJoinAndSelect('company.category', 'category')
        .leftJoinAndSelect('company.companyResources', 'companyResources')
        .leftJoinAndSelect('companyResources.resource', 'resource')
        .leftJoinAndSelect('company.branches', 'branches')
        .leftJoinAndSelect('company.settings', 'companySettings')
        .leftJoinAndSelect('company.invoiceConfiguration', 'invoiceConfiguration')
        .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
        .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
        .leftJoinAndSelect('userPlatformRoles.role', 'role')
        .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
        .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
        .leftJoinAndSelect(
          'userCompanyResources.resource',
          'userCompanyResourceDetail',
        )
        .leftJoinAndSelect('users.activeBranch', 'activeBranch')
        .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
        .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
        .leftJoinAndSelect('users.loyalty', 'loyalty')
        .leftJoinAndSelect('users.referrals', 'referrals')
        .leftJoinAndSelect('users.referrer', 'referrer')
        .where('users.id = :id', { id: user.id })
        .getOne();
    }

    if (!user)
      throw new InternalServerErrorException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    // ✅ SÉLECTION DE L'ENTREPRISE ACTIVE SELON x-platform
    await this.applyActiveCompanyByPlatform(user, platform);

    if (fcmToken && platform) {
      (async () => {
        try {
          const existingToken = await this.deviceTokenRepo.findOne({
            where: { token: fcmToken },
            select: ['id'],
          });

          if (existingToken) {
            await this.deviceTokenRepo.update(
              { token: fcmToken },
              { userId: user!.id, platform, updatedAt: new Date() },
            );
          } else {
            await this.deviceTokenRepo.save(
              this.deviceTokenRepo.create({
                token: fcmToken,
                userId: user!.id,
                platform,
              }),
            );
          }
        } catch (err: any) {
          console.error('❌ [googleLogin] FCM token save error:', err.message);
        }
      })();
    }

    const [access_token, refresh_token] = await Promise.all([
      this.accessToken(user),
      this.refreshToken(user),
    ]);

    const { password, ...userWithoutPassword } = user;

    const userHasCompany =
      userWithoutPassword.userHasCompany?.map((uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,
        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,
            settings: (uhc.company as any).settings ?? null,
            invoiceConfiguration:
              (uhc.company as any).invoiceConfiguration ?? null,
            branches: (uhc.company.branches ?? []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,
              country: b.country
                ? { id: b.country.id, name: b.country.name }
                : null,
              city: b.city ? { id: b.city.id, name: b.city.name } : null,
            })),
          }
          : null,
        branch: uhc.branch
          ? { id: uhc.branch.id, name: uhc.branch.name }
          : null,
        userResources:
          uhc.resources?.map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,
            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })) ?? [],
      })) ?? [];

    const activeUserHasCompany = user.userHasCompany?.find(
      (uhc) => uhc.company?.id === user.activeCompanyId,
    );
    const activeCompanyEntity = activeUserHasCompany?.company ?? null;

    const userResourcesForActiveCompany =
      activeUserHasCompany?.resources?.map((r) => ({
        id: r.id,
        canCreate: r.canCreate,
        canRead: r.canRead,
        canUpdate: r.canUpdate,
        canDelete: r.canDelete,
        canManage: r.canManage,
        status: r.status,
        resource: r.resource
          ? {
            id: r.resource.id,
            name: r.resource.name,
            label: r.resource.label,
          }
          : null,
      })) ?? [];

    const activeCompanyBranch = activeUserHasCompany?.branch
      ? {
        id: activeUserHasCompany.branch.id,
        name: activeUserHasCompany.branch.name,
      }
      : null;

    const activeCompany = activeCompanyEntity
      ? {
        ...activeCompanyEntity,
        tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
        country: activeCompanyEntity.country ?? null,
        city: activeCompanyEntity.city ?? null,
        category: activeCompanyEntity.category ?? null,
        settings: (activeCompanyEntity as any).settings ?? null,
        invoiceConfiguration:
          (activeCompanyEntity as any).invoiceConfiguration ?? null,
        branch: activeCompanyBranch,
        companyResources:
          activeCompanyEntity.companyResources?.map((cr) => ({
            id: cr.id,
            canCreate: cr.can_create,
            canRead: cr.can_read,
            canUpdate: cr.can_update,
            canDelete: cr.can_delete,
            canManage: cr.can_manage,
            status: cr.status,
            resource: cr.resource
              ? {
                id: cr.resource.id,
                name: cr.resource.name,
                label: cr.resource.label,
              }
              : null,
          })) ?? [],
        userResources: userResourcesForActiveCompany,
        branches: (activeCompanyEntity.branches ?? []).map((b) => ({
          id: b.id,
          name: b.name,
          address: b.address,
          phone: b.phone,
          email: b.email,
          status: b.status,
          deleted: b.deleted,
          country: b.country
            ? { id: b.country.id, name: b.country.name }
            : null,
          city: b.city ? { id: b.city.id, name: b.city.name } : null,
        })),
      }
      : null;

    const userPlatformRoles =
      userWithoutPassword.userPlatformRoles?.map((upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      })) ?? [];

    const activeBranch = userWithoutPassword.activeBranch
      ? {
        id: userWithoutPassword.activeBranch.id,
        name: userWithoutPassword.activeBranch.name,
        address: userWithoutPassword.activeBranch.address,
        phone: userWithoutPassword.activeBranch.phone,
        email: userWithoutPassword.activeBranch.email,
        status: userWithoutPassword.activeBranch.status,
        deleted: userWithoutPassword.activeBranch.deleted,
        country: userWithoutPassword.activeBranch.country
          ? {
            id: userWithoutPassword.activeBranch.country.id,
            name: userWithoutPassword.activeBranch.country.name,
          }
          : null,
        city: userWithoutPassword.activeBranch.city
          ? {
            id: userWithoutPassword.activeBranch.city.id,
            name: userWithoutPassword.activeBranch.city.name,
          }
          : null,
      }
      : null;

    const referralData = {
      referralCode: user.referralCode,
      referralCount: user.referralCount || 0,
      referralPoints: user.referralPoints || 0,
      referredBy: user.referredBy,
      referrerName: user.referrer?.fullName || null,
      referralActive: user.referralActive !== false,
      totalReferrals: user.referrals?.length || 0,
    };

    return {
      message: isNewUser
        ? await this.i18n.translate('user.google_account_created', lang)
        : await this.i18n.translate('user.google_login_success', lang),
      data: instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        activeCompany,
        userPlatformRoles,
        activeBranch,
        loyalty: {
          points: user.loyalty?.[0]?.pointsBalance ?? 0,
          tier: user.loyalty?.[0]?.currentTier ?? null,
          code: user.loyalty?.[0]?.loyaltyCode ?? null,
        },
        referral: referralData,
      }),
      access_token,
      refresh_token,
      fcmToken,
    };
  }

  // ==================== APPLE LOGIN ====================
  private async ensureReferralCodeAndLoyalty(
    user: UserEntity,
    lang: string,
  ): Promise<UserEntity> {
    let needsSave = false;

    // 🔥 Garantir le referralCode
    if (!user.referralCode || user.referralCode.trim() === '') {
      console.warn(`âš ï¸ Utilisateur ${user.id} sans referralCode, génération...`);

      const existingCodesRows = await this.usersRepository
        .createQueryBuilder('u')
        .select('u.referralCode', 'code')
        .where('u.referralCode IS NOT NULL')
        .andWhere("TRIM(u.referralCode) != ''")
        .getRawMany();
      const existingCodes = existingCodesRows.map((r) => r.code);

      const newCode = await this.generateReferralCode(user.id, existingCodes);
      if (!newCode || newCode.trim() === '') {
        throw new InternalServerErrorException(
          await this.i18n.translate('user.referral_code_generation_failed', lang),
        );
      }
      user.referralCode = newCode;
      needsSave = true;
      console.log(`✅ referralCode généré: ${newCode}`);
    }

    // 🔥 Garantir le compte fidélité
    if (!user.loyalty || user.loyalty.length === 0) {
      console.log(`âš ï¸ Utilisateur ${user.id} sans loyalty, création...`);
      const loyalty = await this.getOrCreateLoyaltyAccount(user.id);
      await this.loyaltyRepository.save(loyalty);
    }

    if (needsSave) {
      await this.usersRepository.save(user);
    }

    return user;
  }

  // ==================== UPDATE USER ====================
  async update(
    updateUserDto: Partial<UpdateUserDto>,
    currentUser: UserEntity,
    lang: string = 'fr',
  ): Promise<{
    message: string;
    data: any;
    access_token: string;
    refresh_token: string;
  }> {
    try {
      const user = await this.usersRepository.findOne({
        where: { id: currentUser.id },
      });
      if (!user)
        throw new NotFoundException(
          await this.i18n.translate('user.user_not_found', lang),
        );

      const {
        provider,
        appleUserId,
        role,
        password,
        isActive,
        // ✅ email et téléphone ne se modifient plus ici :
        //    PATCH users/me/email et PATCH users/me/phone
        email,
        phone,
        deleted,
        ...safeUpdateData
      } = updateUserDto as any;
      Object.assign(user, safeUpdateData);
      await this.usersRepository.save(user);

      // ✅ Profil complet + nouveaux jetons (partagé avec updateEmail / updatePhone)
      return await this.buildProfileResponse(user.id, lang, 'user.user_updated');
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l’utilisateur:', error);
      throw new InternalServerErrorException(
        await this.i18n.translate('user.user_updated_failed', lang),
      );
    }
  }

  /**
   * Profil complet de l'utilisateur (entreprises, ressources, rôles, branche active)
   * + nouveaux access_token / refresh_token.
   * Utilisé par update(), updateEmail() et updatePhone().
   */
  private async buildProfileResponse(
    userId: string,
    lang: string,
    messageKey: string,
  ): Promise<{
    message: string;
    data: any;
    access_token: string;
    refresh_token: string;
  }> {

    let fullUser = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.activeBranch', 'activeBranch')
      .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
      .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
      .where('users.id = :id', { id: userId })
      .getOne();

    if (!fullUser)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    // ✅ OPTIMISATION : JWT en parallèle
    const [access_token, refresh_token] = await Promise.all([
      this.accessToken(fullUser),
      this.refreshToken(fullUser),
    ]);

    const { password: _, ...userWithoutPassword } = fullUser;

    const userHasCompany =
      userWithoutPassword.userHasCompany?.map((uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,
        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,
            branches: (uhc.company.branches ?? []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,
              country: b.country
                ? { id: b.country.id, name: b.country.name }
                : null,
              city: b.city ? { id: b.city.id, name: b.city.name } : null,
            })),
          }
          : null,
        branch: uhc.branch
          ? { id: uhc.branch.id, name: uhc.branch.name }
          : null,
        userResources:
          uhc.resources?.map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,
            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })) ?? [],
      })) ?? [];

    // ✅ OPTIMISATION : activeCompany calculée depuis fullUser.userHasCompany
    //    (plus de requête activeCompanyRaw)
    const activeUserHasCompany = fullUser.userHasCompany?.find(
      (uhc) => uhc.company?.id === fullUser.activeCompanyId,
    );
    const activeCompanyEntity = activeUserHasCompany?.company ?? null;
    const userResourcesForActiveCompany =
      activeUserHasCompany?.resources?.map((r) => ({
        id: r.id,
        canCreate: r.canCreate,
        canRead: r.canRead,
        canUpdate: r.canUpdate,
        canDelete: r.canDelete,
        canManage: r.canManage,
        status: r.status,
        resource: r.resource
          ? {
            id: r.resource.id,
            name: r.resource.name,
            label: r.resource.label,
          }
          : null,
      })) ?? [];

    const activeCompanyBranch = activeUserHasCompany?.branch
      ? {
        id: activeUserHasCompany.branch.id,
        name: activeUserHasCompany.branch.name,
      }
      : null;

    const activeCompany = activeCompanyEntity
      ? {
        ...activeCompanyEntity,
        tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
        country: activeCompanyEntity.country ?? null,
        city: activeCompanyEntity.city ?? null,
        category: activeCompanyEntity.category ?? null,
        branch: activeCompanyBranch,
        companyResources:
          activeCompanyEntity.companyResources?.map((cr) => ({
            id: cr.id,
            canCreate: cr.can_create,
            canRead: cr.can_read,
            canUpdate: cr.can_update,
            canDelete: cr.can_delete,
            canManage: cr.can_manage,
            status: cr.status,
            resource: cr.resource
              ? {
                id: cr.resource.id,
                name: cr.resource.name,
                label: cr.resource.label,
              }
              : null,
          })) ?? [],
        userResources: userResourcesForActiveCompany,
        branches: (activeCompanyEntity.branches ?? []).map((b) => ({
          id: b.id,
          name: b.name,
          address: b.address,
          phone: b.phone,
          email: b.email,
          status: b.status,
          deleted: b.deleted,
          country: b.country
            ? { id: b.country.id, name: b.country.name }
            : null,
          city: b.city ? { id: b.city.id, name: b.city.name } : null,
        })),
      }
      : null;

    const userPlatformRoles =
      userWithoutPassword.userPlatformRoles?.map((upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      })) ?? [];

    const activeBranch = userWithoutPassword.activeBranch
      ? {
        id: userWithoutPassword.activeBranch.id,
        name: userWithoutPassword.activeBranch.name,
        address: userWithoutPassword.activeBranch.address,
        phone: userWithoutPassword.activeBranch.phone,
        email: userWithoutPassword.activeBranch.email,
        status: userWithoutPassword.activeBranch.status,
        deleted: userWithoutPassword.activeBranch.deleted,
        country: userWithoutPassword.activeBranch.country
          ? {
            id: userWithoutPassword.activeBranch.country.id,
            name: userWithoutPassword.activeBranch.country.name,
          }
          : null,
        city: userWithoutPassword.activeBranch.city
          ? {
            id: userWithoutPassword.activeBranch.city.id,
            name: userWithoutPassword.activeBranch.city.name,
          }
          : null,
      }
      : null;

    return {
      message: await this.i18n.translate(messageKey, lang),
      data: instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        activeCompany,
        userPlatformRoles,
        activeBranch,
      }),
      access_token,
      refresh_token,
    };
  }

  // ============================================================
  // ✅ MODIFICATION DE L'EMAIL SEUL — PATCH users/me/email
  // ============================================================
  async updateEmail(
    currentUser: UserEntity,
    dto: UpdateEmailDto,
    lang: string = 'fr',
  ) {
    const user = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .where('users.id = :id', { id: currentUser.id })
      .getOne();
    if (!user)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    const email = String(dto.email || '').trim().toLowerCase();
    if (!email)
      throw new BadRequestException(
        await this.i18n.translate('user.email_required', lang),
      );
    if (!validator.isEmail(email))
      throw new BadRequestException(
        await this.i18n.translate('user.valid_email', lang),
      );
    if ((user.email || '').toLowerCase() === email)
      throw new BadRequestException(
        await this.i18n.translate('user.email_unchanged', lang),
      );

    const exists = await this.usersRepository
      .createQueryBuilder('users')
      .select('users.id')
      .where('LOWER(users.email) = :email', { email })
      .andWhere('users.id <> :id', { id: user.id })
      .getOne();
    if (exists)
      throw new BadRequestException(
        await this.i18n.translate('user.email_already_exists', lang),
      );

    // ✅ Confirmation par code PIN envoyé à la NOUVELLE adresse (plus de mot de passe)
    if (!dto.otpCode) return this.sendContactChangeCode(user, 'email', email, lang);
    await this.verifyContactChangeCode(user, email, dto.otpCode, lang);

    await this.usersRepository.update(user.id, { email });
    return this.buildProfileResponse(user.id, lang, 'user.email_updated');
  }

  // ============================================================
  // ✅ MODIFICATION DU TÉLÉPHONE SEUL — PATCH users/me/phone
  // ============================================================
  async updatePhone(
    currentUser: UserEntity,
    dto: UpdatePhoneDto,
    lang: string = 'fr',
  ) {
    const user = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .where('users.id = :id', { id: currentUser.id })
      .getOne();
    if (!user)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    // Espaces, tirets, points et parenthèses retirés : "+243 97-000 00 00" → "+243970000000"
    const phone = String(dto.phone || '').trim().replace(/[\s\-().]/g, '');
    if (!phone)
      throw new BadRequestException(
        await this.i18n.translate('user.phone_required', lang),
      );
    if (!/^\+?[0-9]{8,15}$/.test(phone))
      throw new BadRequestException(
        await this.i18n.translate('user.phone_invalid', lang),
      );
    if ((user.phone || '').replace(/[\s\-().]/g, '') === phone)
      throw new BadRequestException(
        await this.i18n.translate('user.phone_unchanged', lang),
      );

    const exists = await this.usersRepository
      .createQueryBuilder('users')
      .select('users.id')
      .where('users.phone = :phone', { phone })
      .andWhere('users.id <> :id', { id: user.id })
      .getOne();
    if (exists)
      throw new BadRequestException(
        await this.i18n.translate('user.phone_already_exists', lang),
      );

    // ✅ Confirmation par code PIN envoyé par SMS au NOUVEAU numéro (plus de mot de passe)
    if (!dto.otpCode) return this.sendContactChangeCode(user, 'phone', phone, lang);
    await this.verifyContactChangeCode(user, phone, dto.otpCode, lang);

    await this.usersRepository.update(user.id, { phone });
    return this.buildProfileResponse(user.id, lang, 'user.phone_updated');
  }

  // ============================================================
  // ✅ CODE PIN POUR CHANGER L'EMAIL / LE TÉLÉPHONE
  //    Le code est envoyé à la NOUVELLE adresse / au NOUVEAU numéro : il prouve que
  //    l'utilisateur la possède. Valable 10 minutes, un seul usage, renvoi après 60 s.
  // ============================================================
  private contactChangeKey(destination: string) {
    // Préfixe : ces codes ne se mélangent pas avec ceux de connexion / inscription
    return `contact-change:${destination}`;
  }

  private async sendContactChangeCode(
    user: UserEntity,
    kind: 'email' | 'phone',
    destination: string,
    lang: string,
  ) {
    const key = this.contactChangeKey(destination);

    // Anti-abus : un nouveau code au plus toutes les 60 secondes
    const last = await this.otpRepository.findOne({
      where: { email: key, isUsed: false, user: { id: user.id } },
      order: { createdAt: 'DESC' },
    });
    if (last && Date.now() - new Date(last.createdAt).getTime() < 60 * 1000) {
      throw new BadRequestException(
        await this.i18n.translate('user.contact_change_wait', lang, { seconds: 60 }),
      );
    }

    // Les anciens codes de ce changement ne sont plus valables
    await this.otpRepository
      .createQueryBuilder()
      .update()
      .set({ isUsed: true })
      .where('email = :key AND isUsed = :no AND userId = :uid', { key, no: false, uid: user.id })
      .execute()
      .catch(() => undefined);

    const otpCode = Math.floor(1000 + Math.random() * 9000).toString();
    await this.otpRepository.save(
      this.otpRepository.create({
        email: key,
        phone: kind === 'phone' ? destination : undefined,
        otpCode,
        user: { id: user.id } as any,
        expiresAt: new Date(Date.now() + 10 * 60 * 1000),
      }),
    );

    if (kind === 'email') {
      const translations = {
        title: await this.i18n.translate('user.otp_email_title', lang),
        description: await this.i18n.translate('user.contact_change_email_description', lang),
        label: await this.i18n.translate('user.otp_email_label', lang),
        expiry: await this.i18n.translate('user.otp_email_expiry', lang, { minutes: 10 }),
        support: await this.i18n.translate('user.otp_email_support', lang),
        contact: await this.i18n.translate('user.otp_email_contact', lang),
        footerCopyright: await this.i18n.translate('user.otp_email_footer_copyright', lang),
        footerSecurity: await this.i18n.translate('user.otp_email_footer_security', lang),
        legalNote: await this.i18n.translate('user.otp_email_legal_note', lang),
      };
      try {
        await this.mailService.sendHtmlEmail(
          destination,
          await this.i18n.translate('user.contact_change_email_subject', lang),
          'sendOtp.html',
          { otpCode, year: new Date().getFullYear(), translations, lang },
        );
      } catch (e: any) {
        console.error('[ContactChange] Email non envoyé :', e?.message);
        throw new BadRequestException(await this.i18n.translate('user.contact_change_send_failed', lang));
      }
      return {
        message: await this.i18n.translate('user.otp_sent_email', lang),
        data: { otpRequired: true, channel: 'email', destination, expiresInSeconds: 600, resendInSeconds: 60 },
      };
    }

    const sms = await this.i18n.translate('user.contact_change_sms_body', lang, { otpCode });
    const sent = await this.safeSendAuthSms(destination, sms, 'CONTACT_CHANGE_OTP');
    if (!sent) {
      throw new BadRequestException(await this.i18n.translate('user.contact_change_send_failed', lang));
    }
    return {
      message: await this.i18n.translate('user.otp_sent_sms', lang),
      data: { otpRequired: true, channel: 'sms', destination, expiresInSeconds: 600, resendInSeconds: 60 },
    };
  }

  private async verifyContactChangeCode(user: UserEntity, destination: string, otpCode: string, lang: string) {
    const entry = await this.otpRepository.findOne({
      where: { email: this.contactChangeKey(destination), otpCode: String(otpCode).trim(), isUsed: false, user: { id: user.id } },
      order: { createdAt: 'DESC' },
    });
    if (!entry || !entry.expiresAt || new Date() > new Date(entry.expiresAt)) {
      throw new BadRequestException(await this.i18n.translate('user.otp_invalid', lang));
    }
    entry.isUsed = true;
    await this.otpRepository.save(entry);
  }

  async updateProfileImage(
    userId: string,
    file?: Express.Multer.File,
    lang: string = 'fr',
  ): Promise<{
    message: string;
    data: any;
  }> {
    let user = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.activeBranch', 'activeBranch')
      .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
      .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
      .where('users.id = :id', { id: userId })
      .getOne();

    if (!user)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );
    if (!file)
      throw new BadRequestException(
        await this.i18n.translate('user.invalid_image', lang),
      );

    if (isStoredFileUrl(user.image)) {
      try {
        const filename = user.image.split('/').pop()!;
        await this.filesService.deleteFile('user', filename);
      } catch (err) {
        console.warn('âš ï¸ Échec suppression ancienne image :', err.message);
      }
    }

    const uploadedFile = await this.filesService.uploadFile(
      file,
      'user',
      'avatar',
    );
    user.image = uploadedFile.data;
    const updatedUser = await this.usersRepository.save(user);

    // ============================================================
    // ✅ OPTIMISATION : on utilise directement `user` (déjà chargé avec toutes
    //    les relations) au lieu de recharger `fullUser`
    // ============================================================

    const { password, ...userWithoutPassword } = user;

    const userHasCompany = (userWithoutPassword.userHasCompany || []).map(
      (uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,
        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,
            branches: (uhc.company.branches || []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,
              country: b.country
                ? { id: b.country.id, name: b.country.name }
                : null,
              city: b.city ? { id: b.city.id, name: b.city.name } : null,
            })),
          }
          : null,
        branch: uhc.branch
          ? { id: uhc.branch.id, name: uhc.branch.name }
          : null,
        userResources: (uhc.resources || []).map((r) => ({
          id: r.id,
          canCreate: r.canCreate,
          canRead: r.canRead,
          canUpdate: r.canUpdate,
          canDelete: r.canDelete,
          canManage: r.canManage,
          status: r.status,
          resource: r.resource
            ? {
              id: r.resource.id,
              name: r.resource.name,
              label: r.resource.label,
            }
            : null,
        })),
      }),
    );

    // ✅ OPTIMISATION : activeCompany calculée depuis user.userHasCompany
    //    (plus de requête activeCompanyRaw)
    const activeUserHasCompany = user.userHasCompany?.find(
      (uhc) => uhc.company?.id === user.activeCompanyId,
    );
    const activeCompanyEntity = activeUserHasCompany?.company ?? null;
    const activeCompanyBranch = activeUserHasCompany?.branch
      ? {
        id: activeUserHasCompany.branch.id,
        name: activeUserHasCompany.branch.name,
      }
      : null;

    const userResourcesForActiveCompany = (
      activeUserHasCompany?.resources || []
    ).map((r) => ({
      id: r.id,
      canCreate: r.canCreate,
      canRead: r.canRead,
      canUpdate: r.canUpdate,
      canDelete: r.canDelete,
      canManage: r.canManage,
      status: r.status,
      resource: r.resource
        ? { id: r.resource.id, name: r.resource.name, label: r.resource.label }
        : null,
    }));

    const activeCompany = activeCompanyEntity
      ? {
        ...activeCompanyEntity,
        tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
        country: activeCompanyEntity.country ?? null,
        city: activeCompanyEntity.city ?? null,
        category: activeCompanyEntity.category ?? null,
        branch: activeCompanyBranch,
        companyResources: (activeCompanyEntity.companyResources || []).map(
          (cr) => ({
            id: cr.id,
            canCreate: cr.can_create,
            canRead: cr.can_read,
            canUpdate: cr.can_update,
            canDelete: cr.can_delete,
            canManage: cr.can_manage,
            status: cr.status,
            resource: cr.resource
              ? {
                id: cr.resource.id,
                name: cr.resource.name,
                label: cr.resource.label,
              }
              : null,
          }),
        ),
        userResources: userResourcesForActiveCompany,
        branches: (activeCompanyEntity.branches || []).map((b) => ({
          id: b.id,
          name: b.name,
          address: b.address,
          phone: b.phone,
          email: b.email,
          status: b.status,
          deleted: b.deleted,
          country: b.country
            ? { id: b.country.id, name: b.country.name }
            : null,
          city: b.city ? { id: b.city.id, name: b.city.name } : null,
        })),
      }
      : null;

    const userPlatformRoles = (userWithoutPassword.userPlatformRoles || []).map(
      (upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      }),
    );

    const activeBranch = userWithoutPassword.activeBranch
      ? {
        id: userWithoutPassword.activeBranch.id,
        name: userWithoutPassword.activeBranch.name,
        address: userWithoutPassword.activeBranch.address,
        phone: userWithoutPassword.activeBranch.phone,
        email: userWithoutPassword.activeBranch.email,
        status: userWithoutPassword.activeBranch.status,
        deleted: userWithoutPassword.activeBranch.deleted,
        country: userWithoutPassword.activeBranch.country
          ? {
            id: userWithoutPassword.activeBranch.country.id,
            name: userWithoutPassword.activeBranch.country.name,
          }
          : null,
        city: userWithoutPassword.activeBranch.city
          ? {
            id: userWithoutPassword.activeBranch.city.id,
            name: userWithoutPassword.activeBranch.city.name,
          }
          : null,
      }
      : null;

    return {
      message: await this.i18n.translate('user.profile_image_updated', lang),
      data: instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        activeCompany,
        userPlatformRoles,
        activeBranch,
      }),
    };
  }

  async getReferralPoints(
    userId: string,
    lang: string = 'fr',
  ): Promise<any> {
    const user = await this.usersRepository.findOne({
      where: { id: userId },
      relations: [
        'referralHistory',
        'referralHistory.referred',
        'referralHistory.referred.orders',
      ],
    });

    if (!user) {
      throw new NotFoundException(
        await this.i18n.translate('user_not_found', lang)
      );
    }

    // ============================================================
    // ✅ RÉCUPÉRER LES TRANSACTIONS EN ATTENTE (DEPOSIT PENDING)
    // ============================================================
    let pendingTransactions = null;
    try {
      if (user.userIdFpay) {
        const pendingResult = await this.fpayService.getLastPendingTransaction(
          user.userIdFpay,
          'DEPOSIT'
        );

        if (pendingResult && pendingResult.success) {
          // âœ… Correction avec typage explicite
          const totalsArray = Object.entries(pendingResult.totalsByCurrency || {})
            .filter(([, amount]) => typeof amount === 'number' && amount > 0)
            .map(([currency, amount]) => ({
              amount: Math.round((amount as number) * 100) / 100,
              currency: currency,
            }));

          pendingTransactions = {
            ...pendingResult.data,
            totalsByCurrency: totalsArray,
            currencies: pendingResult.currencies || [],
            currenciesWithData: pendingResult.currenciesWithData || [],
            count: pendingResult.count || 0,
          };
        }
      }
    } catch (error) {
      console.error('[ReferralPoints] âŒ Erreur récupération transactions PENDING:', error.message);
    }

    let totalPoints = 0;
    const rewardsByCurrency: Record<string, number> = {};

    // âœ… Historique des parrainages
    const history = user.referralHistory?.map((referral) => {
      const referred = referral.referred;
      let orderDetails: any[] = [];
      let validatedOrdersLength = 0;

      const rewardAmount = Number(referral.rewardAmount) || 0;
      const rewardCurrency = referral.currency || 'USD';

      if (referred && referred.orders && referred.orders.length > 0) {
        const validatedOrders = referred.orders.filter(
          (order) => order.status === OrderStatus.VALIDATED
        );
        validatedOrdersLength = validatedOrders.length;

        orderDetails = validatedOrders.map((order) => ({
          orderId: order.id,
          shippingCost: order.shippingCost || 0,
          currency: order.currency || 'USD',
          reward: (Number(order.shippingCost || 0) * 0.10),
          rewardCurrency: rewardCurrency,
          createdAt: order.createdAt,
          status: order.status,
        }));
      }

      if (rewardAmount > 0) {
        if (!rewardsByCurrency[rewardCurrency]) {
          rewardsByCurrency[rewardCurrency] = 0;
        }
        rewardsByCurrency[rewardCurrency] += rewardAmount;
        totalPoints += rewardAmount;
      }

      return {
        id: referral.id,
        referredUser: referred?.fullName || 'Utilisateur inconnu',
        referredEmail: referred?.email || 'Non renseigné',
        referredPhone: referred?.phone || 'Non renseigné',
        referredId: referred?.id || null,
        status: referral.status,
        rewardAmount: Math.round(rewardAmount * 100) / 100,
        rewardCurrency: rewardCurrency,
        rewardType: 'POINTS (10% shipping - VALIDATED)',
        createdAt: referral.createdAt,
        completedAt: referral.completedAt || null,
        orders: orderDetails,
        totalValidatedOrders: validatedOrdersLength,
        referralCurrency: referral.currency || 'USD',
        metadata: referral.metadata,
      };
    }) || [];

    // ✅ Mise à jour des points
    if (Math.round(totalPoints * 100) / 100 !== user.referralPoints) {
      user.referralPoints = Math.round(totalPoints * 100) / 100;
      await this.usersRepository.save(user);
    }

    // ✅ Liste des utilisateurs parrainés groupés
    const referredUsersMap = new Map<string, {
      id: string;
      fullName: string;
      email: string | null;
      phone: string | null;
      status: string;
      totalOrders: number;
      totalValidatedOrders: number;
      totalShippingCost: number;
      currency: string;
      pointsEarned: number;
      pointsCurrency: string;
      createdAt: Date;
      completedAt: Date | null;
    }>();

    for (const referral of user.referralHistory || []) {
      const referred = referral.referred;
      if (!referred) continue;

      const referredId = referred.id;
      const currency = referral.currency || 'USD';
      const pointsEarned = Number(referral.rewardAmount) || 0;

      const validatedOrders = referred.orders?.filter(
        (order) => order.status === OrderStatus.VALIDATED
      ) || [];
      const totalShippingCost = validatedOrders.reduce(
        (sum, order) => sum + Number(order.shippingCost || 0),
        0
      );

      if (!referredUsersMap.has(referredId)) {
        referredUsersMap.set(referredId, {
          id: referredId,
          fullName: referred.fullName || 'Utilisateur inconnu',
          email: referred.email || null,
          phone: referred.phone || null,
          status: referral.status,
          totalOrders: referred.orders?.length || 0,
          totalValidatedOrders: validatedOrders.length,
          totalShippingCost: 0,
          currency: currency,
          pointsEarned: 0,
          pointsCurrency: currency,
          createdAt: referral.createdAt,
          completedAt: referral.completedAt || null,
        });
      }

      const userEntry = referredUsersMap.get(referredId)!;
      userEntry.totalShippingCost += totalShippingCost;

      if (referral.createdAt > userEntry.createdAt) {
        userEntry.currency = currency;
        userEntry.pointsCurrency = currency;
        userEntry.pointsEarned = pointsEarned;
      } else if (referral.createdAt.getTime() === userEntry.createdAt.getTime()) {
        userEntry.pointsEarned += pointsEarned;
      }

      if (referral.completedAt && (!userEntry.completedAt || referral.completedAt > userEntry.completedAt)) {
        userEntry.completedAt = referral.completedAt;
      }
      if (referral.createdAt > userEntry.createdAt) {
        userEntry.createdAt = referral.createdAt;
      }
    }

    const referredUsers = Array.from(referredUsersMap.values()).map((entry) => ({
      id: entry.id,
      fullName: entry.fullName,
      email: entry.email,
      phone: entry.phone,
      status: entry.status,
      totalOrders: entry.totalOrders,
      totalValidatedOrders: entry.totalValidatedOrders,
      totalShippingCost: Math.round(entry.totalShippingCost * 100) / 100,
      currency: entry.currency,
      pointsEarned: Math.round(entry.pointsEarned * 100) / 100,
      pointsCurrency: entry.currency,
      createdAt: entry.createdAt,
      completedAt: entry.completedAt,
    }));

    referredUsers.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    const rewardsByCurrencyArray = Object.entries(rewardsByCurrency).map(([currency, amount]) => ({
      currency: currency,
      amount: Math.round(amount * 100) / 100,
    }));

    const baseUrl = 'https://favorhelp.com';
    const referralLink = user.referralCode
      ? `${baseUrl}/register?ref=${user.referralCode}`
      : null;

    return {
      message: await this.i18n.translate('referral_points_retrieved', lang),
      data: {
        referralPoints: Math.round(totalPoints * 100) / 100,
        totalReferralRewards: Math.round(totalPoints * 100) / 100,
        referralCount: user.referralCount || 0,
        referralCode: user.referralCode || 'Non généré',
        referralLink: referralLink || 'Non disponible',
        referralActive: user.referralActive !== false,
        rewardsByCurrency: rewardsByCurrencyArray,
        defaultCurrency: 'USD',
        history,
        referredUsers,
        pendingTransactions: pendingTransactions,
      },
    };
  }

  async sendOtp(email: string, lang: string = 'fr'): Promise<any> {
    const otpCode = Math.floor(1000 + Math.random() * 9000).toString();

    // Validation du DTO (optionnel selon votre logique)
    const dto = plainToInstance(VerifyOtpDto, { email, otpCode: '0000' });
    const errors = await validate(dto, {
      whitelist: true,
      forbidNonWhitelisted: true,
    });
    if (errors.length > 0) {
      const errorMessages = errors
        .map((err) => Object.values(err.constraints ?? {}).join(', '))
        .join(', ');
      throw new BadRequestException(errorMessages);
    }

    // Supprimer l'ancien OTP non utilisé
    const existingOtp = await this.otpRepository.findOne({
      where: { email, isUsed: false },
    });
    if (existingOtp) await this.otpRepository.remove(existingOtp);

    // Créer le nouvel OTP
    const otp = this.otpRepository.create({
      email,
      otpCode,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000),
    });
    await this.otpRepository.save(otp);

    // Envoi par email ou SMS
    if (validator.isEmail(email)) {
      // Récupération des traductions pour l'email
      const translations = {
        title: await this.i18n.translate('user.otp_email_title', lang),
        description: await this.i18n.translate('user.otp_email_description', lang),
        label: await this.i18n.translate('user.otp_email_label', lang),
        expiry: await this.i18n.translate('user.otp_email_expiry', lang, { minutes: 10 }),
        support: await this.i18n.translate('user.otp_email_support', lang),
        contact: await this.i18n.translate('user.otp_email_contact', lang),
        footerCopyright: await this.i18n.translate('user.otp_email_footer_copyright', lang),
        footerSecurity: await this.i18n.translate('user.otp_email_footer_security', lang),
        legalNote: await this.i18n.translate('user.otp_email_legal_note', lang),
      };

      const subject = await this.i18n.translate('user.otp_login_subject', lang);

      await this.mailService.sendHtmlEmail(
        email,
        subject,
        'sendOtp.html',
        {
          otpCode,
          year: new Date().getFullYear(),
          translations,
          lang,
        }
      );
    } else if (validator.isMobilePhone(email, 'any')) {
      const message = await this.i18n.translate('user.otp_sms_body', lang, {
        otpCode,
      });

      // ✅ Best effort : on tente, mais on ne bloque JAMAIS l'envoi d'OTP
      await this.safeSendAuthSms(email, message, 'SEND_OTP');
    }

    return {
      message: await this.i18n.translate('user.otp_sent', lang),
      otpCode,
    };
  }

  async sendResetPasswordOtp(email: string, lang: string = 'fr'): Promise<any> {
    const user = await this.usersRepository.findOne({
      where: [{ email }, { phone: email }],
    });
    if (!user) throw new BadRequestException(await this.i18n.translate('user.user_not_found', lang));

    const otpCode = Math.floor(1000 + Math.random() * 9000).toString();
    const otp = this.otpRepository.create({
      email,
      otpCode,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000),
    });
    await this.otpRepository.save(otp);

    if (validator.isEmail(email)) {
      // ✅ Construire l'objet translations (identique à sendOtp)
      const translations = {
        title: await this.i18n.translate('user.otp_email_title', lang),
        description: await this.i18n.translate('user.otp_email_description', lang),
        label: await this.i18n.translate('user.otp_email_label', lang),
        expiry: await this.i18n.translate('user.otp_email_expiry', lang, { minutes: 10 }),
        support: await this.i18n.translate('user.otp_email_support', lang),
        contact: await this.i18n.translate('user.otp_email_contact', lang),
        footerCopyright: await this.i18n.translate('user.otp_email_footer_copyright', lang),
        footerSecurity: await this.i18n.translate('user.otp_email_footer_security', lang),
        legalNote: await this.i18n.translate('user.otp_email_legal_note', lang),
      };

      const subject = await this.i18n.translate('user.reset_password_subject', lang);

      await this.mailService.sendHtmlEmail(
        email,
        subject,
        'sendOtp.html',
        {
          otpCode,
          year: new Date().getFullYear(),
          translations,   // ✅ nécessaire pour le template
          lang,           // ✅ nécessaire pour l'attribut lang du HTML
        }
      );
    } else if (validator.isMobilePhone(email, 'any')) {
      const message = await this.i18n.translate('user.reset_password_sms_body', lang, { otpCode });

      // ✅ Best effort : on tente, mais on ne bloque JAMAIS le reset password
      await this.safeSendAuthSms(email, message, 'RESET_PASSWORD_OTP');
    }

    return { message: await this.i18n.translate('user.reset_otp_sent_success', lang) };
  }

  async resetPassword(
    resetPasswordDto: ResetPasswordDto,
    lang: string = 'fr',
  ): Promise<any> {
    const { email, otpCode, password } = resetPasswordDto;

    const otpEntry = await this.otpRepository.findOne({
      where: { email, otpCode, isUsed: false },
    });
    if (!otpEntry || new Date() > otpEntry.expiresAt) {
      throw new BadRequestException(
        await this.i18n.translate('user.otp_invalid', lang),
      );
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await this.usersRepository.findOne({
      where: [{ email }, { phone: email }],
    });
    if (!user)
      throw new BadRequestException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    user.password = hashedPassword;
    await this.usersRepository.save(user);

    otpEntry.isUsed = true;
    await this.otpRepository.save(otpEntry);

    // ✅ Mot de passe réinitialisé : toutes les sessions sont fermées
    await this.sessions?.revokeAllForUser(user.id, SessionRevokeReason.PASSWORD_RESET);

    return {
      message: await this.i18n.translate('user.password_reset_success', lang),
    };
  }

  async verifyOtp(
    email: string,
    otpCode: string,
    lang: string = 'fr',
  ): Promise<{ message: string }> {
    if (!email)
      throw new BadRequestException(
        await this.i18n.translate('user.email_or_phone_required', lang),
      );

    const otpEntry = await this.otpRepository.findOne({
      where: { email, otpCode, isUsed: false, expiresAt: MoreThan(new Date()) },
    });
    if (!otpEntry)
      throw new BadRequestException(
        await this.i18n.translate('user.otp_invalid', lang),
      );

    await this.otpRepository.save(otpEntry);
    return { message: await this.i18n.translate('user.otp_validated', lang) };
  }

  async getFullProfile(
    userId: string,
    lang: string = 'fr',
    platform?: string, // ✅ NOUVEAU paramètre
  ): Promise<Record<string, any>> {
    let user = await this.hydrateUser(
      this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('company.settings', 'companySettings')
      .leftJoinAndSelect('company.invoiceConfiguration', 'invoiceConfiguration')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('defaultAddress.country', 'defaultAddressCountry')
      .leftJoinAndSelect('defaultAddress.city', 'defaultAddressCity')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.activeBranch', 'activeBranch')
      .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
      .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
      .leftJoinAndSelect('users.loyalty', 'loyalty')
      .leftJoinAndSelect('users.referrals', 'referrals')
      .leftJoinAndSelect('users.referrer', 'referrer')
      .where('users.id = :id', { id: userId })
      ,
      UsersService.PROFILE_GRAPH,
    );

    if (!user) throw new NotFoundException(await this.i18n.translate('user.user_not_found', lang));

    // ============================================================
    // ✅ SÉLECTION DE L'ENTREPRISE ACTIVE SELON x-platform
    //    admin → FavorHelp | group → FavorGroup
    // ============================================================
    await this.applyActiveCompanyByPlatform(user, platform);

    // ============================================================
    // 🔥 GARANTIR LE referralCode ET LE COMPTE FIDÉLITÉ
    // ✅ OPTIMISATION : plus de reload, assignation locale
    // ============================================================

    if (!user.referralCode || user.referralCode.trim() === '') {
      console.warn(`⚠️ [getFullProfile] Utilisateur ${user.id} sans referralCode, génération...`);

      // ✅ OPTIMISATION : utilise directement generateReferralCode
      const newCode = await this.generateReferralCode(user.id);

      if (!newCode || newCode.trim() === '') {
        console.error(`❌ [getFullProfile] Impossible de générer un referralCode pour ${user.id}`);
        throw new InternalServerErrorException(
          await this.i18n.translate('user.referral_code_generation_failed', lang),
        );
      }

      user.referralCode = newCode;
      await this.usersRepository.save(user);
      console.log(`✅ [getFullProfile] referralCode généré: ${newCode}`);
    }

    if (!user.loyalty || user.loyalty.length === 0) {
      const loyalty = await this.getOrCreateLoyaltyAccount(user.id);
      await this.loyaltyRepository.save(loyalty);

      // ✅ OPTIMISATION : assignation directe (plus de reload)
      user.loyalty = [loyalty];
    }

    const { password, ...userWithoutPassword } = user;

    // ✅ userHasCompany : ajout settings + invoiceConfiguration
    const userHasCompany = (userWithoutPassword.userHasCompany || []).map(
      (uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,
        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,
            settings: (uhc.company as any).settings ?? null,
            invoiceConfiguration:
              (uhc.company as any).invoiceConfiguration ?? null,
            branches: (uhc.company.branches || []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,
              country: b.country
                ? { id: b.country.id, name: b.country.name }
                : null,
              city: b.city ? { id: b.city.id, name: b.city.name } : null,
            })),
          }
          : null,
        branch: uhc.branch
          ? { id: uhc.branch.id, name: uhc.branch.name }
          : null,
        userResources: (uhc.resources || []).map((r) => ({
          id: r.id,
          canCreate: r.canCreate,
          canRead: r.canRead,
          canUpdate: r.canUpdate,
          canDelete: r.canDelete,
          canManage: r.canManage,
          status: r.status,
          resource: r.resource
            ? {
              id: r.resource.id,
              name: r.resource.name,
              label: r.resource.label,
            }
            : null,
        })),
      }),
    );

    // ============================================================
    // ✅ OPTIMISATION : activeCompany calculée depuis user.userHasCompany
    //    (plus de requête activeCompanyRaw)
    // ============================================================
    const activeUserHasCompany = user.userHasCompany?.find(
      (uhc) => uhc.company?.id === user.activeCompanyId,
    );
    const activeCompanyEntity = activeUserHasCompany?.company ?? null;
    const activeCompanyBranch = activeUserHasCompany?.branch
      ? {
        id: activeUserHasCompany.branch.id,
        name: activeUserHasCompany.branch.name,
      }
      : null;

    const userResourcesForActiveCompany = (
      activeUserHasCompany?.resources || []
    ).map((r) => ({
      id: r.id,
      canCreate: r.canCreate,
      canRead: r.canRead,
      canUpdate: r.canUpdate,
      canDelete: r.canDelete,
      canManage: r.canManage,
      status: r.status,
      resource: r.resource
        ? {
          id: r.resource.id,
          name: r.resource.name,
          label: r.resource.label,
        }
        : null,
    }));

    // ✅ activeCompany : ajout settings + invoiceConfiguration
    const activeCompany = activeCompanyEntity
      ? {
        ...activeCompanyEntity,
        tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
        country: activeCompanyEntity.country ?? null,
        city: activeCompanyEntity.city ?? null,
        category: activeCompanyEntity.category ?? null,
        settings: (activeCompanyEntity as any).settings ?? null,
        invoiceConfiguration:
          (activeCompanyEntity as any).invoiceConfiguration ?? null,
        branch: activeCompanyBranch,
        companyResources: (activeCompanyEntity.companyResources || []).map(
          (cr) => ({
            id: cr.id,
            canCreate: cr.can_create,
            canRead: cr.can_read,
            canUpdate: cr.can_update,
            canDelete: cr.can_delete,
            canManage: cr.can_manage,
            status: cr.status,
            resource: cr.resource
              ? {
                id: cr.resource.id,
                name: cr.resource.name,
                label: cr.resource.label,
              }
              : null,
          }),
        ),
        userResources: userResourcesForActiveCompany,
        branches: (activeCompanyEntity.branches || []).map((b) => ({
          id: b.id,
          name: b.name,
          address: b.address,
          phone: b.phone,
          email: b.email,
          status: b.status,
          deleted: b.deleted,
          country: b.country
            ? { id: b.country.id, name: b.country.name }
            : null,
          city: b.city ? { id: b.city.id, name: b.city.name } : null,
        })),
      }
      : null;

    const userPlatformRoles = (userWithoutPassword.userPlatformRoles || []).map(
      (upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      }),
    );

    const defaultAddress = userWithoutPassword.defaultAddress
      ? {
        id: userWithoutPassword.defaultAddress.id,
        firstName: userWithoutPassword.defaultAddress.firstName,
        lastName: userWithoutPassword.defaultAddress.lastName,
        address: userWithoutPassword.defaultAddress.address,
        phone: userWithoutPassword.defaultAddress.phone,
        type: userWithoutPassword.defaultAddress.type,
        isDefault: userWithoutPassword.defaultAddress.isDefault,
        latitude: userWithoutPassword.defaultAddress.latitude,
        longitude: userWithoutPassword.defaultAddress.longitude,
        countryId: userWithoutPassword.defaultAddress.countryId,
        cityId: userWithoutPassword.defaultAddress.cityId,
        createdAt: userWithoutPassword.defaultAddress.createdAt,
        updatedAt: userWithoutPassword.defaultAddress.updatedAt,
        country: userWithoutPassword.defaultAddress.country
          ? {
            id: userWithoutPassword.defaultAddress.country.id,
            name: userWithoutPassword.defaultAddress.country.name,
            code: userWithoutPassword.defaultAddress.country.code,
            status: userWithoutPassword.defaultAddress.country.status,
            createdAt: userWithoutPassword.defaultAddress.country.createdAt,
            updatedAt: userWithoutPassword.defaultAddress.country.updatedAt,
            flag: userWithoutPassword.defaultAddress.country.flag,
          }
          : null,
        city: userWithoutPassword.defaultAddress.city
          ? {
            id: userWithoutPassword.defaultAddress.city.id,
            name: userWithoutPassword.defaultAddress.city.name,
          }
          : null,
      }
      : null;

    const activeBranch = userWithoutPassword.activeBranch
      ? {
        id: userWithoutPassword.activeBranch.id,
        name: userWithoutPassword.activeBranch.name,
        address: userWithoutPassword.activeBranch.address,
        phone: userWithoutPassword.activeBranch.phone,
        email: userWithoutPassword.activeBranch.email,
        status: userWithoutPassword.activeBranch.status,
        deleted: userWithoutPassword.activeBranch.deleted,
        country: userWithoutPassword.activeBranch.country
          ? {
            id: userWithoutPassword.activeBranch.country.id,
            name: userWithoutPassword.activeBranch.country.name,
          }
          : null,
        city: userWithoutPassword.activeBranch.city
          ? {
            id: userWithoutPassword.activeBranch.city.id,
            name: userWithoutPassword.activeBranch.city.name,
          }
          : null,
      }
      : null;

    const referralData = {
      referralCode: user.referralCode,
      referralCount: user.referralCount || 0,
      referralPoints: user.referralPoints || 0,
      referredBy: user.referredBy,
      referrerName: user.referrer?.fullName || null,
      referralActive: user.referralActive !== false,
      totalReferrals: user.referrals?.length || 0,
    };

    return instanceToPlain({
      ...userWithoutPassword,
      userHasCompany,
      activeCompany,
      userPlatformRoles,
      defaultAddress,
      activeBranch,
      loyalty: {
        points: user.loyalty?.[0]?.pointsBalance ?? 0,
        tier: user.loyalty?.[0]?.currentTier ?? null,
        code: user.loyalty?.[0]?.loyaltyCode ?? null,
      },
      referral: referralData,
    });
  }

  async accessToken(user: UserEntity): Promise<string> {
    // ✅ Horaires de travail : aucun jeton émis en dehors des heures autorisées (connexion, Google, Apple, renouvellement…)
    await this.workSchedules?.assertCanIssueToken(user);
    // ✅ Session de connexion inscrite dans le jeton (sid) : la fermer invalide le jeton immédiatement
    const sid = (await this.sessions?.sidForIssue(user)) ?? null;
    const payload: Record<string, any> = {
      id: user.id,
      email: user.email,
      role: user.role,
    };
    if (sid) payload.sid = sid;

    const secretKey = this.configService.get<string>('ACCESS_TOKEN_SECRET_KEY');
    if (!secretKey) {
      throw new Error('ACCESS_TOKEN_SECRET_KEY is not defined!');
    }

    return await this.jwtService.signAsync(payload, {
      expiresIn: '48h',
      secret: secretKey,
    });
  }

  async refreshToken(user: UserEntity): Promise<string> {
    await this.workSchedules?.assertCanIssueToken(user);
    const sid = (await this.sessions?.sidForIssue(user)) ?? null;
    const payload: Record<string, any> = {
      id: user.id,
      email: user.email,
      role: user.role,
    };
    if (sid) payload.sid = sid;

    const secretKey = this.configService.get<string>(
      'REFRESH_TOKEN_SECRET_KEY',
    );
    if (!secretKey) {
      throw new Error('REFRESH_TOKEN_SECRET_KEY is not defined!');
    }

    const token = await this.jwtService.signAsync(payload, {
      expiresIn: '7d',
      secret: secretKey,
    });
    // ✅ Empreinte du refresh token enregistrée dans la session (rotation, détection de réutilisation)
    if (sid) await this.sessions?.attachRefresh(sid, token);
    return token;
  }

  async refreshTokenWithValidation(
    refresh_token: string,
    lang: string = 'fr',
  ): Promise<{ accessToken: string; refreshToken: string }> {
    if (!refresh_token) {
      throw new BadRequestException(
        await this.i18n.translate('user.refresh_token_required', lang),
      );
    }

    const secret = this.configService.get<string>('REFRESH_TOKEN_SECRET_KEY');
    if (!secret) {
      throw new Error('REFRESH_TOKEN_SECRET_KEY is not defined in .env');
    }

    let decoded: any;
    try {
      decoded = await this.jwtService.verifyAsync(refresh_token, { secret });
    } catch (err) {
      throw new BadRequestException(
        await this.i18n.translate('user.invalid_refresh_token', lang),
      );
    }

    const user = await this.usersRepository.findOne({
      where: { id: decoded.id },
    });
    if (!user) {
      throw new BadRequestException(
        await this.i18n.translate('user.user_not_found', lang),
      );
    }

    // ✅ Session : fermée / expirée / jeton déjà utilisé → refus ; sinon les nouveaux jetons gardent la même session
    if (this.sessions) {
      const sid = await this.sessions.validateRefresh(decoded, refresh_token, lang);
      if (sid) this.sessions.useForRequest(user.id, sid);
    }

    const newAccessToken = await this.accessToken(user);
    const newRefreshToken = await this.refreshToken(user);

    return {
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
    };
  }

  generateSecret(email: string) {
    return speakeasy.generateSecret({ name: `FavorApp (${email})` });
  }

  async generateQrCode(otpauthUrl: string): Promise<string> {
    return await qrcode.toDataURL(otpauthUrl);
  }

  async verifyToken(
    secret: string,
    token: string,
    lang?: string,
  ): Promise<boolean> {
    return speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token,
      window: 60,
    });
  }

  async findById(userId: string, lang: string = 'fr'): Promise<UserEntity> {
    const user = await this.usersRepository.findOne({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException(await this.i18n.translate('user.user_not_found', lang));
    }
    return user;
  }

  async getOne(
    userId: string,
    lang: string = 'fr',
  ): Promise<{
    message: string;
    data: any;
  }> {
    const user = await this.hydrateUser(
      this.usersRepository
      .createQueryBuilder('users')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .where('users.id = :userId', { userId })
      ,
      UsersService.USER_GRAPH,
    );

    if (!user) {
      throw new NotFoundException(
        await this.i18n.translate(
          'user.user_not_found',
          lang,
        ),
      );
    }

    const { password, ...userWithoutPassword } = user;

    const userHasCompany = (
      userWithoutPassword.userHasCompany || []
    ).map((uhc) => ({
      id: uhc.id,
      isOwner: uhc.isOwner,

      company: uhc.company
        ? {
          ...uhc.company,
          tauxCompanies: uhc.company.tauxCompanies ?? [],
          country: uhc.company.country ?? null,
          city: uhc.company.city ?? null,
          category: uhc.company.category ?? null,

          branches: (uhc.company.branches || []).map((b) => ({
            id: b.id,
            name: b.name,
            address: b.address,
            phone: b.phone,
            email: b.email,
            status: b.status,
            deleted: b.deleted,

            country: b.country
              ? {
                id: b.country.id,
                name: b.country.name,
              }
              : null,

            city: b.city
              ? {
                id: b.city.id,
                name: b.city.name,
              }
              : null,
          })),
        }
        : null,

      branch: uhc.branch
        ? {
          id: uhc.branch.id,
          name: uhc.branch.name,
        }
        : null,

      userResources: (uhc.resources || []).map((r) => ({
        id: r.id,
        canCreate: r.canCreate,
        canRead: r.canRead,
        canUpdate: r.canUpdate,
        canDelete: r.canDelete,
        canManage: r.canManage,
        status: r.status,

        resource: r.resource
          ? {
            id: r.resource.id,
            name: r.resource.name,
            label: r.resource.label,
          }
          : null,
      })),
    }));

    const activeUserHasCompany =
      userWithoutPassword.userHasCompany?.find(
        (uhc) =>
          uhc.company?.id ===
          userWithoutPassword.activeCompanyId,
      );

    const activeCompanyEntity =
      activeUserHasCompany?.company ?? null;

    const activeCompany = activeCompanyEntity
      ? {
        ...activeCompanyEntity,

        tauxCompanies:
          activeCompanyEntity.tauxCompanies ?? [],

        country:
          activeCompanyEntity.country ?? null,

        city:
          activeCompanyEntity.city ?? null,

        category:
          activeCompanyEntity.category ?? null,

        branch: activeUserHasCompany?.branch
          ? {
            id: activeUserHasCompany.branch.id,
            name: activeUserHasCompany.branch.name,
          }
          : null,

        companyResources: (
          activeCompanyEntity.companyResources || []
        ).map((cr) => ({
          id: cr.id,
          canCreate: cr.can_create,
          canRead: cr.can_read,
          canUpdate: cr.can_update,
          canDelete: cr.can_delete,
          canManage: cr.can_manage,
          status: cr.status,

          resource: cr.resource
            ? {
              id: cr.resource.id,
              name: cr.resource.name,
              label: cr.resource.label,
            }
            : null,
        })),

        userResources: (
          activeUserHasCompany?.resources || []
        ).map((r) => ({
          id: r.id,
          canCreate: r.canCreate,
          canRead: r.canRead,
          canUpdate: r.canUpdate,
          canDelete: r.canDelete,
          canManage: r.canManage,
          status: r.status,

          resource: r.resource
            ? {
              id: r.resource.id,
              name: r.resource.name,
              label: r.resource.label,
            }
            : null,
        })),

        branches: (
          activeCompanyEntity.branches || []
        ).map((b) => ({
          id: b.id,
          name: b.name,
          address: b.address,
          phone: b.phone,
          email: b.email,
          status: b.status,
          deleted: b.deleted,

          country: b.country
            ? {
              id: b.country.id,
              name: b.country.name,
            }
            : null,

          city: b.city
            ? {
              id: b.city.id,
              name: b.city.name,
            }
            : null,
        })),
      }
      : null;

    const userPlatformRoles = (
      userWithoutPassword.userPlatformRoles || []
    ).map((upr: any) => ({
      id: upr.id,
      platform: upr.platform,
      role: upr.role,
    }));

    const defaultAddress =
      userWithoutPassword.defaultAddress
        ? {
          id: userWithoutPassword.defaultAddress.id,
          firstName:
            userWithoutPassword.defaultAddress.firstName,
          lastName:
            userWithoutPassword.defaultAddress.lastName,
          address:
            userWithoutPassword.defaultAddress.address,
          phone:
            userWithoutPassword.defaultAddress.phone,
          type:
            userWithoutPassword.defaultAddress.type,
          isDefault:
            userWithoutPassword.defaultAddress.isDefault,
          latitude:
            userWithoutPassword.defaultAddress.latitude,
          longitude:
            userWithoutPassword.defaultAddress.longitude,
          createdAt:
            userWithoutPassword.defaultAddress.createdAt,
          updatedAt:
            userWithoutPassword.defaultAddress.updatedAt,
        }
        : null;

    const data = instanceToPlain({
      ...userWithoutPassword,
      userHasCompany,
      activeCompany,
      userPlatformRoles,
      defaultAddress,
    });

    return {
      message: await this.i18n.translate(
        'user.user_found',
        lang,
      ),
      data,
    };
  }

  async set2FASecret(
    userId: string,
    secret: string,
    lang?: string,
  ): Promise<void> {
    await this.usersRepository.update(userId, { twoFASecret: secret });
  }

  async enable2FA(userId: string, lang: string = 'fr'): Promise<void> {
    const user = await this.usersRepository.findOne({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException(await this.i18n.translate('user.user_not_found', lang));
    }
    user.isTwoFAEnabled = true;
    await this.usersRepository.save(user);
  }

  async findAll(role?: string): Promise<any[]> {
    const roles = Object.values(UserRole);
    let queryBuilder = this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.loyalty', 'loyalty')
      .orderBy('users.createdAt', 'DESC');

    if (role && roles.includes(role as UserRole)) {
      queryBuilder = queryBuilder.where('users.role = :role', { role });
    }

    // ✅ Optimisé : identifiants d'abord, relations ensuite par lots (évite l'explosion des jointures)
    const users = await this.hydrateUsers(queryBuilder, { ...UsersService.USER_GRAPH, loyalty: true });

    const sanitizedUsers = users.map((user) => {
      const { password, ...userWithoutPassword } = user;

      const userHasCompany = (userWithoutPassword.userHasCompany || []).map(
        (uhc) => ({
          id: uhc.id,
          isOwner: uhc.isOwner,
          company: uhc.company
            ? {
              ...uhc.company,
              tauxCompanies: uhc.company.tauxCompanies ?? [],
              country: uhc.company.country ?? null,
              city: uhc.company.city ?? null,
              category: uhc.company.category ?? null,
              branches: (uhc.company.branches || []).map((b) => ({
                id: b.id,
                name: b.name,
                address: b.address,
                phone: b.phone,
                email: b.email,
                status: b.status,
                deleted: b.deleted,
                country: b.country
                  ? { id: b.country.id, name: b.country.name }
                  : null,
                city: b.city ? { id: b.city.id, name: b.city.name } : null,
              })),
            }
            : null,
          branch: uhc.branch
            ? { id: uhc.branch.id, name: uhc.branch.name }
            : null,
          userResources: (uhc.resources || []).map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,
            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })),
        }),
      );

      // Reconstruire activeCompany avec sa branche
      const activeUserHasCompany = userWithoutPassword.userHasCompany?.find(
        (uhc) => uhc.company?.id === userWithoutPassword.activeCompanyId,
      );
      const activeCompanyEntity = activeUserHasCompany?.company ?? null;
      const activeCompanyBranch = activeUserHasCompany?.branch
        ? {
          id: activeUserHasCompany.branch.id,
          name: activeUserHasCompany.branch.name,
        }
        : null;

      const activeCompany = activeCompanyEntity
        ? {
          ...activeCompanyEntity,
          tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
          country: activeCompanyEntity.country ?? null,
          city: activeCompanyEntity.city ?? null,
          category: activeCompanyEntity.category ?? null,
          branch: activeCompanyBranch,
          companyResources: (activeCompanyEntity.companyResources || []).map(
            (cr) => ({
              id: cr.id,
              canCreate: cr.can_create,
              canRead: cr.can_read,
              canUpdate: cr.can_update,
              canDelete: cr.can_delete,
              canManage: cr.can_manage,
              status: cr.status,
              resource: cr.resource
                ? {
                  id: cr.resource.id,
                  name: cr.resource.name,
                  label: cr.resource.label,
                }
                : null,
            }),
          ),
          userResources: (activeUserHasCompany?.resources || []).map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,
            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })),
          branches: (activeCompanyEntity.branches || []).map((b) => ({
            id: b.id,
            name: b.name,
            address: b.address,
            phone: b.phone,
            email: b.email,
            status: b.status,
            deleted: b.deleted,
            country: b.country
              ? { id: b.country.id, name: b.country.name }
              : null,
            city: b.city ? { id: b.city.id, name: b.city.name } : null,
          })),
        }
        : null;

      const userPlatformRoles = (
        userWithoutPassword.userPlatformRoles || []
      ).map((upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      }));

      const defaultAddress = userWithoutPassword.defaultAddress
        ? {
          id: userWithoutPassword.defaultAddress.id,
          firstName: userWithoutPassword.defaultAddress.firstName,
          lastName: userWithoutPassword.defaultAddress.lastName,
          address: userWithoutPassword.defaultAddress.address,
          phone: userWithoutPassword.defaultAddress.phone,
          type: userWithoutPassword.defaultAddress.type,
          isDefault: userWithoutPassword.defaultAddress.isDefault,
          latitude: userWithoutPassword.defaultAddress.latitude,
          longitude: userWithoutPassword.defaultAddress.longitude,
          createdAt: userWithoutPassword.defaultAddress.createdAt,
          updatedAt: userWithoutPassword.defaultAddress.updatedAt,
        }
        : null;

      return instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        activeCompany,
        userPlatformRoles,
        defaultAddress,
        loyalty: {
          points: user.loyalty?.[0]?.pointsBalance ?? 0,
          tier: user.loyalty?.[0]?.currentTier ?? null,
          code: user.loyalty?.[0]?.loyaltyCode ?? null,
        },
      });
    });

    return sanitizedUsers;
  }

  // ==================== findAllWithDetails ====================
  async findAllWithDetails(
    role?: UserRole,
    hasOrder?: boolean,
    hasShipment?: boolean,
    search?: string,
  ) {
    const query = this.usersRepository
      .createQueryBuilder('users')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      );

    // FILTRE PAR RÔLE
    if (role) {
      query.andWhere('users.role = :role', { role });
    }

    // RECHERCHE
    if (search && search.trim()) {
      const keyword = `%${search.trim()}%`;

      query.andWhere(
        `(
        users.fullName LIKE :keyword
        OR users.email LIKE :keyword
        OR users.phone LIKE :keyword
      )`,
        { keyword },
      );
    }

    // UTILISATEURS AYANT AU MOINS UNE COMMANDE
    if (hasOrder === true) {
      query.andWhere(`
      EXISTS (
        SELECT 1
        FROM orders order_filter
        WHERE order_filter.userId = users.id
      )
    `);
    }

    // UTILISATEURS AYANT AU MOINS UN SHIPMENT
    // Aucun filtre sur LTA
    if (hasShipment === true) {
      query.andWhere(`
      EXISTS (
        SELECT 1
        FROM shipments shipment_filter
        WHERE shipment_filter.userId = users.id
      )
    `);
    }

    query.orderBy('users.createdAt', 'DESC');

    // ✅ Optimisé : identifiants d'abord, relations ensuite par lots (évite l'explosion des jointures)
    const users = await this.hydrateUsers(query, UsersService.USER_GRAPH);

    const sanitizedUsers = users.map((user) => {
      const { password, ...userWithoutPassword } = user;

      const userHasCompany = (
        userWithoutPassword.userHasCompany || []
      ).map((uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,

        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,

            branches: (uhc.company.branches || []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,

              country: b.country
                ? {
                  id: b.country.id,
                  name: b.country.name,
                }
                : null,

              city: b.city
                ? {
                  id: b.city.id,
                  name: b.city.name,
                }
                : null,
            })),
          }
          : null,

        branch: uhc.branch
          ? {
            id: uhc.branch.id,
            name: uhc.branch.name,
          }
          : null,

        userResources: (uhc.resources || []).map((r) => ({
          id: r.id,
          canCreate: r.canCreate,
          canRead: r.canRead,
          canUpdate: r.canUpdate,
          canDelete: r.canDelete,
          canManage: r.canManage,
          status: r.status,

          resource: r.resource
            ? {
              id: r.resource.id,
              name: r.resource.name,
              label: r.resource.label,
            }
            : null,
        })),
      }));

      const activeUserHasCompany =
        userWithoutPassword.userHasCompany?.find(
          (uhc) =>
            uhc.company?.id === userWithoutPassword.activeCompanyId,
        );

      const activeCompanyEntity =
        activeUserHasCompany?.company ?? null;

      const activeCompanyBranch = activeUserHasCompany?.branch
        ? {
          id: activeUserHasCompany.branch.id,
          name: activeUserHasCompany.branch.name,
        }
        : null;

      const activeCompany = activeCompanyEntity
        ? {
          ...activeCompanyEntity,

          tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
          country: activeCompanyEntity.country ?? null,
          city: activeCompanyEntity.city ?? null,
          category: activeCompanyEntity.category ?? null,

          branch: activeCompanyBranch,

          companyResources: (
            activeCompanyEntity.companyResources || []
          ).map((cr) => ({
            id: cr.id,
            canCreate: cr.can_create,
            canRead: cr.can_read,
            canUpdate: cr.can_update,
            canDelete: cr.can_delete,
            canManage: cr.can_manage,
            status: cr.status,

            resource: cr.resource
              ? {
                id: cr.resource.id,
                name: cr.resource.name,
                label: cr.resource.label,
              }
              : null,
          })),

          userResources: (
            activeUserHasCompany?.resources || []
          ).map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,

            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })),

          branches: (
            activeCompanyEntity.branches || []
          ).map((b) => ({
            id: b.id,
            name: b.name,
            address: b.address,
            phone: b.phone,
            email: b.email,
            status: b.status,
            deleted: b.deleted,

            country: b.country
              ? {
                id: b.country.id,
                name: b.country.name,
              }
              : null,

            city: b.city
              ? {
                id: b.city.id,
                name: b.city.name,
              }
              : null,
          })),
        }
        : null;

      const userPlatformRoles = (
        userWithoutPassword.userPlatformRoles || []
      ).map((upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      }));

      const defaultAddress = userWithoutPassword.defaultAddress
        ? {
          id: userWithoutPassword.defaultAddress.id,
          firstName: userWithoutPassword.defaultAddress.firstName,
          lastName: userWithoutPassword.defaultAddress.lastName,
          address: userWithoutPassword.defaultAddress.address,
          phone: userWithoutPassword.defaultAddress.phone,
          type: userWithoutPassword.defaultAddress.type,
          isDefault: userWithoutPassword.defaultAddress.isDefault,
          latitude: userWithoutPassword.defaultAddress.latitude,
          longitude: userWithoutPassword.defaultAddress.longitude,
          createdAt: userWithoutPassword.defaultAddress.createdAt,
          updatedAt: userWithoutPassword.defaultAddress.updatedAt,
        }
        : null;

      return instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        activeCompany,
        userPlatformRoles,
        defaultAddress,
      });
    });

    return sanitizedUsers;
  }

  async findAllWithDetailsPaginate(
    page: number = 1,
    limit: number = 10,
    role?: UserRole,
    hasOrder?: boolean,
    hasShipment?: boolean,
    search?: string,
  ): Promise<{ data: PaginatedResponseDto<any> }> {
    const query = this.usersRepository
      .createQueryBuilder('users')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      );

    // FILTRE PAR RÔLE
    if (role) {
      query.andWhere('users.role = :role', { role });
    }

    // RECHERCHE
    if (search && search.trim()) {
      const keyword = `%${search.trim()}%`;

      query.andWhere(
        `(
        users.fullName LIKE :keyword
        OR users.email LIKE :keyword
        OR users.phone LIKE :keyword
      )`,
        { keyword },
      );
    }

    // UTILISATEURS AYANT AU MOINS UNE COMMANDE
    if (hasOrder === true) {
      query.andWhere(`
      EXISTS (
        SELECT 1
        FROM orders order_filter
        WHERE order_filter.userId = users.id
      )
    `);
    }

    // UTILISATEURS AYANT AU MOINS UN SHIPMENT
    // Aucun filtre sur LTA
    if (hasShipment === true) {
      query.andWhere(`
      EXISTS (
        SELECT 1
        FROM shipments shipment_filter
        WHERE shipment_filter.userId = users.id
      )
    `);
    }

    const skip = (page - 1) * limit;

    query
      .orderBy('users.createdAt', 'DESC')
      .skip(skip)
      .take(limit);

    // ✅ Optimisé : page d'identifiants d'abord, relations ensuite par lots (évite l'explosion des jointures)
    const [users, total] = await this.hydrateUsersAndCount(query, UsersService.USER_GRAPH);

    const sanitizedUsers = users.map((user) => {
      const { password, ...userWithoutPassword } = user;

      const userHasCompany = (
        userWithoutPassword.userHasCompany || []
      ).map((uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,

        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,

            branches: (uhc.company.branches || []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,

              country: b.country
                ? {
                  id: b.country.id,
                  name: b.country.name,
                }
                : null,

              city: b.city
                ? {
                  id: b.city.id,
                  name: b.city.name,
                }
                : null,
            })),
          }
          : null,

        branch: uhc.branch
          ? {
            id: uhc.branch.id,
            name: uhc.branch.name,
          }
          : null,

        userResources: (uhc.resources || []).map((r) => ({
          id: r.id,
          canCreate: r.canCreate,
          canRead: r.canRead,
          canUpdate: r.canUpdate,
          canDelete: r.canDelete,
          canManage: r.canManage,
          status: r.status,

          resource: r.resource
            ? {
              id: r.resource.id,
              name: r.resource.name,
              label: r.resource.label,
            }
            : null,
        })),
      }));

      const activeUserHasCompany =
        userWithoutPassword.userHasCompany?.find(
          (uhc) =>
            uhc.company?.id === userWithoutPassword.activeCompanyId,
        );

      const activeCompanyEntity =
        activeUserHasCompany?.company ?? null;

      const activeCompanyBranch = activeUserHasCompany?.branch
        ? {
          id: activeUserHasCompany.branch.id,
          name: activeUserHasCompany.branch.name,
        }
        : null;

      const activeCompany = activeCompanyEntity
        ? {
          ...activeCompanyEntity,

          tauxCompanies: activeCompanyEntity.tauxCompanies ?? [],
          country: activeCompanyEntity.country ?? null,
          city: activeCompanyEntity.city ?? null,
          category: activeCompanyEntity.category ?? null,

          branch: activeCompanyBranch,

          companyResources: (
            activeCompanyEntity.companyResources || []
          ).map((cr) => ({
            id: cr.id,
            canCreate: cr.can_create,
            canRead: cr.can_read,
            canUpdate: cr.can_update,
            canDelete: cr.can_delete,
            canManage: cr.can_manage,
            status: cr.status,

            resource: cr.resource
              ? {
                id: cr.resource.id,
                name: cr.resource.name,
                label: cr.resource.label,
              }
              : null,
          })),

          userResources: (
            activeUserHasCompany?.resources || []
          ).map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,

            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })),

          branches: (
            activeCompanyEntity.branches || []
          ).map((b) => ({
            id: b.id,
            name: b.name,
            address: b.address,
            phone: b.phone,
            email: b.email,
            status: b.status,
            deleted: b.deleted,

            country: b.country
              ? {
                id: b.country.id,
                name: b.country.name,
              }
              : null,

            city: b.city
              ? {
                id: b.city.id,
                name: b.city.name,
              }
              : null,
          })),
        }
        : null;

      const userPlatformRoles = (
        userWithoutPassword.userPlatformRoles || []
      ).map((upr: any) => ({
        id: upr.id,
        platform: upr.platform,
        role: upr.role,
      }));

      const defaultAddress = userWithoutPassword.defaultAddress
        ? {
          id: userWithoutPassword.defaultAddress.id,
          firstName: userWithoutPassword.defaultAddress.firstName,
          lastName: userWithoutPassword.defaultAddress.lastName,
          address: userWithoutPassword.defaultAddress.address,
          phone: userWithoutPassword.defaultAddress.phone,
          type: userWithoutPassword.defaultAddress.type,
          isDefault: userWithoutPassword.defaultAddress.isDefault,
          latitude: userWithoutPassword.defaultAddress.latitude,
          longitude: userWithoutPassword.defaultAddress.longitude,
          createdAt: userWithoutPassword.defaultAddress.createdAt,
          updatedAt: userWithoutPassword.defaultAddress.updatedAt,
        }
        : null;

      return instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        activeCompany,
        userPlatformRoles,
        defaultAddress,
      });
    });

    return {
      data: new PaginatedResponseDto(
        sanitizedUsers,
        total,
        page,
        limit,
      ),
    };
  }
  // ============================================================
  // 🔄 CHANGER LE RÔLE D'UN UTILISATEUR
  // ============================================================
  async changeUserRole(
    targetUserId: string,
    newRole: UserRole,
    currentUser: UserEntity,       // utilisateur qui effectue l'action
    lang: string = 'fr',
    reason?: string,
  ) {

    // ============================================================
    // 1. Récupérer l'utilisateur cible
    // ============================================================
    const targetUser = await this.usersRepository.findOne({
      where: { id: targetUserId },
    });

    if (!targetUser) {
      throw new NotFoundException(
        await this.i18n.translate('user.not_found', lang),
      );
    }

    // ============================================================
    // 2. Vérifications de sécurité
    // ============================================================

    // âŒ Interdire de changer son propre rôle
    if (targetUser.id === currentUser.id) {
      throw new BadRequestException(
        await this.i18n.translate('user.cannot_change_own_role', lang),
      );
    }

    // âŒ Interdire de modifier un SUPER_ADMIN (sauf par un SUPER_ADMIN lui-même)
    if (
      targetUser.role === UserRole.SUPER_ADMIN &&
      currentUser.role !== UserRole.SUPER_ADMIN
    ) {
      throw new ForbiddenException(
        await this.i18n.translate('user.cannot_modify_super_admin', lang),
      );
    }

    // âŒ Interdire de promouvoir quelqu'un en SUPER_ADMIN (sauf SUPER_ADMIN)
    if (
      newRole === UserRole.SUPER_ADMIN &&
      currentUser.role !== UserRole.SUPER_ADMIN
    ) {
      throw new ForbiddenException(
        await this.i18n.translate('user.cannot_promote_super_admin', lang),
      );
    }

    // âŒ Interdire un rôle identique (pas de changement inutile)
    if (targetUser.role === newRole) {
      throw new BadRequestException(
        await this.i18n.translate('user.same_role', lang, { role: newRole }),
      );
    }

    // ============================================================
    // 3. Appliquer le changement
    // ============================================================
    const oldRole = targetUser.role;
    targetUser.role = newRole;

    const updated = await this.usersRepository.save(targetUser);

    // 4. (Optionnel) Log d'audit
    // ============================================================

    return {
      message: await this.i18n.translate('user.role_changed', lang, {
        fullName: updated.fullName,
        role: newRole,
      }),
      data: {
        id: updated.id,
        fullName: updated.fullName,
        email: updated.email,
        newRole: updated.role,
        updatedAt: updated.updatedAt,
      },
    };
  }

  // ============================================================
  // ✅ CHARGEMENT OPTIMISÉ DES UTILISATEURS ET DE LEURS RELATIONS
  // Une seule requête à 16-26 jointures multiplie les lignes (entreprises × filiales × ressources × taux…).
  // On récupère d'abord les identifiants (filtres, tri, pagination sur la table users seule),
  // puis chaque relation en une requête groupée (relationLoadStrategy « query »). Résultat identique.
  // ============================================================
  static readonly USER_GRAPH: FindOptionsRelations<UserEntity> = {
    userHasCompany: {
      branch: true,
      company: {
        tauxCompanies: true,
        country: true,
        city: true,
        category: true,
        companyResources: { resource: true },
        branches: true,
      },
      resources: { resource: true },
    },
    userPlatformRoles: { platform: true, role: true },
    defaultAddress: true,
  } as any;

  static readonly PROFILE_GRAPH: FindOptionsRelations<UserEntity> = {
    userHasCompany: {
      branch: true,
      company: {
        tauxCompanies: true,
        country: true,
        city: true,
        category: true,
        companyResources: { resource: true },
        branches: true,
        settings: true,
        invoiceConfiguration: true,
      },
      resources: { resource: true },
    },
    userPlatformRoles: { platform: true, role: true },
    defaultAddress: { country: true, city: true },
    activeBranch: { country: true, city: true },
    loyalty: true,
    referrals: true,
    referrer: true,
  } as any;

  /** Requête d'identifiants : mêmes filtres / tri / pagination, sans les jointures (les filtres ne portent que sur users) */
  private idQuery(qb: SelectQueryBuilder<UserEntity>): SelectQueryBuilder<UserEntity> {
    const idQb = qb.clone();
    idQb.expressionMap.joinAttributes = [];
    idQb.expressionMap.relationIdAttributes = [];
    idQb.expressionMap.relationCountAttributes = [];
    return idQb.select(['users.id', 'users.createdAt']);
  }

  private async loadGraph(ids: string[], relations: FindOptionsRelations<UserEntity>): Promise<UserEntity[]> {
    if (!ids.length) return [];
    // ⚠️ Relations de users vers users (parrain / filleuls) : TypeORM réutilise l'alias « UserEntity »
    //    en mode « query » (ER_NONUNIQ_TABLE) → chargées à part, par lots.
    const { referrer: wantReferrer, referrals: wantReferrals, ...rest } = relations as any;
    const rows = await this.usersRepository.find({
      where: { id: In(ids) },
      relations: rest,
      relationLoadStrategy: 'query',
      // Comme l'ancienne requête : seulement les relations demandées
      loadEagerRelations: false,
    });

    if (wantReferrer) {
      const parentIds = [...new Set(rows.map((u) => u.referredBy).filter((v): v is string => !!v))];
      const parents = parentIds.length
        ? await this.usersRepository.find({ where: { id: In(parentIds) }, loadEagerRelations: false })
        : [];
      const parentById = new Map(parents.map((p) => [p.id, p]));
      for (const u of rows) u.referrer = u.referredBy ? parentById.get(u.referredBy) : undefined;
    }

    if (wantReferrals) {
      const children = await this.usersRepository.find({
        where: { referredBy: In(rows.map((u) => u.id)) },
        loadEagerRelations: false,
      });
      for (const u of rows) u.referrals = children.filter((c) => c.referredBy === u.id);
    }

    const byId = new Map(rows.map((u) => [u.id, u]));
    return ids.map((id) => byId.get(id)).filter((u): u is UserEntity => !!u);
  }

  async hydrateUsers(qb: SelectQueryBuilder<UserEntity>, relations: FindOptionsRelations<UserEntity>): Promise<UserEntity[]> {
    const rows = await this.idQuery(qb).getMany();
    return this.loadGraph(rows.map((r) => r.id), relations);
  }

  async hydrateUsersAndCount(qb: SelectQueryBuilder<UserEntity>, relations: FindOptionsRelations<UserEntity>): Promise<[UserEntity[], number]> {
    const [rows, total] = await this.idQuery(qb).getManyAndCount();
    return [await this.loadGraph(rows.map((r) => r.id), relations), total];
  }

  async hydrateUser(qb: SelectQueryBuilder<UserEntity>, relations: FindOptionsRelations<UserEntity>): Promise<UserEntity | null> {
    const row = await this.idQuery(qb).getOne();
    if (!row) return null;
    const [user] = await this.loadGraph([row.id], relations);
    return user ?? null;
  }

  /**
   * ✅ Version légère pour l'authentification (CurrentUserMiddleware, à chaque requête) :
   * seulement les colonnes utiles + le statut de l'entreprise active, sans les ~15 jointures de findOne().
   */
  async findForAuth(id: string): Promise<{
    id: string;
    fullName: string;
    email: string;
    phone: string;
    image: string;
    isActive: boolean;
    country?: string;
    city?: string;
    preferredLanguage?: string;
    loyaltyPoints?: number;
    dateOfBirth?: Date;
    vehicleType?: any;
    plateNumber?: string;
    activeCompanyId?: string;
    defaultAddressId?: string;
    userIdFpay?: string;
    isLink?: boolean;
    companyStatus?: any;
  } | null> {
    const user = await this.usersRepository
      .createQueryBuilder('u')
      .select([
        'u.id',
        'u.fullName',
        'u.email',
        'u.phone',
        'u.image',
        'u.isActive',
        'u.country',
        'u.city',
        'u.preferredLanguage',
        'u.loyaltyPoints',
        'u.dateOfBirth',
        'u.vehicleType',
        'u.plateNumber',
        'u.activeCompanyId',
        'u.defaultAddressId',
        'u.userIdFpay',
        'u.isLink',
      ])
      .where('u.id = :id', { id })
      .getOne();
    if (!user) return null;

    // Statut de l'entreprise active (seulement si l'utilisateur en fait partie, comme findOne)
    let companyStatus: any = undefined;
    if (user.activeCompanyId) {
      const rows = await this.usersRepository.query(
        'SELECT c.`status` AS status FROM `user_has_company` uhc INNER JOIN `company` c ON c.`id` = uhc.`companyId` WHERE uhc.`userId` = ? AND uhc.`companyId` = ? LIMIT 1',
        [user.id, user.activeCompanyId],
      );
      companyStatus = rows?.[0]?.status ?? undefined;
    }
    return { ...(user as any), companyStatus };
  }

  async findOne(
    id: string,
    lang: string = 'fr',
  ): Promise<{
    message: string;
    data: any;
  }> {
    const user = await this.hydrateUser(
      this.usersRepository
      .createQueryBuilder('users')
      .leftJoinAndSelect(
        'users.userHasCompany',
        'userHasCompany',
      )
      .leftJoinAndSelect(
        'userHasCompany.branch',
        'userHasCompanyBranch',
      )
      .leftJoinAndSelect(
        'userHasCompany.company',
        'company',
      )
      .leftJoinAndSelect(
        'company.tauxCompanies',
        'tauxCompanies',
      )
      .leftJoinAndSelect(
        'company.country',
        'country',
      )
      .leftJoinAndSelect(
        'company.city',
        'city',
      )
      .leftJoinAndSelect(
        'company.category',
        'category',
      )
      .leftJoinAndSelect(
        'company.companyResources',
        'companyResources',
      )
      .leftJoinAndSelect(
        'companyResources.resource',
        'resource',
      )
      .leftJoinAndSelect(
        'company.branches',
        'branches',
      )
      .leftJoinAndSelect(
        'users.userPlatformRoles',
        'userPlatformRoles',
      )
      .leftJoinAndSelect(
        'userPlatformRoles.platform',
        'platform',
      )
      .leftJoinAndSelect(
        'userPlatformRoles.role',
        'role',
      )
      .leftJoinAndSelect(
        'users.defaultAddress',
        'defaultAddress',
      )
      .leftJoinAndSelect(
        'userHasCompany.resources',
        'userCompanyResources',
      )
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .where('users.id = :id', { id })
      ,
      UsersService.USER_GRAPH,
    );

    if (!user) {
      throw new NotFoundException(
        await this.i18n.translate(
          'user.user_not_found',
          lang,
        ),
      );
    }

    const { password, ...userWithoutPassword } = user;

    const userHasCompany = (
      userWithoutPassword.userHasCompany || []
    ).map((uhc) => ({
      id: uhc.id,
      isOwner: uhc.isOwner,

      company: uhc.company
        ? {
          ...uhc.company,

          tauxCompanies:
            uhc.company.tauxCompanies ?? [],

          country:
            uhc.company.country ?? null,

          city:
            uhc.company.city ?? null,

          category:
            uhc.company.category ?? null,

          branches: (
            uhc.company.branches || []
          ).map((b) => ({
            id: b.id,
            name: b.name,
            address: b.address,
            phone: b.phone,
            email: b.email,
            status: b.status,
            deleted: b.deleted,

            country: b.country
              ? {
                id: b.country.id,
                name: b.country.name,
              }
              : null,

            city: b.city
              ? {
                id: b.city.id,
                name: b.city.name,
              }
              : null,
          })),
        }
        : null,

      branch: uhc.branch
        ? {
          id: uhc.branch.id,
          name: uhc.branch.name,
        }
        : null,

      userResources: (
        uhc.resources || []
      ).map((r) => ({
        id: r.id,
        canCreate: r.canCreate,
        canRead: r.canRead,
        canUpdate: r.canUpdate,
        canDelete: r.canDelete,
        canManage: r.canManage,
        status: r.status,

        resource: r.resource
          ? {
            id: r.resource.id,
            name: r.resource.name,
            label: r.resource.label,
          }
          : null,
      })),
    }));

    const activeUserHasCompany =
      userWithoutPassword.userHasCompany?.find(
        (uhc) =>
          uhc.company?.id ===
          userWithoutPassword.activeCompanyId,
      );

    const activeCompanyEntity =
      activeUserHasCompany?.company ?? null;

    const activeCompany =
      activeCompanyEntity
        ? {
          ...activeCompanyEntity,

          tauxCompanies:
            activeCompanyEntity.tauxCompanies ?? [],

          country:
            activeCompanyEntity.country ?? null,

          city:
            activeCompanyEntity.city ?? null,

          category:
            activeCompanyEntity.category ?? null,

          branch:
            activeUserHasCompany?.branch
              ? {
                id:
                  activeUserHasCompany.branch.id,
                name:
                  activeUserHasCompany.branch.name,
              }
              : null,

          companyResources: (
            activeCompanyEntity.companyResources || []
          ).map((cr) => ({
            id: cr.id,
            canCreate: cr.can_create,
            canRead: cr.can_read,
            canUpdate: cr.can_update,
            canDelete: cr.can_delete,
            canManage: cr.can_manage,
            status: cr.status,

            resource: cr.resource
              ? {
                id: cr.resource.id,
                name: cr.resource.name,
                label: cr.resource.label,
              }
              : null,
          })),

          userResources: (
            activeUserHasCompany?.resources || []
          ).map((r) => ({
            id: r.id,
            canCreate: r.canCreate,
            canRead: r.canRead,
            canUpdate: r.canUpdate,
            canDelete: r.canDelete,
            canManage: r.canManage,
            status: r.status,

            resource: r.resource
              ? {
                id: r.resource.id,
                name: r.resource.name,
                label: r.resource.label,
              }
              : null,
          })),

          branches: (
            activeCompanyEntity.branches || []
          ).map((b) => ({
            id: b.id,
            name: b.name,
            address: b.address,
            phone: b.phone,
            email: b.email,
            status: b.status,
            deleted: b.deleted,

            country: b.country
              ? {
                id: b.country.id,
                name: b.country.name,
              }
              : null,

            city: b.city
              ? {
                id: b.city.id,
                name: b.city.name,
              }
              : null,
          })),
        }
        : null;

    const userPlatformRoles = (
      userWithoutPassword.userPlatformRoles || []
    ).map((upr: any) => ({
      id: upr.id,
      platform: upr.platform,
      role: upr.role,
    }));

    const defaultAddress =
      userWithoutPassword.defaultAddress
        ? {
          id:
            userWithoutPassword.defaultAddress.id,

          firstName:
            userWithoutPassword.defaultAddress.firstName,

          lastName:
            userWithoutPassword.defaultAddress.lastName,

          address:
            userWithoutPassword.defaultAddress.address,

          phone:
            userWithoutPassword.defaultAddress.phone,

          type:
            userWithoutPassword.defaultAddress.type,

          isDefault:
            userWithoutPassword.defaultAddress.isDefault,

          latitude:
            userWithoutPassword.defaultAddress.latitude,

          longitude:
            userWithoutPassword.defaultAddress.longitude,

          createdAt:
            userWithoutPassword.defaultAddress.createdAt,

          updatedAt:
            userWithoutPassword.defaultAddress.updatedAt,
        }
        : null;

    const data = instanceToPlain({
      ...userWithoutPassword,
      userHasCompany,
      activeCompany,
      userPlatformRoles,
      defaultAddress,
    });

    return {
      message: await this.i18n.translate(
        'user.user_found',
        lang,
      ),
      data,
    };
  }

  async findUserByEmail(email: string) {
    return await this.usersRepository.findOneBy({ email });
  }

  async remove(id: string, lang: string = 'fr') {
    const user = await this.findOne(id, lang);
    await this.sessions?.revokeAllForUser(id, SessionRevokeReason.ACCOUNT_DELETED);
    await this.usersRepository.remove(user.data);
    return { message: await this.i18n.translate('user.user_deleted_success_admin', lang, { id }) };
  }

  async toggleUserActiveStatus(userId: string, lang: string = 'fr') {
    // 1ï¸âƒ£ Récupérer l'utilisateur avec toutes ses relations
    const user = await this.usersRepository.findOne({
      where: { id: userId },
      relations: [
        'activeCompany',
        'addresses',
        'userPlatformRoles',
        'userPlatformRoles.platform',
        'userPlatformRoles.role',
        'userHasResources',
        'userHasResources.resource',
        'userHasCompany',
        'userHasCompany.company',
        'userHasCompany.permissions',
        'userHasCompany.permissions.permission',
        'defaultAddress',
      ],
    });

    if (!user) {
      throw new NotFoundException(await this.i18n.translate('user.user_not_found', lang));
    }

    // 2ï¸ Basculer automatiquement le statut (true â†’ false, false â†’ true)
    user.isActive = !user.isActive;
    await this.usersRepository.save(user);
    // ✅ Compte désactivé : déconnexion immédiate de tous ses appareils
    if (!user.isActive) {
      await this.sessions?.revokeAllForUser(user.id, SessionRevokeReason.ACCOUNT_DISABLED);
    }

    // 3ï¸âƒ£ Supprimer le mot de passe avant retour
    const { password, ...rest } = user;

    const messageKey = user.isActive ? 'user.user_activated' : 'user.user_deactivated';
    return {
      message: await this.i18n.translate(messageKey, lang),
      data: rest,
    };
  }

  async deleteOwnAccount(
    userId: string,
    password: string,
    lang: string = 'fr',
  ): Promise<{ message: string; data: any }> {
    const user = await this.usersRepository.findOne({
      where: { id: userId },
      select: [
        'id',
        'fullName',
        'email',
        'phone',
        'deleted',
        'isActive',
        'password',
      ],
    });

    if (!password)
      throw new BadRequestException(
        await this.i18n.translate(
          'user.delete_account_password_required',
          lang,
        ),
      );
    if (!user)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid)
      throw new BadRequestException(
        await this.i18n.translate('user.password_incorrect', lang),
      );

    user.deleted = true;
    const savedUser = await this.usersRepository.save(user);
    await this.sessions?.revokeAllForUser(user.id, SessionRevokeReason.ACCOUNT_DELETED, { byId: user.id });

    return {
      message: await this.i18n.translate('user.account_deleted_success', lang),
      data: {
        id: savedUser.id,
        fullName: savedUser.fullName,
        email: savedUser.email,
        phone: savedUser.phone,
        deleted: savedUser.deleted,
      },
    };
  }

  async updateUserBranch(
    userId: string,
    branchId: string,
    lang: string = 'fr',
  ): Promise<UserEntity> {
    const user = await this.usersRepository.findOne({ where: { id: userId } });
    if (!user)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );
    user.activeBranchId = branchId;
    return this.usersRepository.save(user);
  }

  async registerDeviceToken(
    userId: string,
    fcmToken: string,
    lang: string = 'fr',
    platform?: string,
    voipToken?: string,
  ): Promise<DeviceToken> {
    const user = await this.usersRepository.findOne({ where: { id: userId } });
    if (!user)
      throw new BadRequestException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    // ✅ Jeton VoIP seul (iPhone : PushKit le fournit parfois avant le jeton Firebase) :
    //    rattaché au dernier appareil iPhone / Favor Driver de l'utilisateur
    if ((!fcmToken || !fcmToken.trim()) && voipToken && String(voipToken).trim()) {
      const cleanVoipOnly = String(voipToken).trim();
      const device = await this.deviceTokenRepo
        .createQueryBuilder('d')
        .where('d.userId = :uid', { uid: userId })
        .andWhere("(d.platform IN ('ios', 'driver') OR d.voipToken IS NOT NULL)")
        .orderBy('d.updatedAt', 'DESC')
        .getOne();
      if (!device)
        throw new BadRequestException(
          await this.i18n.translate('user.fcm_token_required', lang),
        );
      await this.deviceTokenRepo
        .createQueryBuilder()
        .update(DeviceToken)
        .set({ voipToken: null })
        .where('voipToken = :v AND id <> :id', { v: cleanVoipOnly, id: device.id })
        .execute()
        .catch(() => undefined);
      device.voipToken = cleanVoipOnly;
      device.updatedAt = new Date();
      return this.deviceTokenRepo.save(device);
    }

    if (!fcmToken || !fcmToken.trim())
      throw new BadRequestException(
        await this.i18n.translate('user.fcm_token_required', lang),
      );
    const cleanToken = fcmToken.trim();
    // ✅ Plateforme réelle de l'appareil (x-platform) : avant, toujours 'unknown'
    const cleanPlatform = platform ? String(platform).toLowerCase().trim() : undefined;
    const cleanVoip = voipToken && String(voipToken).trim() ? String(voipToken).trim() : undefined;

    // Un jeton VoIP n'appartient qu'à un seul appareil / utilisateur
    if (cleanVoip) {
      await this.deviceTokenRepo
        .createQueryBuilder()
        .update(DeviceToken)
        .set({ voipToken: null })
        .where('voipToken = :v AND token <> :t', { v: cleanVoip, t: cleanToken })
        .execute()
        .catch(() => undefined);
    }

    let deviceToken = await this.deviceTokenRepo.findOne({
      where: { token: cleanToken },
    });
    if (deviceToken) {
      deviceToken.userId = userId;
      if (cleanPlatform) deviceToken.platform = cleanPlatform;
      if (cleanVoip) deviceToken.voipToken = cleanVoip;
      deviceToken.updatedAt = new Date();
      deviceToken = await this.deviceTokenRepo.save(deviceToken);
    } else {
      const newToken = this.deviceTokenRepo.create({
        userId,
        token: cleanToken,
        platform: cleanPlatform ?? 'unknown',
        voipToken: cleanVoip ?? null,
      });
      deviceToken = await this.deviceTokenRepo.save(newToken);
    }
    return deviceToken;
  }

  async getUserSettings(
    userId: string,
    lang: string = 'fr',
  ): Promise<{ message: string; data: UserSettingsEntity }> {
    let settings = await this.settingsRepo.findOne({ where: { userId } });
    if (!settings) {
      settings = this.settingsRepo.create({ userId });
      await this.settingsRepo.save(settings);
    }
    return {
      message: await this.i18n.translate('user.settings_retrieved', lang),
      data: settings,
    };
  }

  async updateUserSettings(
    userId: string,
    dto: UpdateUserSettingsDto,
    lang: string = 'fr',
  ): Promise<{ message: string; data: UserSettingsEntity }> {
    const user = await this.usersRepository.findOne({ where: { id: userId } });
    if (!user)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    const updateData: Partial<UserSettingsEntity> = { ...dto };
    if (dto.theme) updateData.theme = dto.theme.toLowerCase();

    let settings = await this.settingsRepo.findOne({ where: { userId } });
    if (settings) {
      Object.assign(settings, updateData);
      settings = await this.settingsRepo.save(settings);
    } else {
      const newSettings = this.settingsRepo.create({ userId, ...updateData });
      settings = await this.settingsRepo.save(newSettings);
    }

    return {
      message: await this.i18n.translate('user.settings_updated', lang),
      data: settings,
    };
  }

  // ============================================================
  // 🔧 CRÉER UN UTILISATEUR PAR UN ADMIN
  // ============================================================
  async createUserByAdmin(
    dto: CreateUserByAdminDto,
    currentUser: UserEntity,
    lang: string = 'fr',
  ): Promise<{ message: string; data: any }> {
    // 1. Sécurité : SUPER_ADMIN uniquement par SUPER_ADMIN
    if (
      dto.role === UserRole.SUPER_ADMIN &&
      currentUser.role !== UserRole.SUPER_ADMIN
    ) {
      throw new ForbiddenException(
        await this.i18n.translate('user.cannot_promote_super_admin', lang),
      );
    }
    const DEFAULT_USER_PASSWORD = 'FavorHelp@2025';
    if (!dto.email && !dto.phone) {
      throw new BadRequestException(
        await this.i18n.translate('user.email_or_phone_required', lang),
      );
    }

    // 2. Doublons
    const existing = await this.usersRepository.findOne({
      where: [
        ...(dto.email ? [{ email: dto.email }] : []),
        ...(dto.phone ? [{ phone: dto.phone }] : []),
      ],
    });

    if (existing) {
      throw new BadRequestException(
        await this.i18n.translate('user.account_exists', lang),
      );
    }

    // 3. Mot de passe (par défaut si non fourni)
    const usedDefaultPassword = !dto.password || dto.password.trim() === '';
    const rawPassword = usedDefaultPassword ? DEFAULT_USER_PASSWORD : dto.password!;
    const hashedPassword = await bcrypt.hash(rawPassword, 10);

    // 4. Création
    const newUser = this.usersRepository.create({
      fullName: dto.fullName,
      email: dto.email || undefined,
      phone: dto.phone || undefined,
      password: hashedPassword,
      role: dto.role,
      isActive: true,
      provider: 'admin',
      country: dto.country,
      city: dto.city,
      address: dto.address,
      image: dto.image,
      vehicleType: dto.vehicleType,
      plateNumber: dto.plateNumber,
    });

    const savedUser = await this.usersRepository.save(newUser);

    // 5. Génération du referralCode
    const referralCodeGenerated = await this.generateReferralCode(savedUser.id);
    savedUser.referralCode = referralCodeGenerated;
    await this.usersRepository.save(savedUser);

    // 6. Compte fidélité
    const loyalty = await this.getOrCreateLoyaltyAccount(savedUser.id);
    await this.loyaltyRepository.save(loyalty);

    // 7. Recharger avec relations
    const fullUser = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.activeBranch', 'activeBranch')
      .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
      .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
      .leftJoinAndSelect('users.loyalty', 'loyalty')
      .where('users.id = :id', { id: savedUser.id })
      .getOne();

    if (!fullUser)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    const { password: _pw, ...userWithoutPassword } = fullUser;

    // 8. Mapper userHasCompany
    const userHasCompany = (userWithoutPassword.userHasCompany || []).map(
      (uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,
        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,
            branches: (uhc.company.branches || []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,
              country: b.country
                ? { id: b.country.id, name: b.country.name }
                : null,
              city: b.city ? { id: b.city.id, name: b.city.name } : null,
            })),
          }
          : null,
        branch: uhc.branch
          ? { id: uhc.branch.id, name: uhc.branch.name }
          : null,
        userResources: (uhc.resources || []).map((r) => ({
          id: r.id,
          canCreate: r.canCreate,
          canRead: r.canRead,
          canUpdate: r.canUpdate,
          canDelete: r.canDelete,
          canManage: r.canManage,
          status: r.status,
          resource: r.resource
            ? {
              id: r.resource.id,
              name: r.resource.name,
              label: r.resource.label,
            }
            : null,
        })),
      }),
    );

    // 9. Réponse
    return {
      message: await this.i18n.translate('user.user_created_by_admin', lang, {
        fullName: fullUser.fullName,
      }),
      data: instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        loyalty: {
          points: fullUser.loyalty?.[0]?.pointsBalance ?? 0,
          tier: fullUser.loyalty?.[0]?.currentTier ?? null,
          code: fullUser.loyalty?.[0]?.loyaltyCode ?? null,
        },
        ...(usedDefaultPassword && {
          defaultPasswordUsed: true,
          defaultPasswordHint:
            'Un mot de passe par défaut a été attribué.',
        }),
      }),
    };
  }

  // ============================================================
  // 🔧 MODIFIER UN UTILISATEUR PAR UN ADMIN
  // ============================================================
  async updateUserByAdmin(
    targetUserId: string,
    dto: UpdateUserByAdminDto,
    currentUser: UserEntity,
    lang: string = 'fr',
  ): Promise<{ message: string; data: any }> {
    // 1. Récupérer l'utilisateur cible
    const targetUser = await this.usersRepository.findOne({
      where: { id: targetUserId },
    });

    if (!targetUser) {
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );
    }

    // 2. Sécurité
    if (
      targetUser.role === UserRole.SUPER_ADMIN &&
      currentUser.role !== UserRole.SUPER_ADMIN
    ) {
      throw new ForbiddenException(
        await this.i18n.translate('user.cannot_modify_super_admin', lang),
      );
    }

    if (
      dto.role === UserRole.SUPER_ADMIN &&
      currentUser.role !== UserRole.SUPER_ADMIN
    ) {
      throw new ForbiddenException(
        await this.i18n.translate('user.cannot_promote_super_admin', lang),
      );
    }

    if (targetUser.id === currentUser.id && dto.isActive === false) {
      throw new BadRequestException(
        await this.i18n.translate('user.cannot_deactivate_self', lang),
      );
    }

    // 3. Doublons email / phone
    if (dto.email && dto.email !== targetUser.email) {
      const emailExists = await this.usersRepository.findOne({
        where: { email: dto.email },
      });
      if (emailExists && emailExists.id !== targetUserId) {
        throw new BadRequestException(
          await this.i18n.translate('user.email_already_exists', lang),
        );
      }
    }

    if (dto.phone && dto.phone !== targetUser.phone) {
      const phoneExists = await this.usersRepository.findOne({
        where: { phone: dto.phone },
      });
      if (phoneExists && phoneExists.id !== targetUserId) {
        throw new BadRequestException(
          await this.i18n.translate('user.phone_already_exists', lang),
        );
      }
    }

    // 4. Mot de passe (hash si fourni)
    let hashedPassword: string | undefined;
    let passwordChanged = false;

    if (dto.password && dto.password.trim() !== '') {
      hashedPassword = await bcrypt.hash(dto.password, 10);
      passwordChanged = true;
    }

    // 5. Appliquer les modifications
    const oldRole = targetUser.role;

    Object.assign(targetUser, {
      ...(dto.fullName !== undefined && { fullName: dto.fullName }),
      ...(dto.email !== undefined && { email: dto.email }),
      ...(dto.phone !== undefined && { phone: dto.phone }),
      ...(hashedPassword !== undefined && { password: hashedPassword }),
      ...(dto.country !== undefined && { country: dto.country }),
      ...(dto.city !== undefined && { city: dto.city }),
      ...(dto.address !== undefined && { address: dto.address }),
      ...(dto.image !== undefined && { image: dto.image }),
      ...(dto.preferredLanguage !== undefined && {
        preferredLanguage: dto.preferredLanguage,
      }),
      ...(dto.role !== undefined && { role: dto.role }),
      ...(dto.isActive !== undefined && { isActive: dto.isActive }),
      ...(dto.vehicleType !== undefined && { vehicleType: dto.vehicleType }),
      ...(dto.plateNumber !== undefined && { plateNumber: dto.plateNumber }),
      ...(dto.licenseDocumentUrl !== undefined && {
        licenseDocumentUrl: dto.licenseDocumentUrl,
      }),
    });

    await this.usersRepository.save(targetUser);

    // 6. Recharger avec relations
    const fullUser = await this.usersRepository
      .createQueryBuilder('users')
      .addSelect('users.password')
      .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
      .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
      .leftJoinAndSelect('userHasCompany.company', 'company')
      .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
      .leftJoinAndSelect('company.country', 'country')
      .leftJoinAndSelect('company.city', 'city')
      .leftJoinAndSelect('company.category', 'category')
      .leftJoinAndSelect('company.companyResources', 'companyResources')
      .leftJoinAndSelect('companyResources.resource', 'resource')
      .leftJoinAndSelect('company.branches', 'branches')
      .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
      .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
      .leftJoinAndSelect('userPlatformRoles.role', 'role')
      .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
      .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
      .leftJoinAndSelect(
        'userCompanyResources.resource',
        'userCompanyResourceDetail',
      )
      .leftJoinAndSelect('users.activeBranch', 'activeBranch')
      .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
      .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
      .leftJoinAndSelect('users.loyalty', 'loyalty')
      .where('users.id = :id', { id: targetUserId })
      .getOne();

    if (!fullUser)
      throw new NotFoundException(
        await this.i18n.translate('user.user_not_found', lang),
      );

    const { password: _pw, ...userWithoutPassword } = fullUser;

    // 7. Mapper userHasCompany
    const userHasCompany = (userWithoutPassword.userHasCompany || []).map(
      (uhc) => ({
        id: uhc.id,
        isOwner: uhc.isOwner,
        company: uhc.company
          ? {
            ...uhc.company,
            tauxCompanies: uhc.company.tauxCompanies ?? [],
            country: uhc.company.country ?? null,
            city: uhc.company.city ?? null,
            category: uhc.company.category ?? null,
            branches: (uhc.company.branches || []).map((b) => ({
              id: b.id,
              name: b.name,
              address: b.address,
              phone: b.phone,
              email: b.email,
              status: b.status,
              deleted: b.deleted,
              country: b.country
                ? { id: b.country.id, name: b.country.name }
                : null,
              city: b.city ? { id: b.city.id, name: b.city.name } : null,
            })),
          }
          : null,
        branch: uhc.branch
          ? { id: uhc.branch.id, name: uhc.branch.name }
          : null,
        userResources: (uhc.resources || []).map((r) => ({
          id: r.id,
          canCreate: r.canCreate,
          canRead: r.canRead,
          canUpdate: r.canUpdate,
          canDelete: r.canDelete,
          canManage: r.canManage,
          status: r.status,
          resource: r.resource
            ? {
              id: r.resource.id,
              name: r.resource.name,
              label: r.resource.label,
            }
            : null,
        })),
      }),
    );

    // 8. Réponse
    return {
      message: await this.i18n.translate('user.user_updated_by_admin', lang, {
        fullName: fullUser.fullName,
      }),
      data: instanceToPlain({
        ...userWithoutPassword,
        userHasCompany,
        loyalty: {
          points: fullUser.loyalty?.[0]?.pointsBalance ?? 0,
          tier: fullUser.loyalty?.[0]?.currentTier ?? null,
          code: fullUser.loyalty?.[0]?.loyaltyCode ?? null,
        },
        ...(oldRole !== fullUser.role && {
          oldRole,
          newRole: fullUser.role,
        }),
        ...(passwordChanged && { passwordChanged: true }),
      }),
    };
  }

  async getClientUsersByCompanyAndDestination(options: {
    type?: 'SHIPMENT' | 'ORDER' | 'VEHICLE_RESERVATION' | 'HOTEL_RESERVATION';
    shippingCompanyId?: string;
    city?: string;
    country?: string;
    search?: string;
    lang?: string;
    startDate?: string;
    endDate?: string;
    onlySellers?: boolean | string | number;
    page?: number | string;
    limit?: number | string;
    /** false = seulement la liste des users (sans colis, commandes, réservations, entreprises) — envoi SMS */
    withActivities?: boolean;
    /** « Tous » : true = seulement les clients qui ont au moins un élément lié ; false/absent = TOUS les clients */
    onlyWithActivity?: boolean;
  }): Promise<{
    message: string;
    data: PaginatedResponseDto<any>;
  }> {
    const lang = options.lang || 'fr';
    const withActivities = options.withActivities !== false;
    const searchFilter = options.search ? `%${options.search}%` : null;

    // ✅ NORMALISATION onlySellers
    const onlySellers =
      options.onlySellers === true ||
      options.onlySellers === 1 ||
      options.onlySellers === '1' ||
      String(options.onlySellers).toLowerCase() === 'true';

    // ✅ PAGINATION — config
    const hasPagination =
      options.page !== undefined || options.limit !== undefined;
    const currentPage = Math.max(1, Number(options.page) || 1);
    const currentLimit = hasPagination
      ? Math.min(100, Math.max(1, Number(options.limit) || 10))
      : Number.MAX_SAFE_INTEGER;
    const skip = (currentPage - 1) * currentLimit;

    // ============================================================
    // 0. Déterminer les types à chercher
    // ============================================================
    const selectedTypes: Array<
      'SHIPMENT' | 'ORDER' | 'VEHICLE_RESERVATION' | 'HOTEL_RESERVATION'
    > = options.type
        ? [options.type]
        : ['SHIPMENT', 'ORDER', 'VEHICLE_RESERVATION', 'HOTEL_RESERVATION'];

    if (options.type === 'SHIPMENT' && !options.shippingCompanyId) {
      return {
        message: 'Company ID is required for SHIPMENT',
        data: new PaginatedResponseDto<any>([], 0, 1, 0),
      };
    }

    // ✅ « Tous » (pas de type) : les colis sont inclus aussi, de toutes les entreprises
    //    si aucune entreprise n'est choisie (avant : colis retirés → rien de lié au client n'était renvoyé).

    // ✅ onlySellers=true : startDate / endDate filtrent la DATE DE CRÉATION DU COMPTE (users.createdAt),
    //    pas les colis / commandes / réservations.
    const datesOnAccount = onlySellers;

    // ✅ Filtre "activité" = type / companyId / city / country / dates (dates : sauf si onlySellers).
    const hasActivityFilter =
      !!options.type ||
      !!options.shippingCompanyId ||
      !!options.city ||
      !!options.country ||
      (!datesOnAccount && (!!options.startDate || !!options.endDate));

    // ✅ « Tous » (rien de sélectionné) : TOUS les clients, chacun avec ses éléments liés.
    //    onlyWithActivity = true : seulement les clients qui ont AU MOINS un élément lié
    //    (colis, commande, réservation véhicule/hôtel, entreprise).
    const useUnion = hasActivityFilter || (withActivities && options.onlyWithActivity === true);

    const includeShipment = useUnion && selectedTypes.includes('SHIPMENT');
    const includeOrder = useUnion && selectedTypes.includes('ORDER');
    const includeVehicle = useUnion && selectedTypes.includes('VEHICLE_RESERVATION');
    const includeHotel = useUnion && selectedTypes.includes('HOTEL_RESERVATION');

    // ✅ Données liées à renvoyer pour chaque user : TOUS les types choisis (tous si « Tous »),
    //    même sans filtre d'activité (avant : rien n'était renvoyé quand on choisissait « Tous »).
    const loadShipment = withActivities && selectedTypes.includes('SHIPMENT');
    const loadOrder = withActivities && selectedTypes.includes('ORDER');
    const loadVehicle = withActivities && selectedTypes.includes('VEHICLE_RESERVATION');
    const loadHotel = withActivities && selectedTypes.includes('HOTEL_RESERVATION');

    const shipmentCompanyId = options.shippingCompanyId;
    const cityFilter = options.city ? `%${options.city}%` : null;

    // ============================================================
    // ✅ Préparation des filtres de date
    // ============================================================
    const startDate = options.startDate ? new Date(options.startDate) : null;
    const endDate = options.endDate ? new Date(options.endDate) : null;
    if (endDate) endDate.setHours(23, 59, 59, 999);

    const buildDateCondition = (column: string, params: any[]): string | null => {
      // onlySellers : les dates portent sur la création du compte, pas sur l'activité
      if (datesOnAccount) return null;
      const parts: string[] = [];
      if (startDate) { parts.push(`${column} >= ?`); params.push(startDate); }
      if (endDate) { parts.push(`${column} <= ?`); params.push(endDate); }
      return parts.length > 0 ? parts.join(' AND ') : null;
    };

    const allUserIds = new Set<string>();

    // ============================================================
    // ✅ Charger TOUS les users (« Tous » sans filtre)
    // ============================================================
    if (!useUnion) {
      const allUsers: any[] = await this.usersRepository.query(
        `SELECT u.id
       FROM users u
       WHERE u.deleted = 0
       ORDER BY u.fullName ASC`,
      );

      allUsers.forEach((u) => u.id && allUserIds.add(u.id));
    }

    // ============================================================
    // 1. Récupérer les userIds (UNION) — uniquement si filtre d'activité
    // ============================================================
    const unionParts: string[] = [];
    const unionParams: any[] = [];

    // ---------- SHIPMENT ----------
    if (includeShipment) {
      const conds1: string[] = [];
      if (shipmentCompanyId) {
        conds1.push('shippingCompanyId = ?');
        unionParams.push(shipmentCompanyId);
      }
      if (cityFilter) {
        conds1.push('LOWER(shippingTo) LIKE LOWER(?)');
        unionParams.push(cityFilter);
      }
      const date1 = buildDateCondition('createdAt', unionParams);
      if (date1) conds1.push(date1);

      unionParts.push(
        `SELECT DISTINCT userId FROM shipments
       WHERE ${[...conds1, 'userId IS NOT NULL'].join(' AND ')}`,
      );

      const conds2: string[] = [];
      if (shipmentCompanyId) {
        conds2.push('s.shippingCompanyId = ?');
        unionParams.push(shipmentCompanyId);
      }
      if (cityFilter) {
        conds2.push('LOWER(s.shippingTo) LIKE LOWER(?)');
        unionParams.push(cityFilter);
      }
      const date2 = buildDateCondition('s.createdAt', unionParams);
      if (date2) conds2.push(date2);

      unionParts.push(
        `SELECT DISTINCT u.id AS userId
       FROM shipments s
       INNER JOIN users u
         ON REPLACE(REPLACE(u.phone, ' ', ''), '+', '')
          = REPLACE(REPLACE(s.clientPhone, ' ', ''), '+', '')
       WHERE ${[...conds2, 's.clientPhone IS NOT NULL'].join(' AND ')}
         AND s.userId IS NULL`,
      );
    }

    // ---------- ORDER ----------
    if (includeOrder) {
      const conds: string[] = [];
      if (cityFilter) {
        conds.push('(LOWER(ci.name) LIKE LOWER(?) OR LOWER(c.address) LIKE LOWER(?))');
        unionParams.push(cityFilter, cityFilter);
      }
      const dateCond = buildDateCondition('o.createdAt', unionParams);
      if (dateCond) conds.push(dateCond);

      const whereClause = conds.length > 0
        ? `WHERE ${conds.join(' AND ')} AND o.userId IS NOT NULL`
        : `WHERE o.userId IS NOT NULL`;

      unionParts.push(
        `SELECT DISTINCT o.userId FROM orders o
       INNER JOIN sub_orders so ON so.orderId = o.id
       INNER JOIN company c ON c.id = so.companyId
       LEFT JOIN cities ci ON ci.id = c.cityId
       ${whereClause}`,
      );
    }

    // ---------- VEHICLE_RESERVATION ----------
    if (includeVehicle) {
      const conds: string[] = ["rv.type = 'VEHICLE'"];
      if (cityFilter) {
        conds.push('(LOWER(ci.name) LIKE LOWER(?) OR LOWER(co.address) LIKE LOWER(?))');
        unionParams.push(cityFilter, cityFilter);
      }
      const dateCond = buildDateCondition('rv.reservation_date', unionParams);
      if (dateCond) conds.push(dateCond);

      unionParts.push(
        `SELECT DISTINCT rv.user_id AS userId
       FROM reservations_vehicules rv
       INNER JOIN products p ON p.id = rv.product_id
       LEFT JOIN company co ON co.id = p.companyId
       LEFT JOIN cities ci ON ci.id = co.cityId
       WHERE ${conds.join(' AND ')} AND rv.user_id IS NOT NULL`,
      );
    }

    // ---------- HOTEL_RESERVATION ----------
    if (includeHotel) {
      const conds: string[] = [];
      if (cityFilter) {
        conds.push('(LOWER(ci.name) LIKE LOWER(?) OR LOWER(p.localization) LIKE LOWER(?))');
        unionParams.push(cityFilter, cityFilter);
      }
      const dateCond = buildDateCondition('r.createdAt', unionParams);
      if (dateCond) conds.push(dateCond);

      const whereClause = conds.length > 0
        ? `WHERE ${conds.join(' AND ')} AND r.userId IS NOT NULL`
        : `WHERE r.userId IS NOT NULL`;

      unionParts.push(
        `SELECT DISTINCT r.userId FROM reservations r
       INNER JOIN products p ON p.id = r.productId
       INNER JOIN company c ON c.id = p.companyId
       LEFT JOIN cities ci ON ci.id = c.cityId
       ${whereClause}`,
      );
    }

    // ---------- ENTREPRISES (vendeurs) — seulement pour « Tous » sans filtre ----------
    if (useUnion && !hasActivityFilter) {
      unionParts.push(
        `SELECT DISTINCT uhc.userId FROM user_has_company uhc WHERE uhc.userId IS NOT NULL`,
      );
    }

    // ✅ Exécution de l'UNION (users supprimés exclus, triés par nom)
    if (useUnion && unionParts.length > 0) {
      const rows: any[] = await this.usersRepository.query(
        `SELECT combined.userId
       FROM (${unionParts.join(' UNION ')}) AS combined
       INNER JOIN users u ON u.id = combined.userId AND u.deleted = 0
       GROUP BY combined.userId, u.fullName
       ORDER BY u.fullName ASC`,
        unionParams,
      );
      rows.forEach((r) => r.userId && allUserIds.add(r.userId));
    }

    let userIds = Array.from(allUserIds);

    // ============================================================
    // 1.bis Filtre search (nom / phone / email / nom d'entreprise)
    // ============================================================
    if (searchFilter && userIds.length > 0) {
      const filtered: any[] = await this.usersRepository.query(
        `SELECT DISTINCT u.id
       FROM users u
       WHERE u.id IN (?)
         AND (
           LOWER(u.fullName) LIKE LOWER(?)
           OR LOWER(COALESCE(u.email, '')) LIKE LOWER(?)
           OR REPLACE(REPLACE(COALESCE(u.phone, ''), ' ', ''), '+', '')
              LIKE REPLACE(REPLACE(?, ' ', ''), '+', '')
           OR EXISTS (
             SELECT 1
             FROM user_has_company uhc
             INNER JOIN company c ON c.id = uhc.companyId
             WHERE uhc.userId = u.id
               AND LOWER(c.companyName) LIKE LOWER(?)
           )
         )`,
        [userIds, searchFilter, searchFilter, searchFilter, searchFilter],
      );
      userIds = filtered.map((u) => u.id);
    }

    // ✅ Filtre onlySellers
    if (onlySellers && userIds.length > 0) {
      const sellers: any[] = await this.usersRepository.query(
        `SELECT DISTINCT uhc.userId
       FROM user_has_company uhc
       WHERE uhc.userId IN (?)`,
        [userIds],
      );
      userIds = sellers.map((u) => u.userId);
    }

    // ✅ onlySellers : filtre sur la date de création du compte (users.createdAt)
    if (datesOnAccount && (startDate || endDate) && userIds.length > 0) {
      const accountConds: string[] = [];
      const accountParams: any[] = [userIds];
      if (startDate) { accountConds.push('u.createdAt >= ?'); accountParams.push(startDate); }
      if (endDate) { accountConds.push('u.createdAt <= ?'); accountParams.push(endDate); }
      const created: any[] = await this.usersRepository.query(
        `SELECT u.id
       FROM users u
       WHERE u.id IN (?)
         AND ${accountConds.join(' AND ')}
       ORDER BY u.fullName ASC`,
        accountParams,
      );
      userIds = created.map((u) => u.id);
    }

    // ============================================================
    // ✅ PAGINATION — total AVANT slice, puis slice
    // ============================================================
    const totalUsers = userIds.length;

    if (totalUsers === 0) {
      return {
        message: 'No users found for these criteria',
        data: new PaginatedResponseDto<any>(
          [],
          0,
          currentPage,
          hasPagination ? currentLimit : 0,
        ),
      };
    }

    if (hasPagination) {
      userIds = userIds.slice(skip, skip + currentLimit);
    }

    // ============================================================
    // 2. Préparer les conditions
    // ============================================================
    const shipConds: string[] = [];
    const shipParams: any[] = [];
    if (shipmentCompanyId) {
      shipConds.push('shipment.shippingCompanyId = ?');
      shipParams.push(shipmentCompanyId);
    }
    if (cityFilter) {
      shipConds.push('LOWER(shipment.shippingTo) LIKE LOWER(?)');
      shipParams.push(cityFilter);
    }
    const shipDateCond = buildDateCondition('shipment.createdAt', shipParams);
    if (shipDateCond) shipConds.push(shipDateCond);
    const shipCondsAliased = shipConds.map((c) =>
      c.replace(/shipment\./g, 's.'),
    );

    // ✅ Colis du client : liés par userId, OU sans userId mais avec son téléphone (clientPhone)
    const normPhone = (v: any) => String(v ?? '').replace(/[\s+]/g, '');
    const userIdByPhone = new Map<string, string>();
    if (loadShipment) {
      const phoneRows: any[] = await this.usersRepository.query(
        `SELECT id, phone FROM users WHERE id IN (?) AND phone IS NOT NULL AND phone <> ''`,
        [userIds],
      );
      for (const r of phoneRows) {
        const ph = normPhone(r.phone);
        if (ph && !userIdByPhone.has(ph)) userIdByPhone.set(ph, r.id);
      }
    }
    const phones = userIdByPhone.size > 0 ? Array.from(userIdByPhone.keys()) : ['__none__'];
    const shipOwnerCond = `(s.userId IN (?) OR (s.userId IS NULL AND s.clientPhone IS NOT NULL
         AND REPLACE(REPLACE(s.clientPhone, ' ', ''), '+', '') IN (?)))`;
    const shipWhere = [...shipCondsAliased, shipOwnerCond].join(' AND ');
    const shipWhereParams = [...shipParams, userIds, phones];

    const orderConds: string[] = [];
    const orderParams: any[] = [];
    if (cityFilter) {
      orderConds.push(
        '(LOWER(ci.name) LIKE LOWER(?) OR LOWER(company.address) LIKE LOWER(?))',
      );
      orderParams.push(cityFilter, cityFilter);
    }
    const orderDateCond = buildDateCondition('o.createdAt', orderParams);
    if (orderDateCond) orderConds.push(orderDateCond);

    const vehicleConds: string[] = ["rv.type = 'VEHICLE'"];
    const vehicleParams: any[] = [];
    if (cityFilter) {
      vehicleConds.push(
        '(LOWER(ci.name) LIKE LOWER(?) OR LOWER(co.address) LIKE LOWER(?))',
      );
      vehicleParams.push(cityFilter, cityFilter);
    }
    const vehicleDateCond = buildDateCondition('rv.reservation_date', vehicleParams);
    if (vehicleDateCond) vehicleConds.push(vehicleDateCond);

    const hotelConds: string[] = [];
    const hotelParams: any[] = [];
    if (cityFilter) {
      hotelConds.push(
        '(LOWER(ci.name) LIKE LOWER(?) OR LOWER(p.localization) LIKE LOWER(?))',
      );
      hotelParams.push(cityFilter, cityFilter);
    }
    const hotelDateCond = buildDateCondition('r.createdAt', hotelParams);
    if (hotelDateCond) hotelConds.push(hotelDateCond);

    // ============================================================
    // 3. TOUT EN PARALLÈLE
    // ============================================================
    const [
      users,
      shipments,
      trackingsLta,
      trackingsShipment,
      orders,
      vehicleReservations,
      hotelReservations,
      userHasCompanyRows,
      productsRows,
    ] = await Promise.all([
      // USERS
      this.usersRepository.query(
        `SELECT id, fullName, email, phone, image, role, isActive, city, country, address, createdAt
       FROM users
       WHERE id IN (?)
         AND deleted = 0
       ORDER BY fullName ASC`,
        [userIds],
      ),

      // SHIPMENTS
      loadShipment
        ? this.shipmentRepo.query(
          `SELECT
         s.id, s.trackingNumber, s.userId, s.pickupEnabled, s.shippingEnabled, s.deliveryEnabled,
         s.status, s.pickupFrom, s.pickupTo, s.pickupContactName, s.pickupContactPhone,
         s.shippingFrom, s.shippingTo, s.deliveryFrom, s.deliveryTo,
         s.deliveryContactName, s.deliveryContactPhone, s.createdAt, s.updatedAt,
         s.pickupTransportTypeId, s.pickupPrice, s.shippingPrice, s.deliveryPrice,
         s.totalPrice, s.packageId, s.image, s.whatsapp_number, s.paymentMethod,
         s.clientName, s.clientPhone, s.deliveryAddressId, s.pin, s.paid, s.collectedAt,
         s.userAssignId, s.shippingCompanyId, s.pickupCompanyId, s.deliveryCompanyId,
         s.company_id, s.loyaltyCode, s.fournisseurName, s.fournisseurPhone,
         s.loyaltyCodeFournisseur, s.isPaid, s.fournisseurId,
         pd.id AS package_id, pd.description AS package_description,
         pd.weight AS package_weight, pd.value AS package_value,
         pd.dimensions AS package_dimensions, pd.fragile AS package_fragile,
         pc.id AS pickupCompany_id, pc.companyName AS pickupCompany_companyName,
         pc.logo AS pickupCompany_logo, pc.phone AS pickupCompany_phone,
         pc.email AS pickupCompany_email, pc.address AS pickupCompany_address,
         sc.id AS shippingCompany_id, sc.companyName AS shippingCompany_companyName,
         sc.logo AS shippingCompany_logo, sc.phone AS shippingCompany_phone,
         sc.email AS shippingCompany_email, sc.address AS shippingCompany_address,
         dc.id AS deliveryCompany_id, dc.companyName AS deliveryCompany_companyName,
         dc.logo AS deliveryCompany_logo, dc.phone AS deliveryCompany_phone,
         dc.email AS deliveryCompany_email, dc.address AS deliveryCompany_address,
         f.id AS fournisseur_id, f.fullName AS fournisseur_fullName,
         f.email AS fournisseur_email, f.phone AS fournisseur_phone,
         f.image AS fournisseur_image, f.country AS fournisseur_country, f.city AS fournisseur_city,
         da.id AS deliveryAddress_id, da.firstName AS deliveryAddress_firstName,
         da.lastName AS deliveryAddress_lastName, da.address AS deliveryAddress_address,
         da.phone AS deliveryAddress_phone, da.type AS deliveryAddress_type,
         da.isDefault AS deliveryAddress_isDefault, da.latitude AS deliveryAddress_latitude,
         da.longitude AS deliveryAddress_longitude,
         tt.id AS pickupTransportType_id, tt.name AS pickupTransportType_name,
         tt.description AS pickupTransportType_description, tt.image AS pickupTransportType_image,
         tt.isActive AS pickupTransportType_isActive,
         tt.createdAt AS pickupTransportType_createdAt,
         tt.updatedAt AS pickupTransportType_updatedAt
       FROM shipments s
       LEFT JOIN package_details pd ON pd.id = s.packageId
       LEFT JOIN company pc ON pc.id = s.pickupCompanyId
       LEFT JOIN company sc ON sc.id = s.shippingCompanyId
       LEFT JOIN company dc ON dc.id = s.deliveryCompanyId
       LEFT JOIN users f ON f.id = s.fournisseurId
       LEFT JOIN address_user da ON da.id = s.deliveryAddressId
       LEFT JOIN type_transport tt ON tt.id = s.pickupTransportTypeId
       WHERE ${shipWhere}
       ORDER BY s.createdAt DESC`,
          shipWhereParams,
        )
        : Promise.resolve([]),

      // TRACKINGS LTA
      loadShipment
        ? this.shipmentRepo.query(
          `SELECT t.id, t.name, t.type, t.completed, t.time, t.createdAt, t.updatedAt,
              ls.shipmentId AS shipmentId,
              l.id AS ltaId, l.ltaNumber, l.externalLtaNumber,
              l.origin AS ltaOrigin, l.destination AS ltaDestination,
              l.originAirportOrPort AS ltaOriginAirport,
              l.destinationAirportOrPort AS ltaDestinationAirport,
              l.status AS ltaStatus
       FROM tracking_lta t
       INNER JOIN lta l ON l.id = t.ltaId
       INNER JOIN lta_shipments ls ON ls.ltaId = l.id
       INNER JOIN shipments s ON s.id = ls.shipmentId
       WHERE ${shipWhere}
       ORDER BY ls.shipmentId ASC, t.createdAt ASC`,
          shipWhereParams,
        )
        : Promise.resolve([]),

      // TRACKINGS SHIPMENT
      loadShipment
        ? this.shipmentRepo.query(
          `SELECT st.id, st.shipmentId, st.status, st.location, st.comment,
              st.createdAt, st.updatedAt
       FROM shipment_tracking st
       INNER JOIN shipments s ON s.id = st.shipmentId
       WHERE ${shipWhere}
       ORDER BY st.shipmentId ASC, st.createdAt ASC`,
          shipWhereParams,
        )
        : Promise.resolve([]),

      // ORDERS
      loadOrder
        ? this.orderRepo.query(
          `SELECT DISTINCT o.id, o.invoiceNumber, o.userId, o.status, o.paymentStatus, o.paid,
              o.totalAmount, o.grandTotal, o.currency, o.shippingCost, o.type,
              o.createdAt, o.updatedAt
       FROM orders o
       INNER JOIN sub_orders so ON so.orderId = o.id
       INNER JOIN company company ON company.id = so.companyId
       LEFT JOIN cities ci ON ci.id = company.cityId
       WHERE o.userId IN (?)
         ${orderConds.length > 0 ? `AND ${orderConds.join(' AND ')}` : ''}
       ORDER BY o.createdAt DESC`,
          [userIds, ...orderParams],
        )
        : Promise.resolve([]),

      // VEHICLE RESERVATIONS
      loadVehicle
        ? this.shipmentRepo.query(
          `SELECT rv.id, rv.type, rv.user_id AS userId, rv.product_id AS productId,
              rv.start_date AS startDate, rv.end_date AS endDate,
              rv.total_amount AS totalAmount, rv.currency, rv.status,
              rv.reservation_date AS createdAt,
              rv.reservation_date AS updatedAt,
              rv.expires_at AS expiresAt,
              p.name AS productName,
              p.localization AS productLocalization,
              co.companyName AS companyName,
              co.address AS companyAddress,
              ci.name AS companyCity,
              co.countryId AS companyCountryId
       FROM reservations_vehicules rv
       INNER JOIN products p ON p.id = rv.product_id
       LEFT JOIN company co ON co.id = p.companyId
       LEFT JOIN cities ci ON ci.id = co.cityId
       WHERE rv.user_id IN (?)
         AND ${vehicleConds.join(' AND ')}
       ORDER BY rv.reservation_date DESC`,
          [userIds, ...vehicleParams],
        )
        : Promise.resolve([]),

      // HOTEL RESERVATIONS
      loadHotel
        ? this.shipmentRepo.query(
          `SELECT r.id, r.userId, r.productId, r.startDate, r.endDate,
              r.adults, r.children, r.roomsBooked, r.quantity,
              r.totalPrice, r.invoiceNumber, r.status, r.specialRequest, r.reason,
              r.createdAt, r.updatedAt,
              p.name AS productName, p.localization AS productLocalization,
              c.id AS companyId, c.companyName,
              ci.name AS companyCity
       FROM reservations r
       INNER JOIN products p ON p.id = r.productId
       INNER JOIN company c ON c.id = p.companyId
       LEFT JOIN cities ci ON ci.id = c.cityId
       WHERE r.userId IN (?)
         ${hotelConds.length > 0 ? `AND ${hotelConds.join(' AND ')}` : ''}
       ORDER BY r.createdAt DESC`,
          [userIds, ...hotelParams],
        )
        : Promise.resolve([]),

      // ✅ entreprises de chaque user (avec role)
      !withActivities ? Promise.resolve([]) : this.usersRepository.query(
        `SELECT
         uhc.id            AS uhcId,
         uhc.userId        AS userId,
         uhc.isOwner       AS isOwner,
         uhc.createdAt     AS uhcCreatedAt,
         uhc.updatedAt     AS uhcUpdatedAt,
         c.id              AS companyId,
         c.companyName     AS companyName,
         c.logo            AS logo,
         c.banner          AS banner,
         c.email           AS companyEmail,
         c.phone           AS companyPhone,
         c.address         AS companyAddress,
         c.companyAddress  AS companyCompanyAddress,
         c.typeCompany     AS typeCompany,
         c.status          AS companyStatus,
         c.isMain          AS isMain,
         c.cityId          AS cityId,
         c.countryId       AS countryId,
         r.id              AS roleId,
         r.name            AS roleName
       FROM user_has_company uhc
       INNER JOIN company c ON c.id = uhc.companyId
       LEFT JOIN role_user r ON r.id = uhc.roleId
       WHERE uhc.userId IN (?)
       ORDER BY uhc.createdAt ASC`,
        [userIds],
      ),

      // ✅ produits de toutes les companies de ces users
      !withActivities ? Promise.resolve([]) : this.usersRepository.query(
        `SELECT
         p.id              AS productId,
         p.name            AS productName,
         p.slug            AS productSlug,
         p.price           AS price,
         p.detail          AS detail,
         p.gros            AS gros,
         p.image           AS productImage,
         p.quantity        AS quantity,
         p.status          AS productStatus,
         p.companyActivity AS companyActivity,
         p.localization    AS localization,
         p.createdAt       AS productCreatedAt,
         c.id              AS companyId
       FROM products p
       INNER JOIN company c ON c.id = p.companyId
       WHERE c.id IN (
         SELECT DISTINCT uhc.companyId
         FROM user_has_company uhc
         WHERE uhc.userId IN (?)
       )
       ORDER BY p.createdAt DESC`,
        [userIds],
      ),
    ]);

    // ============================================================
    // 4. Indexer par clé
    // ============================================================
    const ltaByShip = new Map<string, any[]>();
    for (const t of trackingsLta) {
      let arr = ltaByShip.get(t.shipmentId);
      if (!arr) { arr = []; ltaByShip.set(t.shipmentId, arr); }
      arr.push(t);
    }

    const trackByShip = new Map<string, any[]>();
    for (const t of trackingsShipment) {
      let arr = trackByShip.get(t.shipmentId);
      if (!arr) { arr = []; trackByShip.set(t.shipmentId, arr); }
      arr.push(t);
    }

    const shipmentsByUser = new Map<string, any[]>();
    for (const r of shipments) {
      const mapped = this.mapShipmentRow(
        r,
        ltaByShip.get(r.id) ?? [],
        trackByShip.get(r.id) ?? [],
      );
      // Colis sans userId : rattaché au client qui a ce téléphone
      const ownerId = mapped.userId ?? userIdByPhone.get(normPhone(r.clientPhone));
      if (!ownerId) continue;
      let arr = shipmentsByUser.get(ownerId);
      if (!arr) { arr = []; shipmentsByUser.set(ownerId, arr); }
      arr.push(mapped);
    }

    const ordersByUser = new Map<string, any[]>();
    for (const o of orders) {
      let arr = ordersByUser.get(o.userId);
      if (!arr) { arr = []; ordersByUser.set(o.userId, arr); }
      arr.push(o);
    }

    const vehicleByUser = new Map<string, any[]>();
    for (const r of vehicleReservations) {
      let arr = vehicleByUser.get(r.userId);
      if (!arr) { arr = []; vehicleByUser.set(r.userId, arr); }
      arr.push({
        id: r.id,
        type: r.type,
        userId: r.userId,
        startDate: r.startDate,
        endDate: r.endDate,
        totalAmount: r.totalAmount,
        currency: r.currency,
        status: r.status,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt,
        expiresAt: r.expiresAt,
        product: r.productId
          ? {
            id: r.productId,
            name: r.productName,
            localization: r.productLocalization,
            company: r.companyName
              ? {
                name: r.companyName,
                address: r.companyAddress,
                city: r.companyCity,
                countryId: r.companyCountryId,
              }
              : null,
          }
          : null,
      });
    }

    const hotelByUser = new Map<string, any[]>();
    for (const r of hotelReservations) {
      let arr = hotelByUser.get(r.userId);
      if (!arr) { arr = []; hotelByUser.set(r.userId, arr); }
      arr.push({
        id: r.id,
        userId: r.userId,
        startDate: r.startDate,
        endDate: r.endDate,
        adults: r.adults,
        children: r.children,
        roomsBooked: r.roomsBooked,
        quantity: r.quantity,
        totalPrice: r.totalPrice,
        invoiceNumber: r.invoiceNumber,
        status: r.status,
        specialRequest: r.specialRequest,
        reason: r.reason,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt,
        product: r.productId
          ? {
            id: r.productId,
            name: r.productName,
            localization: r.productLocalization,
          }
          : null,
        company: r.companyId
          ? { id: r.companyId, companyName: r.companyName, city: r.companyCity }
          : null,
      });
    }

    // ============================================================
    // 4.bis Index userHasCompany + produits
    // ============================================================
    const userHasCompanyByUser = new Map<string, any[]>();
    for (const row of userHasCompanyRows) {
      let arr = userHasCompanyByUser.get(row.userId);
      if (!arr) { arr = []; userHasCompanyByUser.set(row.userId, arr); }

      arr.push({
        id: row.uhcId,
        isOwner: !!row.isOwner,
        createdAt: row.uhcCreatedAt,
        updatedAt: row.uhcUpdatedAt,
        role: row.roleId
          ? { id: row.roleId, name: row.roleName }
          : null,
        company: {
          id: row.companyId,
          companyName: row.companyName,
          logo: row.logo,
          banner: row.banner,
          email: row.companyEmail,
          phone: row.companyPhone,
          address: row.companyAddress,
          companyAddress: row.companyCompanyAddress,
          typeCompany: row.typeCompany,
          status: row.companyStatus,
          isMain: !!row.isMain,
          cityId: row.cityId,
          countryId: row.countryId,
        },
      });
    }

    const productsByCompany = new Map<string, any[]>();
    for (const p of productsRows) {
      let arr = productsByCompany.get(p.companyId);
      if (!arr) { arr = []; productsByCompany.set(p.companyId, arr); }

      arr.push({
        id: p.productId,
        name: p.productName,
        slug: p.productSlug,
        price: p.price,
        detail: p.detail,
        gros: p.gros,
        image: p.productImage,
        quantity: p.quantity,
        status: p.productStatus,
        companyActivity: p.companyActivity,
        localization: p.localization,
        createdAt: p.productCreatedAt,
      });
    }

    // ============================================================
    // 5. Fusion finale
    // ============================================================
    const data = users.map((u: any) => {
      const companies = userHasCompanyByUser.get(u.id) ?? [];

      const companiesWithProducts = companies.map((c: any) => ({
        ...c,
        products: productsByCompany.get(c.company.id) ?? [],
        productsCount: productsByCompany.get(c.company.id)?.length ?? 0,
      }));

      return {
        ...u,
        userHasCompany: companiesWithProducts,
        companiesCount: companiesWithProducts.length,

        shipments: shipmentsByUser.get(u.id) ?? [],
        shipmentsCount: shipmentsByUser.get(u.id)?.length ?? 0,
        orders: ordersByUser.get(u.id) ?? [],
        ordersCount: ordersByUser.get(u.id)?.length ?? 0,
        vehicleReservations: vehicleByUser.get(u.id) ?? [],
        vehicleReservationsCount: vehicleByUser.get(u.id)?.length ?? 0,
        hotelReservations: hotelByUser.get(u.id) ?? [],
        hotelReservationsCount: hotelByUser.get(u.id)?.length ?? 0,
      };
    });

    // ============================================================
    // ✅ RETOUR — Structure identique à ProspectsService.findAll
    // ============================================================
    return {
      message: hasPagination
        ? `${data.length} user(s) found (page ${currentPage}/${Math.ceil(totalUsers / currentLimit)}, total ${totalUsers})`
        : `${data.length} user(s) found`,
      data: new PaginatedResponseDto<any>(
        data,
        totalUsers,
        currentPage,
        hasPagination ? currentLimit : totalUsers,
      ),
    };
  }

  async sendSmsToClientUsersByDestination(options: {
    message: string;
    type?: 'SHIPMENT' | 'ORDER' | 'VEHICLE_RESERVATION' | 'HOTEL_RESERVATION';
    shippingCompanyId?: string;
    city?: string;
    country?: string;
    search?: string;
    lang?: string;
    userId?: string;
    sendToAll?: boolean;
    startDate?: string;
    endDate?: string;
    onlySellers?: boolean;
    batchSize?: number;
    delayBetweenBatchesMs?: number;
  }): Promise<{
    message: string;
    data: {
      total: number;
      sent: number;
      failed: number;
      skipped: number;
      batches: number;
      recipients: Array<{
        userId: string;
        fullName: string | null;
        phone: string | null;
        status: 'SENT' | 'FAILED' | 'SKIPPED';
        error?: string;
      }>;
    };
  }> {
    const lang = options.lang || 'fr';

    // ⚙️ Paramètres de batching
    const BATCH_SIZE =
      options.batchSize && options.batchSize > 0
        ? Math.min(options.batchSize, 50)
        : 10;

    const DELAY_BETWEEN_BATCHES_MS = options.delayBetweenBatchesMs ?? 200;

    // ============================================================
    // 1. Récupérer les utilisateurs ciblés
    // ============================================================
    let clientUsers: any[] = [];

    // ============================================================
    // 🅰️ CAS 1 : Envoi à UN utilisateur précis (userId fourni)
    // ============================================================
    if (options.userId) {
      const user = await this.usersRepository.findOne({
        where: { id: options.userId },
        select: [
          'id',
          'fullName',
          'email',
          'phone',
          'image',
          'role',
          'isActive',
          'city',
          'country',
          'address',
          'createdAt',
        ],
      });

      if (!user) {
        return {
          message: 'User not found',
          data: {
            total: 0,
            sent: 0,
            failed: 0,
            skipped: 0,
            batches: 0,
            recipients: [],
          },
        };
      }

      clientUsers = [user];
    }
    // ============================================================
    // 🅱️ CAS 2 : Envoi à TOUS les utilisateurs actifs
    //            (sendToAll = true) — délègue au service pour cohérence
    // ============================================================
    else if (options.sendToAll) {
      // ⚠️ NE PAS passer page/limit ici :
      //    sans page/limit, getClientUsersByCompanyAndDestination
      //    retourne TOUS les users (pas de pagination).
      const { data } = await this.getClientUsersByCompanyAndDestination({
        type: options.type,
        shippingCompanyId: options.shippingCompanyId,
        city: options.city,
        country: options.country,
        search: options.search,
        startDate: options.startDate,
        endDate: options.endDate,
        onlySellers: options.onlySellers,
        lang,
        withActivities: false, // ✅ SMS : seulement les téléphones, pas les colis/commandes
        // ❌ PAS de page/limit
      });

      // ✅ data.data (tableau) — data est un PaginatedResponseDto
      clientUsers = data.data.filter(
        (u: any) => u.isActive === 1 || u.isActive === true,
      );

      console.log(
        `[sendSmsToClientUsersByDestination] sendToAll → ${clientUsers.length} users actifs (parmi ${data.data.length})`,
      );
    }
    // ============================================================
    // 🅲 CAS 3 : Envoi filtré (logique existante + onlySellers)
    // ============================================================
    else {
      // ⚠️ NE PAS passer page/limit ici non plus.
      const { data } = await this.getClientUsersByCompanyAndDestination({
        type: options.type,
        shippingCompanyId: options.shippingCompanyId,
        city: options.city,
        country: options.country,
        search: options.search,
        startDate: options.startDate,
        endDate: options.endDate,
        onlySellers: options.onlySellers,
        lang,
        withActivities: false, // ✅ SMS : seulement les téléphones, pas les colis/commandes
        // ❌ PAS de page/limit
      });

      // ✅ data.data (tableau)
      clientUsers = data.data;
    }

    if (!clientUsers || clientUsers.length === 0) {
      return {
        message: 'No users found for these criteria',
        data: {
          total: 0,
          sent: 0,
          failed: 0,
          skipped: 0,
          batches: 0,
          recipients: [],
        },
      };
    }

    // ============================================================
    // 2. Dédupliquer les destinataires par téléphone normalisé
    // ============================================================
    const recipientsMap = new Map<
      string,
      { userId: string; fullName: string | null; phone: string | null }
    >();

    for (const u of clientUsers) {
      const rawPhone = (u.phone || '').trim();
      const normalized = rawPhone.replace(/[^\d]/g, '');

      if (!normalized) continue;
      if (recipientsMap.has(normalized)) continue;

      recipientsMap.set(normalized, {
        userId: u.id,
        fullName: u.fullName ?? null,
        phone: rawPhone,
      });
    }

    const recipients = Array.from(recipientsMap.values());
    const total = recipients.length;

    if (total === 0) {
      return {
        message: 'No recipients with valid phone number',
        data: {
          total: 0,
          sent: 0,
          failed: 0,
          skipped: 0,
          batches: 0,
          recipients: [],
        },
      };
    }

    // ============================================================
    // 3. Découper en lots
    // ============================================================
    const chunks: (typeof recipients)[] = [];
    for (let i = 0; i < recipients.length; i += BATCH_SIZE) {
      chunks.push(recipients.slice(i, i + BATCH_SIZE));
    }

    console.log(
      `[sendSmsToClientUsersByDestination] 📤 ${total} destinataires → ${chunks.length} lot(s) de ${BATCH_SIZE}`,
    );

    // ============================================================
    // 4. Envoyer par lots
    // ============================================================
    const results: Array<{
      userId: string;
      fullName: string | null;
      phone: string | null;
      status: 'SENT' | 'FAILED' | 'SKIPPED';
      error?: string;
    }> = [];

    let sent = 0;
    let failed = 0;
    let skipped = 0;

    for (let batchIndex = 0; batchIndex < chunks.length; batchIndex++) {
      const batch = chunks[batchIndex];

      console.log(
        `[sendSmsToClientUsersByDestination] 🚀 Lot ${batchIndex + 1}/${chunks.length} (${batch.length} SMS)`,
      );

      const batchPromises = batch.map(async (recipient) => {
        if (!recipient.phone) {
          return {
            ...recipient,
            status: 'SKIPPED' as const,
            error: 'Phone number is empty',
          };
        }

        try {
          const allowed = await this.consumeSmsQuotas(
            recipient.userId,
            'SERVICE_CLIENT_BULK',
            recipient.phone,
          );
          if (!allowed) {
            return {
              ...recipient,
              status: 'SKIPPED' as const,
              error: 'Quota SERVICE_CLIENT épuisé',
            };
          }

          await this.smsService.sendSms(recipient.phone, options.message);
          return { ...recipient, status: 'SENT' as const };
        } catch (error: any) {
          console.error(
            `[sendSmsToClientUsersByDestination] ❌ Erreur SMS pour ${recipient.phone}:`,
            error?.message,
          );
          return {
            ...recipient,
            status: 'FAILED' as const,
            error: error?.message || 'Unknown error',
          };
        }
      });

      const batchResults = await Promise.allSettled(batchPromises);

      for (const res of batchResults) {
        if (res.status === 'fulfilled') {
          const r = res.value;
          results.push(r);

          if (r.status === 'SENT') sent++;
          else if (r.status === 'FAILED') failed++;
          else if (r.status === 'SKIPPED') skipped++;
        } else {
          failed++;
          results.push({
            userId: 'unknown',
            fullName: null,
            phone: null,
            status: 'FAILED',
            error: res.reason?.message || 'Promise rejected',
          });
        }
      }

      console.log(
        `[sendSmsToClientUsersByDestination] ✅ Lot ${batchIndex + 1}/${chunks.length} terminé — sent: ${sent}, failed: ${failed}, skipped: ${skipped}`,
      );

      if (batchIndex < chunks.length - 1 && DELAY_BETWEEN_BATCHES_MS > 0) {
        await new Promise((resolve) =>
          setTimeout(resolve, DELAY_BETWEEN_BATCHES_MS),
        );
      }
    }

    console.log(
      `[sendSmsToClientUsersByDestination] 🎉 Terminé — ${sent}/${total} SMS envoyés`,
    );

    return {
      message: `${sent}/${total} SMS envoyés`,
      data: {
        total,
        sent,
        failed,
        skipped,
        batches: chunks.length,
        recipients: results,
      },
    };
  }

  // ============================================================
  // HELPER — mapper un shipment brut vers objet structuré
  // ============================================================
  private mapShipmentRow(row: any, ltaTrackings: any[] = [], shipmentTrackings: any[] = []): any {
    const groupOrder: Record<string, number> = {
      DEPARTURE: 1, departure: 1, TRANSIT: 2, transit: 2, ARRIVAL: 3, arrival: 3,
    };
    const sortedLta = [...ltaTrackings].sort((a, b) => {
      const g = (groupOrder[a.type] ?? 99) - (groupOrder[b.type] ?? 99);
      return g !== 0 ? g : new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    });
    const sortedShip = [...shipmentTrackings].sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
    );

    return {
      id: row.id,
      trackingNumber: row.trackingNumber,
      userId: row.userId,
      pickupEnabled: row.pickupEnabled,
      shippingEnabled: row.shippingEnabled,
      deliveryEnabled: row.deliveryEnabled,
      status: row.status,
      pickupFrom: row.pickupFrom, pickupTo: row.pickupTo,
      pickupContactName: row.pickupContactName, pickupContactPhone: row.pickupContactPhone,
      shippingFrom: row.shippingFrom, shippingTo: row.shippingTo,
      deliveryFrom: row.deliveryFrom, deliveryTo: row.deliveryTo,
      deliveryContactName: row.deliveryContactName, deliveryContactPhone: row.deliveryContactPhone,
      createdAt: row.createdAt, updatedAt: row.updatedAt,
      pickupTransportTypeId: row.pickupTransportTypeId,
      pickupPrice: row.pickupPrice, shippingPrice: row.shippingPrice, deliveryPrice: row.deliveryPrice,
      totalPrice: row.totalPrice, packageId: row.packageId,
      image: row.image, whatsapp_number: row.whatsapp_number,
      paymentMethod: row.paymentMethod,
      clientName: row.clientName, clientPhone: row.clientPhone,
      deliveryAddressId: row.deliveryAddressId,
      pin: row.pin, paid: row.paid, collectedAt: row.collectedAt,
      userAssignId: row.userAssignId,
      shippingCompanyId: row.shippingCompanyId,
      pickupCompanyId: row.pickupCompanyId,
      deliveryCompanyId: row.deliveryCompanyId,
      company_id: row.company_id,
      loyaltyCode: row.loyaltyCode,
      fournisseurName: row.fournisseurName, fournisseurPhone: row.fournisseurPhone,
      loyaltyCodeFournisseur: row.loyaltyCodeFournisseur,
      isPaid: row.isPaid, fournisseurId: row.fournisseurId,

      package: row.package_id ? {
        id: row.package_id, description: row.package_description,
        external_quantity: row.package_external_quantity, internal_quantity: row.package_internal_quantity,
        weight: row.package_weight, length: row.package_length,
        dimensions: row.package_dimensions, value: row.package_value, fragile: row.package_fragile,
      } : null,

      pickupCompany: row.pickupCompany_id ? {
        id: row.pickupCompany_id, companyName: row.pickupCompany_companyName,
        logo: row.pickupCompany_logo, phone: row.pickupCompany_phone,
        email: row.pickupCompany_email, address: row.pickupCompany_address,
      } : null,

      shippingCompany: row.shippingCompany_id ? {
        id: row.shippingCompany_id, companyName: row.shippingCompany_companyName,
        logo: row.shippingCompany_logo, phone: row.shippingCompany_phone,
        email: row.shippingCompany_email, address: row.shippingCompany_address,
      } : null,

      deliveryCompany: row.deliveryCompany_id ? {
        id: row.deliveryCompany_id, companyName: row.deliveryCompany_companyName,
        logo: row.deliveryCompany_logo, phone: row.deliveryCompany_phone,
        email: row.deliveryCompany_email, address: row.deliveryCompany_address,
      } : null,

      fournisseur: row.fournisseur_id ? {
        id: row.fournisseur_id, fullName: row.fournisseur_fullName,
        email: row.fournisseur_email, phone: row.fournisseur_phone,
        image: row.fournisseur_image, country: row.fournisseur_country, city: row.fournisseur_city,
      } : null,

      deliveryAddress: row.deliveryAddress_id ? {
        id: row.deliveryAddress_id, firstName: row.deliveryAddress_firstName,
        lastName: row.deliveryAddress_lastName, address: row.deliveryAddress_address,
        phone: row.deliveryAddress_phone, type: row.deliveryAddress_type,
        isDefault: row.deliveryAddress_isDefault,
        latitude: row.deliveryAddress_latitude, longitude: row.deliveryAddress_longitude,
      } : null,

      pickupTransportType: row.pickupTransportType_id ? {
        id: row.pickupTransportType_id, name: row.pickupTransportType_name,
        description: row.pickupTransportType_description, image: row.pickupTransportType_image,
        status: row.pickupTransportType_status,
      } : null,

      ltaTrackings: sortedLta.map((t) => ({
        id: t.id, name: t.name, type: t.type, completed: t.completed,
        time: t.time, createdAt: t.createdAt, updatedAt: t.updatedAt,
        lta: {
          id: t.ltaId, ltaNumber: t.ltaNumber, externalLtaNumber: t.externalLtaNumber,
          origin: t.ltaOrigin, destination: t.ltaDestination,
          originAirportOrPort: t.ltaOriginAirport,
          destinationAirportOrPort: t.ltaDestinationAirport, status: t.ltaStatus,
        },
      })),
      ltaTrackingsCount: sortedLta.length,

      shipmentTrackings: sortedShip.map((t) => ({
        id: t.id, name: t.name, type: t.type, completed: t.completed,
        time: t.time, createdAt: t.createdAt, updatedAt: t.updatedAt,
      })),
      shipmentTrackingsCount: sortedShip.length,
    };
  }

  async unblockUser(options: {
    userId: string;
    adminId?: string;
    reason?: string;
    ipAddress?: string;
    lang?: string;
  }): Promise<{ message: string; data: any }> {
    const lang = options.lang || 'fr';

    // ============================================================
    // 1. Vérifier que l'userId est fourni
    // ============================================================
    if (!options.userId) {
      throw new BadRequestException(
        'userId est requis pour débloquer un utilisateur',
      );
    }

    // ============================================================
    // 2. Récupérer l'utilisateur
    // ============================================================
    const user = await this.usersRepository.findOne({
      where: { id: options.userId },
      select: [
        'id',
        'fullName',
        'email',
        'phone',
        'isActive',
        'deleted',
        'role',
      ],
    });

    if (!user) {
      throw new NotFoundException(
        `Utilisateur avec l'ID ${options.userId} introuvable`,
      );
    }

    // ============================================================
    // 3. Vérifier que l'utilisateur est bien bloqué
    // ============================================================
    if (user.isActive === true && user.deleted === false) {
      return {
        message: 'Cet utilisateur n\'est pas bloqué',
        data: {
          userId: user.id,
          fullName: user.fullName,
          alreadyUnblocked: true,
          isActive: user.isActive,
          deleted: user.deleted,
        },
      };
    }

    // ============================================================
    // 4. Débloquer : isActive = true, deleted = false
    // ============================================================
    await this.usersRepository.update(
      { id: user.id },
      {
        isActive: true,
        deleted: false,
      },
    );

    // ============================================================
    // 5. Audit log
    // ============================================================
    try {
      await this.usersRepository.query(
        `INSERT INTO audit_log (id, userId, action, details, ipAddress, createdAt)
         VALUES (UUID(), ?, 'UNBLOCK_USER', ?, ?, NOW())`,
        [
          options.adminId || null,
          JSON.stringify({
            targetUserId: user.id,
            targetFullName: user.fullName,
            targetEmail: user.email,
            targetPhone: user.phone,
            previousIsActive: user.isActive,
            previousDeleted: user.deleted,
            newIsActive: true,
            newDeleted: false,
            reason: options.reason || null,
          }),
          options.ipAddress || null,
        ],
      );
    } catch (auditError: any) {
      // On ne bloque pas l'action si le log échoue
      console.warn(
        '[unblockUser] ⚠️ Impossible d\'écrire dans audit_log:',
        auditError?.message,
      );
    }

    // ============================================================
    // 6. Retour
    // ============================================================
    return {
      message: `Utilisateur ${user.fullName || user.id} débloqué avec succès`,
      data: {
        userId: user.id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        isActive: true,
        deleted: false,
        unblockedAt: new Date(),
        unblockedBy: options.adminId || null,
        reason: options.reason || null,
      },
    };
  }
}