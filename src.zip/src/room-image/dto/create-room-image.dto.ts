export class CreateRoomImageDto {}
