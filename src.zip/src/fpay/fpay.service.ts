// src/modules/fpay/fpay.service.ts
import { Injectable, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { firstValueFrom } from 'rxjs';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserEntity } from 'src/users/entities/user.entity';
import { FpaySendDto } from './dto/send.dto';
import { FpayResponse, PaymentResponseDto } from './dto/response.dto';
import * as crypto from 'crypto';
import { AuthLoginDto } from './dto/link-user.dto';
import * as jwt from 'jsonwebtoken';
import { FpayPaymentDto } from './dto/payment.dto';
import { JwtService } from '@nestjs/jwt';
import { OtpEntity } from 'src/otp/entities/otp.entity';
import { Validator } from 'class-validator';
import { MailService } from 'src/email/email.service';
import { SmsHelper } from 'src/users/utility/helpers/sms.helper';
import { I18nService } from 'src/libs/common/src';
import { ReferralEntity } from 'src/users/entities/referral.entity';
import { EmployeeEntity } from 'src/backOffice/hr/employees/entities/employee.entity';


export interface WalletBalanceResponse {
    success: boolean;
    message: string;
    data: {
        wallet: {
            id: string;
            userId: string;
            balance: number;
            currency: string;
            isActive: boolean;
            createdAt: string;
            updatedAt: string;
        };
        balance: number;
        currency: string;
        transactions: {
            data: any[];
            total: number;
            page: number;
            limit: number;
            analytics: {
                totalCredit: number;
                totalDebit: number;
                totalTransactions: number;
            };
        };
        stats: {
            totalSent: number;
            totalReceived: number;
            averageTransaction: number;
            largestTransaction: number;
            smallestTransaction: number;
            transactionCount: number;
        };
    };
}

// ✅ Interface pour la réponse de link-user
interface LinkUserResponse {
    accessToken: string;
    refreshToken: string;
    message: string;
    sessionId?: string;
    oauthRedirectUrl?: string;
    requiresOtp?: boolean;
    data: {
        id: string;
        email: string | null;
        phone: string | null;
        full_name: string | null;
        role: string;
        status: string;
        profileImage: string | null;
        kycStatus: string;
        countryCode: string | null;
        accessToken: string;
        refreshToken: string;
        tokenType: string;
        expiresIn: number;
        [key: string]: any;
    };
}

export interface DepositRequestDto {
    userId: string;
    amount: number;
    currency: string;
}

export interface DepositRequestResponse {
    message: string;
    data: {
        transaction: {
            id: string;
            userId: string;
            walletId: string;
            amount: number;
            type: string;
            status: string;
            reference: string;
            description: string;
            movement: string;
            currency: string;
            createdAt: string;
            updatedAt: string;
        };
        wallet: {
            id: string;
            userId: string;
            balance: number;
            currency: string;
            isActive: boolean;
            createdAt: string;
            updatedAt: string;
        };
        requiresValidation: boolean;
    };
}


@Injectable()
export class FpayService {
    private readonly logger = new Logger(FpayService.name);
    private readonly fpayApiUrl: string;
    private readonly apiKey: string;
    private readonly logisticApiKey: string;
    private readonly parrainageApiKey: string;
    private readonly salaryApiKey: string;
    private readonly appUrl: string;
    private readonly fideliteApiKey: string;

    constructor(
        private readonly httpService: HttpService,
        private readonly configService: ConfigService,
        @InjectRepository(UserEntity)
        private readonly userRepository: Repository<UserEntity>,

        @InjectRepository(OtpEntity)
        private readonly otpRepository: Repository<OtpEntity>,
        private readonly smsHelper: SmsHelper,
        private readonly mailService: MailService,
        private readonly jwtService: JwtService,

        @InjectRepository(EmployeeEntity)
        private readonly employeeRepository: Repository<EmployeeEntity>,

        @InjectRepository(ReferralEntity)  // ✅ Ajouter
        private readonly referralRepository: Repository<ReferralEntity>,
    ) {
        const fpayApiUrl = this.configService.get<string>('FPAY_API_URL');
        const apiKey = this.configService.get<string>('FPAY_API_KEY_HELP');
        const parrainageApiKey = this.configService.get<string>('FPAY_API_KEY_PARRAINAGE');
        const logisticApiKey = this.configService.get<string>('FPAY_API_KEY_LOGISTIC');
        const salaryApiKey = this.configService.get<string>('FPAY_API_KEY_SALARY');
        const appUrl = this.configService.get<string>('APP_URL') || 'http://localhost:3000';
        const fideliteApiKey = this.configService.get<string>('FPAY_API_KEY_FIDELITE');


        if (!salaryApiKey) {
            throw new Error('FPAY_API_KEY_SALARY is not defined in environment variables');
        }

        if (!fpayApiUrl) {
            throw new Error('FPAY_API_URL is not defined in environment variables');
        }
        if (!apiKey) {
            throw new Error('FPAY_API_KEY_HELP is not defined in environment variables');
        }
        if (!logisticApiKey) {
            throw new Error('FPAY_API_KEY_LOGISTIC is not defined in environment variables');
        }

        if (!parrainageApiKey) {
            throw new Error('FPAY_API_KEY_PARRAINAGE is not defined in environment variables');
        }

        if (!fideliteApiKey) {
            throw new Error('FPAY_API_KEY_FIDELITE is not defined in environment variables');
        }

        this.fpayApiUrl = fpayApiUrl;
        this.apiKey = apiKey;
        this.logisticApiKey = logisticApiKey;
        this.appUrl = appUrl;
        this.parrainageApiKey = parrainageApiKey;
        this.fideliteApiKey = fideliteApiKey;
        this.salaryApiKey = salaryApiKey;   // ✅ AJOUT : corrige TS6133
    }

    private getHeaders() {
        return {
            'Authorization': this.apiKey,
            'Content-Type': 'application/json',
        };
    }

    private getLogisticHeaders() {
        return {
            'Authorization': this.logisticApiKey,
            'Content-Type': 'application/json',
        };
    }

    // ✅ AJOUT : headers pour le service SALARY
    private getSalaryHeaders() {
        return {
            'Authorization': this.salaryApiKey,
            'Content-Type': 'application/json',
        };
    }

    async login(
        authDto: AuthLoginDto,
        systemUserId?: string
    ): Promise<any> {
        try {
            const url = `${this.fpayApiUrl}/auth/login`;  // ✅ Changé de /auth/link-user à /auth/login
            const hasOtp = authDto.otpCode && authDto.otpCode.trim() !== '';

            this.logger.log(`🔐 Authentification: ${authDto.phone}, hasOtp: ${hasOtp}`);

            // ============================================================
            // ÉTAPE 1 : Vérifier les identifiants et envoyer OTP
            // ============================================================
            if (!hasOtp) {
                this.logger.log(`📱 ÉTAPE 1 - Vérification des identifiants pour ${authDto.phone}`);

                // ✅ Appel pour vérifier les identifiants
                const authResponse = await firstValueFrom(
                    this.httpService.post<any>(
                        url,
                        {
                            phone: authDto.phone,
                            password: authDto.password,
                            clientId: authDto.clientId || 'web-client',
                            redirectUri: authDto.redirectUri || `${this.appUrl}/oauth/callback`,
                            lang: authDto.lang || 'fr',
                        },
                        { headers: this.getHeaders() }
                    )
                );

                this.logger.log(`✅ Identifiants valides pour ${authDto.phone}`);

                // ✅ Retourner que l'OTP a été envoyé
                return {
                    success: true,
                    requiresOtp: true,
                    message: authResponse.data.message || 'Code OTP envoyé avec succès',
                    data: null
                };
            }

            // ============================================================
            // ÉTAPE 2 : Vérifier l'OTP et générer les tokens
            // ============================================================
            this.logger.log(`🔐 ÉTAPE 2 - Vérification OTP pour ${authDto.phone}`);

            const response = await firstValueFrom(
                this.httpService.post<any>(
                    url,
                    {
                        phone: authDto.phone,
                        password: authDto.password,
                        otpCode: authDto.otpCode,
                        clientId: authDto.clientId || 'web-client',
                        redirectUri: authDto.redirectUri || `${this.appUrl}/oauth/callback`,
                        lang: authDto.lang || 'fr',
                    },
                    { headers: this.getHeaders() }
                )
            );

            this.logger.log(`✅ OTP vérifié avec succès pour ${authDto.phone}`);

            // ✅ Sauvegarde du userIdFpay (LE LIEN) - UNIQUEMENT si on a systemUserId
            if (systemUserId && response.data?.data?.id) {
                await this.saveFpayUserId(systemUserId, response.data.data.id);
                this.logger.log(`🔗 Compte FPay lié à l'utilisateur ${systemUserId}`);
            }

            return {
                success: true,
                message: response.data.message || 'Connexion réussie',
                data: response.data.data,
                accessToken: response.data.accessToken,
                refreshToken: response.data.refreshToken,
                requiresOtp: false,
                isLinked: true,
            };

        } catch (error) {
            this.logger.error(`❌ Erreur d'authentification: ${error.message}`);

            return {
                success: false,
                message: error.response?.data?.message || error.message || 'Erreur d\'authentification',
                error: error.response?.data || null
            };
        }
    }

    async linkUserWithToken(
        accessToken: string,
        systemUserId: string,
        refreshToken?: string,
    ): Promise<{ success: boolean; message: string; data?: any; access_token?: string; refresh_token?: string }> {
        try {
            this.logger.log(`🔗 Liaison directe pour systemUserId: ${systemUserId}`);

            if (!accessToken) {
                throw new Error('access_token est requis pour la liaison');
            }

            if (!systemUserId) {
                throw new Error('system_user_id est requis pour la liaison');
            }

            const response = await fetch(`${this.fpayApiUrl}/auth/link-user`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    access_token: accessToken,
                    refresh_token: refreshToken || null,
                    system_user_id: systemUserId,
                }),
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `Erreur API: ${response.status}`);
            }

            const data = await response.json();

            this.logger.log(`✅ Comptes liés avec succès pour ${systemUserId}`);

            // ✅ Récupérer l'utilisateur avec toutes les relations (comme dans le login)
            const user = await this.userRepository
                .createQueryBuilder('users')
                .leftJoinAndSelect('users.userHasCompany', 'userHasCompany')
                .leftJoinAndSelect('userHasCompany.company', 'company')
                .leftJoinAndSelect('userHasCompany.branch', 'userHasCompanyBranch')
                .leftJoinAndSelect('company.tauxCompanies', 'tauxCompanies')
                .leftJoinAndSelect('company.country', 'country')
                .leftJoinAndSelect('company.city', 'city')
                .leftJoinAndSelect('company.category', 'category')
                .leftJoinAndSelect('company.companyResources', 'companyResources')
                .leftJoinAndSelect('companyResources.resource', 'resource')
                .leftJoinAndSelect('company.branches', 'branches')
                .leftJoinAndSelect('users.userPlatformRoles', 'userPlatformRoles')
                .leftJoinAndSelect('userPlatformRoles.platform', 'platform')
                .leftJoinAndSelect('userPlatformRoles.role', 'role')
                .leftJoinAndSelect('users.defaultAddress', 'defaultAddress')
                .leftJoinAndSelect('userHasCompany.resources', 'userCompanyResources')
                .leftJoinAndSelect('userCompanyResources.resource', 'userCompanyResourceDetail')
                .leftJoinAndSelect('users.activeBranch', 'activeBranch')
                .leftJoinAndSelect('activeBranch.country', 'activeBranchCountry')
                .leftJoinAndSelect('activeBranch.city', 'activeBranchCity')
                .leftJoinAndSelect('users.loyalty', 'loyalty')
                .where('users.id = :id', { id: systemUserId })
                .getOne();

            if (!user) {
                throw new Error(`Utilisateur ${systemUserId} non trouvé`);
            }

            // ✅ Mettre à jour userIdFpay et isLink
            const fpayUserId = data.data?.fpayUserId || data.data?.id;
            await this.saveFpayUserId(systemUserId, fpayUserId);

            // ✅ Générer les tokens comme dans le login
            const access_token = await this.accessToken(user);
            const refresh_token = await this.refreshToken(user);

            // ✅ Construire la même structure que le login
            const loyaltyPoints = user.loyalty?.[0]?.pointsBalance ?? 0;
            const loyaltyTier = user.loyalty?.[0]?.currentTier ?? null;
            const loyaltyCode = user.loyalty?.[0]?.loyaltyCode ?? null;

            const { password, ...userWithoutPassword } = user;

            return {
                success: true,
                message: data.message || 'Compte lié avec succès',
                access_token: access_token,
                refresh_token: refresh_token,
                data: {
                    ...userWithoutPassword,
                    loyalty: {
                        points: loyaltyPoints,
                        tier: loyaltyTier,
                        code: loyaltyCode,
                    },
                    userIdFpay: fpayUserId,
                    isLink: true,
                }
            };

        } catch (error) {
            this.logger.error(`❌ Erreur de liaison: ${error.message}`);
            return {
                success: false,
                message: error.message || 'Erreur lors de la liaison',
            };
        }
    }

    async saveFpayUserId(systemUserId: string, fpayUserId: string): Promise<void> {
        try {
            console.log(`[saveFpayUserId] systemUserId: ${systemUserId}`);
            console.log(`[saveFpayUserId] fpayUserId: ${fpayUserId}`);

            if (!systemUserId || !fpayUserId) {
                throw new Error('systemUserId ou fpayUserId est vide');
            }

            // ✅ VÉRIFIER SI CE fpayUserId EST DÉJÀ UTILISÉ PAR UN AUTRE UTILISATEUR
            const existingUser = await this.userRepository.findOne({
                where: { userIdFpay: fpayUserId },
            });

            if (existingUser && existingUser.id !== systemUserId) {
                console.warn(`⚠️ Le userIdFpay ${fpayUserId} est déjà utilisé par l'utilisateur ${existingUser.id}`);
                throw new Error(
                    `Ce compte FPay est déjà lié à un autre utilisateur. Veuillez contacter le support.`
                );
            }

            // ✅ VÉRIFIER SI L'UTILISATEUR ACTUEL A DÉJÀ UN userIdFpay DIFFÉRENT
            const currentUser = await this.userRepository.findOne({
                where: { id: systemUserId },
            });

            if (!currentUser) {
                throw new Error(`Utilisateur ${systemUserId} non trouvé`);
            }

            // ✅ Si l'utilisateur a déjà un userIdFpay différent, on le remplace
            if (currentUser.userIdFpay && currentUser.userIdFpay !== fpayUserId) {
                console.log(`🔄 Remplacement: ${currentUser.userIdFpay} → ${fpayUserId}`);
            }

            // ✅ Mettre à jour
            const result = await this.userRepository.update(
                { id: systemUserId },
                {
                    userIdFpay: fpayUserId,
                    isLink: true,
                }
            );

            console.log(`[saveFpayUserId] Result:`, result);
            console.log(`✅ userIdFpay ${fpayUserId} sauvegardé pour l'utilisateur ${systemUserId}`);
        } catch (error) {
            console.error(`❌ Erreur lors de la sauvegarde:`, error.message);
            throw error;
        }
    }

    async accessToken(user: UserEntity): Promise<string> {
        const payload = {
            id: user.id,
            email: user.email,
            role: user.role,
        };

        const secretKey = this.configService.get<string>('ACCESS_TOKEN_SECRET_KEY');
        if (!secretKey) {
            throw new Error('ACCESS_TOKEN_SECRET_KEY is not defined!');
        }

        return await this.jwtService.signAsync(payload, {
            expiresIn: '48h',
            secret: secretKey,
        });
    }

    async refreshToken(user: UserEntity): Promise<string> {
        const payload = {
            id: user.id,
            email: user.email,
            role: user.role,
        };

        const secretKey = this.configService.get<string>('REFRESH_TOKEN_SECRET_KEY');
        if (!secretKey) {
            throw new Error('REFRESH_TOKEN_SECRET_KEY is not defined!');
        }

        return await this.jwtService.signAsync(payload, {
            expiresIn: '7d',
            secret: secretKey,
        });
    }

    async findUserById(systemUserId: string): Promise<UserEntity | null> {
        try {
            return await this.userRepository.findOne({
                where: { id: systemUserId },
            });
        } catch (error) {
            this.logger.error(`❌ Erreur lors de la recherche de l'utilisateur: ${error.message}`);
            return null;
        }
    }

    async unlinkFpayUser(systemUserId: string): Promise<{ success: boolean; message: string }> {
        try {
            this.logger.log(`🔓 Tentative de déliaison pour l'utilisateur ${systemUserId}`);

            const user = await this.userRepository.findOne({
                where: { id: systemUserId },
            });

            if (!user) {
                throw new HttpException(
                    'Utilisateur non trouvé',
                    HttpStatus.NOT_FOUND,
                );
            }

            if (!user.userIdFpay || user.isLink === false) {
                throw new HttpException(
                    'Ce compte Favor Help n\'est pas lié à un compte FPay',
                    HttpStatus.BAD_REQUEST,
                );
            }

            const result = await this.userRepository.update(
                { id: systemUserId },
                {
                    userIdFpay: "",
                    isLink: false,
                }
            );

            if (result.affected === 0) {
                throw new HttpException(
                    'Impossible de mettre à jour l\'utilisateur',
                    HttpStatus.INTERNAL_SERVER_ERROR,
                );
            }

            this.logger.log(`✅ Compte FPay délié avec succès pour l'utilisateur ${systemUserId}`);

            return {
                success: true,
                message: 'Compte FPay délié avec succès',
            };

        } catch (error) {
            this.logger.error(`❌ Erreur lors de la déliaison: ${error.message}`);

            if (error instanceof HttpException) {
                throw error;
            }

            throw new HttpException(
                {
                    statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                    message: error.message || 'Erreur lors de la déliaison du compte',
                    timestamp: new Date().toISOString(),
                },
                HttpStatus.INTERNAL_SERVER_ERROR,
            );
        }
    }

    async makePayment(
        paymentDto: FpayPaymentDto,
        currentUser: UserEntity,
    ): Promise<FpayResponse<PaymentResponseDto>> {
        try {
            if (!currentUser) {
                throw new HttpException('User not authenticated', HttpStatus.UNAUTHORIZED);
            }



            // ✅ Vérifier que le client a fourni un access_token
            if (!paymentDto.access_token) {
                throw new HttpException(
                    'access_token est requis pour le paiement FPay',
                    HttpStatus.BAD_REQUEST,
                );
            }


            // ✅ Utiliser FPAY_API_URL 
            const url = `${this.fpayApiUrl}/api/external/pay`;

            // ✅ NE PAS envoyer system_user_id
            const paymentData = {
                amount: paymentDto.amount,
                currency: paymentDto.currency || 'USD',
                description: paymentDto.description || `Paiement via FPay`,
                access_token: paymentDto.access_token,
            };

            // ✅ Utiliser l'API Key du service (pay)
            const headers = {
                'Authorization': this.apiKey,
                'Content-Type': 'application/json',
            };

            this.logger.log(`📤 Appel API Gateway: ${url}`);
            this.logger.log(`📤 Headers: Authorization: ${this.apiKey.substring(0, 20)}...`);
            this.logger.log(`📤 Payload:`, JSON.stringify(paymentData, null, 2));

            const response = await firstValueFrom(
                this.httpService.post<FpayResponse<PaymentResponseDto>>(
                    url,
                    paymentData,
                    { headers: headers }
                )
            );

            this.logger.log(`✅ Paiement réussi: ${response.data.data?.transaction?.reference || 'OK'}`);
            return response.data;

        } catch (error) {
            this.logger.error(`❌ Erreur de paiement: ${error.message}`);

            if (error.response) {
                this.logger.error(`📦 Réponse erreur: ${JSON.stringify(error.response.data)}`);
            }

            throw this.handleError(error);
        }
    }

    async payWithMobileMoney(
        amount: number,
        currency: string = 'CDF',
        description?: string,
        paymentMethod?: string,
        ipAddress?: string,
        lang: string = 'fr',
    ): Promise<any> {
        try {
            this.logger.log(`💰 Paiement Mobile Money: ${amount} ${currency}`);

            // ✅ Utiliser l'API Key HELP (celle qui a la permission 'pay')
            const url = `${this.fpayApiUrl}/api/external/pay/mobile_money`;

            const paymentData = {
                amount: amount,
                currency: currency || 'CDF',
                description: description || `Paiement Mobile Money`,
                paymentMethod: paymentMethod || 'CASH',
            };

            // ✅ Utiliser l'API Key du service (pay)
            const headers = {
                'Authorization': this.apiKey,
                'Content-Type': 'application/json',
            };

            this.logger.log(`📤 Appel API Gateway: ${url}`);
            this.logger.log(`📤 Headers: Authorization: ${this.apiKey.substring(0, 30)}...`);
            this.logger.log(`📤 Payload:`, JSON.stringify(paymentData, null, 2));

            const response = await firstValueFrom(
                this.httpService.post<any>(
                    url,
                    paymentData,
                    { headers: headers }
                )
            );

            this.logger.log(`Paiement Mobile Money réussi: ${response.data.data?.transaction?.reference || 'OK'}`);
            return response.data;

        } catch (error) {
            this.logger.error(`Erreur paiement Mobile Money: ${error.message}`);

            if (error.response) {
                this.logger.error(`Réponse erreur: ${JSON.stringify(error.response.data)}`);
            }

            throw this.handleError(error);
        }
    }

    async makeSend(
        sendDto: FpaySendDto,
        currentUser: UserEntity,
    ): Promise<FpayResponse<PaymentResponseDto>> {
        try {
            if (!currentUser) {
                throw new HttpException('User not authenticated', HttpStatus.UNAUTHORIZED);
            }

            let cleanApiKey = this.logisticApiKey;
            if (cleanApiKey.startsWith('Bearer ')) {
                cleanApiKey = cleanApiKey.substring(7);
            }

            let recipientPhoneOrCode: string | null = null;

            try {
                const apiKeyParts = cleanApiKey.split('.');
                if (apiKeyParts.length === 3) {
                    const payloadJson = Buffer.from(apiKeyParts[1], 'base64').toString('utf-8');
                    const payload = JSON.parse(payloadJson);
                    recipientPhoneOrCode = payload.phone || payload.sub;
                }
            } catch (error) {
                this.logger.error(`Erreur lors du décodage de l'API Key LOGISTIC: ${error.message}`);
            }

            if (!recipientPhoneOrCode) {
                throw new HttpException(
                    'Impossible d\'extraire le destinataire de l\'API Key LOGISTIC',
                    HttpStatus.BAD_REQUEST,
                );
            }

            const client = await this.userRepository.findOne({
                where: { userIdFpay: sendDto.userId },
            });

            if (!client) {
                throw new HttpException(
                    `Client avec l'ID ${sendDto.userId} non trouvé`,
                    HttpStatus.NOT_FOUND,
                );
            }

            if (!client.userIdFpay) {
                throw new HttpException(
                    'Le client n\'a pas de compte FPay lié',
                    HttpStatus.BAD_REQUEST,
                );
            }

            if (client.phone === recipientPhoneOrCode) {
                throw new HttpException(
                    'Vous ne pouvez pas vous envoyer d\'argent à vous-même',
                    HttpStatus.BAD_REQUEST,
                );
            }

            this.logger.log(`Envoi LOGISTIC: ${client.phone} → ${recipientPhoneOrCode}`);

            const url = `${this.fpayApiUrl}/api/external/send`;
            const sendData = {
                userId: sendDto.userId,
                amount: sendDto.amount,
                description: sendDto.description || `Envoi vers ${recipientPhoneOrCode}`,
                currency: sendDto.currency || 'USD',
                countryCode: sendDto.countryCode || 'CD',
            };

            const response = await firstValueFrom(
                this.httpService.post<FpayResponse<PaymentResponseDto>>(
                    url,
                    sendData,
                    { headers: this.getLogisticHeaders() }
                )
            );

            this.logger.log(`Envoi LOGISTIC réussi: ${response.data.data.transaction.reference}`);
            return response.data;

        } catch (error) {
            this.logger.error(`❌ Erreur d'envoi LOGISTIC: ${error.message}`);
            throw this.handleError(error);
        }
    }

    async makeSendSalary(
        sendDto: FpaySendDto,
        currentUser: UserEntity,
    ): Promise<FpayResponse<PaymentResponseDto>> {
        try {
            if (!currentUser) {
                throw new HttpException('User not authenticated', HttpStatus.UNAUTHORIZED);
            }

            // ✅ 1. Nettoyer l'API Key SALARY
            let cleanApiKey = this.salaryApiKey;
            if (cleanApiKey.startsWith('Bearer ')) {
                cleanApiKey = cleanApiKey.substring(7);
            }

            // ✅ 2. Extraire le payeur (company)
            let payerPhoneOrCode: string | null = null;
            try {
                const apiKeyParts = cleanApiKey.split('.');
                if (apiKeyParts.length === 3) {
                    const payloadJson = Buffer.from(apiKeyParts[1], 'base64').toString('utf-8');
                    const payload = JSON.parse(payloadJson);
                    payerPhoneOrCode = payload.phone || payload.sub;
                }
            } catch (error) {
                this.logger.error(`❌ Erreur décodage API Key SALARY: ${error.message}`);
            }

            if (!payerPhoneOrCode) {
                throw new HttpException(
                    'Impossible d\'extraire le payeur de l\'API Key SALARY',
                    HttpStatus.BAD_REQUEST,
                );
            }

            // ✅ 3. Récupérer l'employé DEPUIS hr_employees via userIdFpay
            const employee = await this.employeeRepository
                .createQueryBuilder('emp')
                .leftJoinAndSelect('emp.user', 'user')
                .where('user.userIdFpay = :userIdFpay', { userIdFpay: sendDto.userId })
                .getOne();

            if (!employee) {
                throw new HttpException(
                    `Employé avec l'userIdFpay ${sendDto.userId} non trouvé`,
                    HttpStatus.NOT_FOUND,
                );
            }

            // ✅ 4. Récupérer le phone (priorité employee.phone, fallback user.phone)
            const recipientPhone = employee.user?.phone;

            if (!recipientPhone) {
                throw new HttpException(
                    'Aucun numéro de téléphone trouvé pour cet employé',
                    HttpStatus.BAD_REQUEST,
                );
            }

            // ✅ 5. Vérifier que le payeur n'est pas l'employé
            if (recipientPhone === payerPhoneOrCode) {
                throw new HttpException(
                    'Vous ne pouvez pas vous verser un salaire à vous-même',
                    HttpStatus.BAD_REQUEST,
                );
            }

            this.logger.log(`💰 Envoi SALAIRE: ${payerPhoneOrCode} → ${recipientPhone}`);
            this.logger.log(`👤 Employé: ${employee.fullName} (hr_employees.id=${employee.id})`);

            // ✅ 6. Appel API externe
            const url = `${this.fpayApiUrl}/api/external/salary`;

            const sendData = {
                phone: recipientPhone,
                amount: sendDto.amount,
                description: sendDto.description || `Paiement de salaire à ${employee.fullName || recipientPhone}`,
                currency: sendDto.currency || 'USD',
                countryCode: sendDto.countryCode || 'CD',
            };

            this.logger.log(`📤 Appel API SALARY: ${url}`);
            this.logger.log(`📤 Payload:`, JSON.stringify(sendData, null, 2));

            const response = await firstValueFrom(
                this.httpService.post<FpayResponse<PaymentResponseDto>>(
                    url,
                    sendData,
                    { headers: this.getSalaryHeaders() },
                ),
            );

            this.logger.log(`✅ Salaire envoyé: ${response.data.data?.transaction?.reference || 'OK'}`);
            return response.data;

        } catch (error) {
            this.logger.error(`❌ Erreur d'envoi SALAIRE: ${error.message}`);
            if (error.response) {
                this.logger.error(`📦 Réponse erreur: ${JSON.stringify(error.response.data)}`);
            }
            throw this.handleError(error);
        }
    }

    async makeSendparrainage(
        sendDto: FpaySendDto,
        currentUser: UserEntity,
    ): Promise<{ success: boolean; message: string; data?: any }> {
        try {
            if (!currentUser) {
                return {
                    success: false,
                    message: 'Utilisateur non authentifié',
                };
            }

            // ✅ 1. API Key du PAYEUR (celui qui envoie l'argent)
            let payerApiKey = this.apiKey;  // ✅ FPAY_API_KEY_HELP
            if (!payerApiKey) {
                this.logger.error('❌ API Key HELP (payeur) non configurée');
                return {
                    success: false,
                    message: 'Configuration API Key HELP manquante',
                };
            }

            // ✅ 2. Récupérer l'API Key du DESTINATAIRE
            // Si sendDto.userId est fourni, l'utiliser, sinon utiliser la clé PARRAINAGE du .env
            let recipientApiKey = sendDto.userId || this.parrainageApiKey;

            if (!recipientApiKey) {
                this.logger.error('❌ Aucune API Key destinataire disponible');
                return {
                    success: false,
                    message: 'Aucune API Key destinataire disponible',
                };
            }

            // ✅ Nettoyer l'API Key du destinataire pour le body (enlever "Bearer " si présent)
            let cleanRecipientApiKey = recipientApiKey;
            if (cleanRecipientApiKey.startsWith('Bearer ')) {
                cleanRecipientApiKey = cleanRecipientApiKey.substring(7);
            }

            // ✅ Nettoyer l'API Key du payeur pour le log
            let cleanPayerApiKey = payerApiKey;
            if (cleanPayerApiKey.startsWith('Bearer ')) {
                cleanPayerApiKey = cleanPayerApiKey.substring(7);
            }

            // ✅ 3. Vérifier le paymentMethod
            const validPaymentMethods = ['MOBILE_MONEY', 'CASH', 'BANK_TRANSFER', 'CARD'];
            const paymentMethod = sendDto.paymentMethod || 'MOBILE_MONEY';

            if (!validPaymentMethods.includes(paymentMethod)) {
                return {
                    success: false,
                    message: `paymentMethod invalide. Valeurs acceptées: ${validPaymentMethods.join(', ')}`,
                };
            }

            // ✅ 4. Déterminer la devise
            const currency = sendDto.currency || 'USD';

            this.logger.log(`📤 ========== ENVOI PARRAINAGE ==========`);
            this.logger.log(`📤 === PAYEUR (FAVOR HELP) ===`);
            this.logger.log(`📤 API Key HELP: ${cleanPayerApiKey.substring(0, 50)}...`);
            this.logger.log(`📤 === DESTINATAIRE (PARRAIN) ===`);
            this.logger.log(`📤 API Key PARRAIN: ${cleanRecipientApiKey.substring(0, 50)}...`);
            this.logger.log(`📤 Source destinataire: ${sendDto.userId ? 'userId fourni' : 'clé .env'}`);
            this.logger.log(`📤 === INFORMATIONS TRANSFERT ===`);
            this.logger.log(`📤 Montant: ${sendDto.amount} ${currency}`);
            this.logger.log(`📤 PaymentMethod: ${paymentMethod}`);
            this.logger.log(`📤 Description: ${sendDto.description}`);
            this.logger.log(`📤 CountryCode: ${sendDto.countryCode || 'CD'}`);
            this.logger.log(`📤 =========================================`);

            // ✅ 5. Appel à l'API externe
            const url = `${this.fpayApiUrl}/api/external/send/parrainage`;

            // ✅ 6. Payload : on envoie l'API Key brute du destinataire (sans "Bearer ")
            const sendData = {
                toApiKey: cleanRecipientApiKey,  // ✅ API Key du parrain - sans "Bearer "
                amount: sendDto.amount,
                description: sendDto.description || `Envoi de parrainage`,
                currency: currency,
                countryCode: sendDto.countryCode || 'CD',
                paymentMethod: paymentMethod,
            };

            // ✅ 7. Headers : Authorization avec l'API Key du payeur (avec "Bearer ")
            const headers = {
                'Authorization': payerApiKey,  // ✅ Garder "Bearer " pour le header
                'Content-Type': 'application/json',
            };

            this.logger.log(`📤 Appel API PARRAINAGE: ${url}`);
            this.logger.log(`📤 Headers Authorization: ${cleanPayerApiKey.substring(0, 50)}...`);
            this.logger.log(`📤 Payload COMPLET:`, JSON.stringify(sendData, null, 2));

            const response = await firstValueFrom(
                this.httpService.post<FpayResponse<PaymentResponseDto>>(
                    url,
                    sendData,
                    { headers: headers }
                )
            );

            this.logger.log(`✅ Envoi PARRAINAGE réussi: ${response.data.data?.transaction?.reference || 'OK'}`);
            this.logger.log(`✅ Réponse complète:`, JSON.stringify(response.data, null, 2));

            return {
                success: true,
                message: 'Parrainage envoyé avec succès',
                data: response.data,
            };

        } catch (error) {
            this.logger.error(`❌ Erreur d'envoi PARRAINAGE: ${error.message}`);

            if (error.response) {
                this.logger.error(`📦 Réponse erreur: ${JSON.stringify(error.response.data)}`);
                this.logger.error(`📦 Status: ${error.response.status}`);
                this.logger.error(`📦 Headers: ${JSON.stringify(error.response.headers)}`);
            }

            if (error.request) {
                this.logger.error(`📦 Request: ${JSON.stringify(error.request)}`);
            }

            return {
                success: false,
                message: error.message || 'Erreur lors de l\'envoi du parrainage',
            };
        }
    }

    async makeSendFavorhelp(
        sendDto: FpaySendDto,
        currentUser: UserEntity,
    ): Promise<FpayResponse<PaymentResponseDto>> {
        try {
            if (!currentUser) {
                throw new HttpException('User not authenticated', HttpStatus.UNAUTHORIZED);
            }

            let cleanApiKey = this.apiKey;
            if (cleanApiKey.startsWith('Bearer ')) {
                cleanApiKey = cleanApiKey.substring(7);
            }

            let recipientPhoneOrCode: string | null = null;

            try {
                const apiKeyParts = cleanApiKey.split('.');
                if (apiKeyParts.length === 3) {
                    const payloadJson = Buffer.from(apiKeyParts[1], 'base64').toString('utf-8');
                    const payload = JSON.parse(payloadJson);
                    recipientPhoneOrCode = payload.phone || payload.sub;
                }
            } catch (error) {
                this.logger.error(`❌ Erreur lors du décodage de l'API Key LOGISTIC: ${error.message}`);
            }

            if (!recipientPhoneOrCode) {
                throw new HttpException(
                    'Impossible d\'extraire le destinataire de l\'API Key LOGISTIC',
                    HttpStatus.BAD_REQUEST,
                );
            }

            const client = await this.userRepository.findOne({
                where: { userIdFpay: sendDto.userId },
            });

            if (!client) {
                throw new HttpException(
                    `Client avec l'ID ${sendDto.userId} non trouvé`,
                    HttpStatus.NOT_FOUND,
                );
            }

            if (!client.userIdFpay) {
                throw new HttpException(
                    'Le client n\'a pas de compte FPay lié',
                    HttpStatus.BAD_REQUEST,
                );
            }

            if (client.phone === recipientPhoneOrCode) {
                throw new HttpException(
                    'Vous ne pouvez pas vous envoyer d\'argent à vous-même',
                    HttpStatus.BAD_REQUEST,
                );
            }

            this.logger.log(`📤 Envoi LOGISTIC: ${client.phone} → ${recipientPhoneOrCode}`);
            const validPaymentMethods = ['MOBILE_MONEY', 'CASH', 'BANK_TRANSFER', 'CARD'];
            const paymentMethod = sendDto.paymentMethod || 'MOBILE_MONEY';

            if (!validPaymentMethods.includes(paymentMethod)) {
                throw new HttpException(
                    `paymentMethod invalide. Valeurs acceptées: ${validPaymentMethods.join(', ')}`,
                    HttpStatus.BAD_REQUEST,
                );
            }

            const url = `${this.fpayApiUrl}/api/external/send/parrainage`; // ✅ Nouvelle URL
            const sendData = {
                userId: sendDto.userId,
                amount: sendDto.amount,
                description: sendDto.description || `Envoi de parrainage vers ${recipientPhoneOrCode}`,
                currency: sendDto.currency || 'USD',
                countryCode: sendDto.countryCode || 'CD',
                paymentMethod: paymentMethod,
            };

            const response = await firstValueFrom(
                this.httpService.post<FpayResponse<PaymentResponseDto>>(
                    url,
                    sendData,
                    { headers: this.getLogisticHeaders() }
                )
            );

            this.logger.log(`✅ Envoi LOGISTIC réussi: ${response.data.data.transaction.reference}`);
            return response.data;

        } catch (error) {
            this.logger.error(`❌ Erreur d'envoi LOGISTIC: ${error.message}`);
            throw this.handleError(error);
        }
    }

    async getWalletBalanceAndTransactions(
        userId: string,
        page: number = 1,
        limit: number = 10,
        startDate?: string,
        endDate?: string,
        type?: string,
        status?: string,
        movement?: string,
        search?: string,
        walletId?: string,
    ): Promise<any> {
        try {
            if (!userId || userId.trim() === '') {
                throw new Error('userId est requis');
            }

            // ============================================================
            // 🔥 LOGS AVANT D'ENVOYER - AFFICHER userId ET walletId
            // ============================================================
            this.logger.log(`📊 ========== APPEL API FPAY ==========`);
            this.logger.log(`📊 userId envoyé: "${userId}"`);
            this.logger.log(`📊 walletId envoyé: "${walletId || 'NON FOURNI'}"`);
            this.logger.log(`📊 page: ${page}, limit: ${limit}`);
            this.logger.log(`📊 ========================================`);

            const url = `${this.fpayApiUrl}/wallet/balance-transactions`;

            const params = new URLSearchParams();
            params.set('userId', userId.trim());
            params.set('page', page.toString());
            params.set('limit', limit.toString());

            if (startDate) params.set('startDate', startDate);
            if (endDate) params.set('endDate', endDate);
            if (type) params.set('type', type);
            if (status) params.set('status', status);
            if (movement) params.set('movement', movement);
            if (search) params.set('search', search);

            if (walletId) {
                params.set('walletId', walletId);
                this.logger.log(`🔗 Filtrage par walletId: ${walletId}`);
            }

            const fullUrl = `${url}?${params.toString()}`;

            // ============================================================
            // 🔥 AFFICHER L'URL COMPLÈTE
            // ============================================================
            this.logger.log(`🔗 URL COMPLÈTE: ${fullUrl}`);
            this.logger.log(`📤 ========================================`);

            const response = await firstValueFrom(
                this.httpService.get(fullUrl, { headers: this.getHeaders() })
            );

            this.logger.log(`✅ Balance et transactions récupérées avec succès`);
            return response.data;

        } catch (error) {
            // ============================================================
            // 🔥 RECONSTRUIRE L'URL DANS LE CATCH
            // ============================================================
            const url = `${this.fpayApiUrl}/wallet/balance-transactions`;
            const params = new URLSearchParams();
            params.set('userId', userId.trim());
            params.set('page', page.toString());
            params.set('limit', limit.toString());

            if (startDate) params.set('startDate', startDate);
            if (endDate) params.set('endDate', endDate);
            if (type) params.set('type', type);
            if (status) params.set('status', status);
            if (movement) params.set('movement', movement);
            if (search) params.set('search', search);
            if (walletId) params.set('walletId', walletId);

            const fullUrl = `${url}?${params.toString()}`;

            this.logger.error(`❌ ERREUR - Ce qui a été envoyé:`);
            this.logger.error(`❌ userId: "${userId}"`);
            this.logger.error(`❌ walletId: "${walletId || 'NON FOURNI'}"`);
            this.logger.error(`❌ URL: ${fullUrl}`);
            this.logger.error(`❌ Message: ${error.message}`);

            if (error.response) {
                this.logger.error(`📦 Réponse erreur: ${JSON.stringify(error.response.data)}`);
            }
            throw this.handleError(error);
        }
    }

    getApiKey(): string {
        return this.apiKey;
    }

    getFpayApiUrl(): string {
        return this.fpayApiUrl;
    }

    async processFullPayment(
        authDto: AuthLoginDto,
        paymentDto: FpayPaymentDto,
        currentUser: UserEntity
    ): Promise<{
        auth: any;
        payment: FpayResponse<PaymentResponseDto>;
    }> {
        try {
            const authResult = await this.login(authDto, currentUser.id);

            if (!authResult.success) {
                throw new HttpException(
                    authResult.message || 'Authentication failed',
                    HttpStatus.UNAUTHORIZED,
                );
            }

            const paymentResult = await this.makePayment(paymentDto, currentUser);

            return {
                auth: authResult,
                payment: paymentResult,
            };
        } catch (error) {
            this.logger.error(`❌ Erreur lors du traitement complet: ${error.message}`);
            throw error;
        }
    }

    async getTransactionById(transactionId: string): Promise<any> {
        try {
            this.logger.log(`🔍 Récupération de la transaction: ${transactionId}`);

            if (!transactionId) {
                throw new HttpException(
                    'ID de transaction requis',
                    HttpStatus.BAD_REQUEST,
                );
            }

            const url = `${this.fpayApiUrl}/wallet/transactions/${transactionId}`;

            const response = await firstValueFrom(
                this.httpService.get(
                    url,
                    { headers: this.getHeaders() }
                )
            );

            this.logger.log(`✅ Transaction récupérée avec succès: ${transactionId}`);
            return response.data;

        } catch (error) {
            this.logger.error(`❌ Erreur récupération transaction: ${error.message}`);
            throw this.handleError(error);
        }
    }

    async getLastPendingTransaction(
        userId: string,
        type?: 'DEPOSIT' | 'WITHDRAW' | 'TRANSFER' | 'PAYMENT' | 'REFUND',
    ): Promise<any> {
        try {
            this.logger.log(`🔍 Recherche des transactions PENDING pour ${userId}${type ? ` (type: ${type})` : ''}`);

            const result = await this.getWalletBalanceAndTransactions(
                userId,
                1,
                100,
                undefined,
                undefined,
                type,
                undefined,
                undefined,
                undefined,
            );

            // ✅ Récupérer toutes les devises des wallets
            const allCurrencies: string[] = [];

            if (result?.data?.wallets && Array.isArray(result.data.wallets)) {
                result.data.wallets.forEach((wallet: any) => {
                    if (wallet.currency && !allCurrencies.includes(wallet.currency)) {
                        allCurrencies.push(wallet.currency);
                    }
                });
            }

            if (allCurrencies.length === 0) {
                allCurrencies.push('USD');
            }

            const allByCurrency: { [currency: string]: any[] } = {};
            const totalsByCurrency: { [currency: string]: number } = {};

            allCurrencies.forEach((currency) => {
                allByCurrency[currency] = [];
                totalsByCurrency[currency] = 0;
            });

            let transactions: any[] = [];

            if (result?.data?.transactions && Array.isArray(result.data.transactions)) {
                transactions = result.data.transactions;
            } else if (result?.data?.transactions?.data && Array.isArray(result.data.transactions.data)) {
                transactions = result.data.transactions.data;
            } else if (result?.data && Array.isArray(result.data)) {
                transactions = result.data;
            } else if (Array.isArray(result)) {
                transactions = result;
            }

            if (!transactions || transactions.length === 0) {
                return {
                    success: true,
                    message: 'Aucune transaction trouvée',
                    data: allByCurrency,
                    totalsByCurrency: totalsByCurrency,
                    currencies: allCurrencies,
                    currenciesWithData: [],
                    count: 0,
                };
            }

            const pendingTransactions = transactions.filter(
                (tx: any) => tx.status === 'PENDING' || tx.status === 'pending'
            );

            pendingTransactions.forEach((tx: any) => {
                const currency = tx.currency || 'USD';

                if (!allByCurrency[currency]) {
                    allByCurrency[currency] = [];
                }
                allByCurrency[currency].push(tx);

                if (!totalsByCurrency[currency]) {
                    totalsByCurrency[currency] = 0;
                }
                totalsByCurrency[currency] += (tx.amount || 0);
            });

            const formattedData: { [currency: string]: any[] } = {};

            allCurrencies.forEach((currency) => {
                const txs = allByCurrency[currency] || [];
                formattedData[currency] = txs.map((tx: any) => ({
                    id: tx.id || tx.transactionId,
                    amount: tx.amount,
                    currency: tx.currency,
                    type: tx.type,
                    status: tx.status,
                    createdAt: tx.createdAt || tx.created_at,
                    description: tx.description,
                    reference: tx.reference,
                    walletId: tx.walletId,
                    userId: tx.userId,
                    movement: tx.movement,
                    paymentMethod: tx.paymentMethod,
                    external_reference: tx.external_reference,
                    metadata: tx.metadata || null,
                    ...tx,
                }));
            });

            const totalCount = pendingTransactions.length;
            const currenciesWithData = Object.keys(allByCurrency).filter(
                (currency) => allByCurrency[currency].length > 0
            );

            return {
                success: true,
                message: totalCount === 0
                    ? 'Aucune transaction en attente'
                    : `${totalCount} transaction(s) en attente sur ${allCurrencies.length} devise(s)`,
                data: formattedData,
                totalsByCurrency: totalsByCurrency,
                currencies: allCurrencies,
                currenciesWithData: currenciesWithData,
                count: totalCount,
            };

        } catch (error) {
            this.logger.error(`❌ Erreur: ${error.message}`);

            // ✅ CORRECTION : Propager les HttpException au lieu de les masquer
            if (error instanceof HttpException) {
                throw error;
            }

            // ✅ Sinon, lancer une erreur générique
            throw new HttpException(
                error.message || 'Erreur lors de la récupération',
                HttpStatus.INTERNAL_SERVER_ERROR,
            );
        }
    }

    async requestDepositWithOtp(
        dto: {
            userId: string;        // userIdFpay (pour l'API FPay)
            amount: number;
            currency: string;
            otpCode?: string;
            systemUserId?: string; // ✅ ID de l'utilisateur dans votre système (pour l'email)
        },
        lang: string = 'fr',
    ): Promise<any> {
        try {
            this.logger.log(
                `📤 Demande de dépôt: ${dto.amount} ${dto.currency} - userIdFpay=${dto.userId}`,
            );

            // ============================================================
            // VALIDATIONS
            // ============================================================

            if (!dto.userId) {
                throw new HttpException(
                    "L'ID de l'utilisateur est requis",
                    HttpStatus.BAD_REQUEST,
                );
            }

            if (!dto.amount || Number(dto.amount) <= 0) {
                throw new HttpException(
                    'Le montant doit être supérieur à 0',
                    HttpStatus.BAD_REQUEST,
                );
            }

            if (!dto.currency) {
                throw new HttpException(
                    'La devise est obligatoire',
                    HttpStatus.BAD_REQUEST,
                );
            }

            if (!this.parrainageApiKey) {
                throw new HttpException(
                    'API Key de parrainage non configurée',
                    HttpStatus.INTERNAL_SERVER_ERROR,
                );
            }

            const amount = Number(dto.amount);
            const currency = dto.currency.toUpperCase();

            // ============================================================
            // VÉRIFICATION DES TRANSACTIONS EN ATTENTE
            // ============================================================

            try {
                this.logger.log(
                    `🔍 Vérification des transactions PENDING en ${currency}`,
                );

                const transactionsData =
                    await this.getWalletBalanceAndTransactions(
                        dto.userId,
                        1,
                        100,
                        undefined,
                        undefined,
                        'DEPOSIT',
                        'PENDING',
                        undefined,
                        undefined,
                    );

                let allPending: any[] = [];

                if (
                    transactionsData?.data?.transactions &&
                    Array.isArray(transactionsData.data.transactions)
                ) {
                    allPending =
                        transactionsData.data.transactions.filter(
                            (tx: any) =>
                                tx.status === 'PENDING' ||
                                tx.status === 'pending',
                        );
                } else if (
                    transactionsData?.data &&
                    Array.isArray(transactionsData.data)
                ) {
                    allPending = transactionsData.data.filter(
                        (tx: any) =>
                            tx.status === 'PENDING' ||
                            tx.status === 'pending',
                    );
                } else if (
                    transactionsData?.data?.transactions?.data &&
                    Array.isArray(
                        transactionsData.data.transactions.data,
                    )
                ) {
                    allPending =
                        transactionsData.data.transactions.data.filter(
                            (tx: any) =>
                                tx.status === 'PENDING' ||
                                tx.status === 'pending',
                        );
                } else if (Array.isArray(transactionsData)) {
                    allPending = transactionsData.filter(
                        (tx: any) =>
                            tx.status === 'PENDING' ||
                            tx.status === 'pending',
                    );
                }

                const pendingInCurrency = allPending.filter(
                    (tx: any) =>
                        String(tx.currency || 'USD').toUpperCase() ===
                        currency,
                );

                if (pendingInCurrency.length > 0) {
                    const pendingTx = pendingInCurrency[0];

                    this.logger.warn(
                        `❌ Une transaction est déjà PENDING en ${currency}`,
                    );

                    throw new HttpException(
                        {
                            statusCode: HttpStatus.BAD_REQUEST,
                            message: `Vous avez déjà une demande de dépôt en cours en ${currency} de ${pendingTx.amount} ${currency}. Veuillez attendre sa finalisation.`,
                            code: 'PENDING_TRANSACTION_EXISTS_IN_CURRENCY',
                            pendingTransaction: {
                                id: pendingTx.id,
                                amount: pendingTx.amount,
                                currency: pendingTx.currency,
                                status: pendingTx.status,
                                reference: pendingTx.reference,
                                createdAt: pendingTx.createdAt,
                            },
                        },
                        HttpStatus.BAD_REQUEST,
                    );
                }

                this.logger.log(
                    `✅ Aucune transaction PENDING en ${currency}`,
                );
            } catch (error: any) {
                if (error instanceof HttpException) {
                    throw error;
                }

                this.logger.warn(
                    `⚠️ Impossible de vérifier les transactions PENDING: ${error.message}`,
                );
            }

            // ============================================================
            // ÉTAPE 1 : ENVOI OTP
            // ============================================================

            const hasOtp =
                dto.otpCode &&
                dto.otpCode.trim() !== '';

            if (!hasOtp) {
                this.logger.log(
                    `📱 ÉTAPE 1 - Génération OTP`,
                );

                const generatedOtpCode =
                    Math.floor(
                        1000 + Math.random() * 9000,
                    ).toString();

                const otpExpiry = new Date(
                    Date.now() + 10 * 60 * 1000,
                );

                // ✅ RECHERCHER L'UTILISATEUR PAR SON ID SYSTÈME (POUR L'EMAIL)
                const user = await this.userRepository.findOne({
                    where: {
                        id: dto.systemUserId,  // ✅ Utiliser systemUserId pour l'email
                    },
                    select: [
                        'id',
                        'email',
                        'phone',
                        'fullName',
                    ],
                });

                if (!user) {
                    throw new HttpException(
                        'Utilisateur non trouvé.',
                        HttpStatus.NOT_FOUND,
                    );
                }

                this.logger.log(`👤 ========== UTILISATEUR CONNECTÉ ==========`);
                this.logger.log(`👤 ID système: ${user.id}`);
                this.logger.log(`👤 Nom: ${user.fullName}`);
                this.logger.log(`👤 EMAIL: ${user.email || 'NON RENSEIGNÉ'}`);
                this.logger.log(`👤 Téléphone: ${user.phone || 'NON RENSEIGNÉ'}`);
                this.logger.log(`👤 userIdFpay: ${dto.userId}`);
                this.logger.log(`👤 ===========================================`);


                let destination: string | null = null;
                let destinationType: 'email' | 'sms' = 'email';

                if (user.email) {
                    destination = user.email;
                    destinationType = 'email';
                } else if (user.phone) {
                    destination = user.phone;
                    destinationType = 'sms';
                }

                if (!destination) {
                    throw new HttpException(
                        'Aucun email ou téléphone trouvé pour cet utilisateur.',
                        HttpStatus.BAD_REQUEST,
                    );
                }

                this.logger.log(`📤 Destination: ${destination} (${destinationType})`);
                this.logger.log(`📤 Utilisateur système: ${user.id} (FPay: ${dto.userId})`);

                // Invalider les anciens OTP
                await this.otpRepository.update(
                    {
                        email: destination,
                        isUsed: false,
                    },
                    {
                        isUsed: true,
                    },
                );

                const otp =
                    this.otpRepository.create({
                        email: destination,
                        otpCode: generatedOtpCode,
                        expiresAt: otpExpiry,
                        isUsed: false,
                        user,
                    });

                await this.otpRepository.save(otp);

                // ========================================================
                // EMAIL
                // ========================================================

                if (destinationType === 'email') {
                    const translations = {
                        title:
                            'Code de vérification pour votre dépôt',

                        description:
                            'Utilisez le code ci-dessous pour confirmer votre demande de dépôt sur FPay',

                        label:
                            'VOTRE CODE DE VÉRIFICATION',

                        expiry:
                            'Ce code expire dans 10 minutes',

                        footerCopyright:
                            `© ${new Date().getFullYear()} FavorHelp. Tous droits réservés.`,

                        footerSecurity:
                            'Protection des données | Email sécurisé',

                        legalNote:
                            'Favor Help — Écosystème digital par Favor Group | RCCM: 21-A-770 | N° IMPÔT: A2156062L | National ID: 19-G4701-N74976',
                    };

                    await this.mailService.sendHtmlEmail(
                        destination,
                        'Code OTP pour votre dépôt FPay',
                        'sendOtp.html',
                        {
                            otpCode: generatedOtpCode,
                            year: new Date().getFullYear(),
                            lang,
                            translations,
                        },
                    );
                    this.logger.log(`✅ OTP envoyé par email à ${destination}`);
                }

                // ========================================================
                // SMS
                // ========================================================

                else {
                    const smsMessage =
                        `Votre code OTP pour le dépôt FPay est: ${generatedOtpCode}. Valable 10 minutes.`;

                    await this.smsHelper.sendSms(
                        destination,
                        smsMessage,
                    );
                    this.logger.log(`✅ OTP envoyé par SMS à ${destination}`);
                }

                return {
                    status: 'success',
                    message: `Un code OTP a été envoyé par ${destinationType === 'email'
                        ? 'email'
                        : 'SMS'
                        }.`,
                    requiresOtp: true,
                    data: {
                        userId: dto.userId,
                        systemUserId: dto.systemUserId,
                        amount,
                        currency,
                        destination: destinationType,
                    },
                };
            }

            // ============================================================
            // ÉTAPE 2 : VÉRIFICATION OTP
            // ============================================================

            this.logger.log(
                `🔐 ÉTAPE 2 - Vérification OTP`,
            );

            // ✅ RECHERCHER L'UTILISATEUR PAR SON ID SYSTÈME
            const user = await this.userRepository.findOne({
                where: {
                    id: dto.systemUserId,
                },
                select: [
                    'id',
                    'email',
                    'phone',
                ],
            });

            if (!user) {
                throw new HttpException(
                    'Utilisateur non trouvé.',
                    HttpStatus.NOT_FOUND,
                );
            }

            let destination: string | null = null;

            if (user.email) {
                destination = user.email;
            } else if (user.phone) {
                destination = user.phone;
            }

            if (!destination) {
                throw new HttpException(
                    'Aucun email ou téléphone trouvé pour cet utilisateur.',
                    HttpStatus.BAD_REQUEST,
                );
            }

            const otpCode =
                dto.otpCode!.trim();

            const otpEntry =
                await this.otpRepository.findOne({
                    where: {
                        email: destination,
                        otpCode,
                        isUsed: false,
                    },
                    relations: ['user'],
                });

            if (!otpEntry) {
                const existingOtp =
                    await this.otpRepository.findOne({
                        where: {
                            email: destination,
                            otpCode,
                        },
                    });

                if (existingOtp?.isUsed) {
                    throw new HttpException(
                        {
                            statusCode:
                                HttpStatus.BAD_REQUEST,
                            message:
                                'Ce code OTP a déjà été utilisé.',
                            code: 'OTP_ALREADY_USED',
                            canResend: true,
                        },
                        HttpStatus.BAD_REQUEST,
                    );
                }

                if (
                    existingOtp &&
                    new Date() > existingOtp.expiresAt
                ) {
                    throw new HttpException(
                        {
                            statusCode:
                                HttpStatus.BAD_REQUEST,
                            message:
                                'Ce code OTP a expiré.',
                            code: 'OTP_EXPIRED',
                            canResend: true,
                        },
                        HttpStatus.BAD_REQUEST,
                    );
                }

                throw new HttpException(
                    {
                        statusCode:
                            HttpStatus.BAD_REQUEST,
                        message:
                            'Code OTP invalide.',
                        code: 'INVALID_OTP',
                        canResend: true,
                    },
                    HttpStatus.BAD_REQUEST,
                );
            }

            // Vérification expiration
            if (
                new Date() >
                otpEntry.expiresAt
            ) {
                otpEntry.isUsed = true;

                await this.otpRepository.save(
                    otpEntry,
                );

                throw new HttpException(
                    {
                        statusCode:
                            HttpStatus.BAD_REQUEST,
                        message:
                            'Code OTP expiré.',
                        code: 'OTP_EXPIRED',
                        canResend: true,
                    },
                    HttpStatus.BAD_REQUEST,
                );
            }

            // OTP valide
            otpEntry.isUsed = true;

            await this.otpRepository.save(
                otpEntry,
            );

            this.logger.log(
                `✅ OTP vérifié avec succès pour l'utilisateur ${user.id}`,
            );

            // ============================================================
            // ÉTAPE 3 : DÉDUIRE DIRECTEMENT LA BALANCE
            // ============================================================

            const deductedReferrals: Array<{
                id: string;
                amount: number;
                balanceBefore: number;
                balanceAfter: number;
            }> = [];

            let totalDeducted = 0;

            try {
                this.logger.log(
                    `💰 Recherche du solde de parrainage en ${currency}`,
                );

                const userWithReferrals =
                    await this.userRepository.findOne({
                        where: {
                            id: user.id,  // ✅ Utiliser l'ID système
                        },
                        relations: [
                            'referralHistory',
                        ],
                    });

                if (!userWithReferrals) {
                    throw new HttpException(
                        'Utilisateur non trouvé.',
                        HttpStatus.NOT_FOUND,
                    );
                }

                // ✅ LOG POUR VOIR CE QUI EST RÉCUPÉRÉ
                this.logger.log(`📊 referralHistory trouvé: ${userWithReferrals?.referralHistory?.length || 0} entrées`);
                userWithReferrals?.referralHistory?.forEach(r => {
                    this.logger.log(`  - ${r.id.substring(0, 8)}...: ${r.rewardAmount} ${r.currency} (referrerId: ${r.referrerId})`);
                });

                // ========================================================
                // ✅ RÉCUPÉRER UNIQUEMENT LES BALANCES DU USER ET DE LA DEVISE
                // ========================================================

                const referralsInCurrency =
                    (
                        userWithReferrals.referralHistory ||
                        []
                    )
                        .filter(
                            (referral) =>
                                referral.referrerId === user.id &&  // ✅ Vérifier que c'est bien le parrain
                                String(
                                    referral.currency,
                                ).toUpperCase() ===
                                currency &&
                                Number(
                                    referral.rewardAmount,
                                ) > 0,
                        )
                        .sort(
                            (a, b) =>
                                (
                                    a.createdAt?.getTime() ||
                                    0
                                ) -
                                (
                                    b.createdAt?.getTime() ||
                                    0
                                ),
                        );

                // ========================================================
                // BALANCE TOTALE
                // ========================================================

                const availableBalance =
                    referralsInCurrency.reduce(
                        (
                            total,
                            referral,
                        ) =>
                            total +
                            Number(
                                referral.rewardAmount ||
                                0,
                            ),
                        0,
                    );

                this.logger.log(
                    `💰 Balance disponible: ${availableBalance} ${currency}`,
                );

                this.logger.log(
                    `💸 Montant demandé: ${amount} ${currency}`,
                );

                // ========================================================
                // VÉRIFICATION DU SOLDE
                // ========================================================

                if (
                    availableBalance <
                    amount
                ) {
                    throw new HttpException(
                        {
                            statusCode:
                                HttpStatus.BAD_REQUEST,

                            message:
                                `Solde de parrainage insuffisant. Votre balance est de ${availableBalance} ${currency}, mais vous demandez ${amount} ${currency}.`,

                            code:
                                'INSUFFICIENT_REFERRAL_BALANCE',

                            available:
                                availableBalance,

                            requested:
                                amount,

                            currency,
                        },
                        HttpStatus.BAD_REQUEST,
                    );
                }

                // ========================================================
                // DÉDUCTION DIRECTE
                // ========================================================

                let remainingAmount =
                    amount;

                for (
                    const referral
                    of referralsInCurrency
                ) {
                    if (
                        remainingAmount <=
                        0
                    ) {
                        break;
                    }

                    const balanceBefore =
                        Number(
                            referral.rewardAmount ||
                            0,
                        );

                    if (
                        balanceBefore <=
                        0
                    ) {
                        continue;
                    }

                    const amountToDeduct =
                        Math.min(
                            balanceBefore,
                            remainingAmount,
                        );

                    const balanceAfter =
                        Number(
                            (
                                balanceBefore -
                                amountToDeduct
                            ).toFixed(2),
                        );

                    // ====================================================
                    // ⭐ BALANCE DIMINUÉE DIRECTEMENT
                    // ====================================================

                    referral.rewardAmount =
                        balanceAfter;

                    // ====================================================
                    // HISTORIQUE
                    // ====================================================

                    const existingMetadata =
                        referral.metadata &&
                            typeof referral.metadata ===
                            'object'
                            ? referral.metadata
                            : {};

                    const history =
                        Array.isArray(
                            existingMetadata.history,
                        )
                            ? existingMetadata.history
                            : [];

                    const operation = {
                        type: 'WITHDRAWAL',

                        amount:
                            amountToDeduct,

                        currency,

                        balanceBefore,

                        balanceAfter,

                        reason:
                            'REFERRAL_DEPOSIT_REQUEST',

                        userId:
                            user.id,

                        fpayUserId:
                            dto.userId,

                        createdAt:
                            new Date().toISOString(),
                    };

                    referral.metadata = {
                        ...existingMetadata,

                        history: [
                            ...history,
                            operation,
                        ],

                        lastOperation:
                            operation,
                    };

                    // ====================================================
                    // SAUVEGARDER LA NOUVELLE BALANCE
                    // ====================================================

                    await this.referralRepository.save(
                        referral,
                    );

                    // ====================================================
                    // MÉMORISER POUR UN ÉVENTUEL REMBOURSEMENT
                    // ====================================================

                    deductedReferrals.push({
                        id:
                            referral.id,

                        amount:
                            amountToDeduct,

                        balanceBefore,

                        balanceAfter,
                    });

                    remainingAmount =
                        Number(
                            (
                                remainingAmount -
                                amountToDeduct
                            ).toFixed(2),
                        );

                    totalDeducted =
                        Number(
                            (
                                totalDeducted +
                                amountToDeduct
                            ).toFixed(2),
                        );

                    this.logger.log(
                        `💰 Balance ${referral.id.substring(
                            0,
                            8,
                        )}... : ${balanceBefore} → ${balanceAfter} ${currency}`,
                    );
                }

                // ========================================================
                // SÉCURITÉ
                // ========================================================

                if (
                    remainingAmount >
                    0.001
                ) {
                    throw new HttpException(
                        {
                            statusCode:
                                HttpStatus.INTERNAL_SERVER_ERROR,

                            message:
                                'La déduction de la balance de parrainage n’a pas pu être complétée.',

                            code:
                                'REFERRAL_BALANCE_DEDUCTION_FAILED',

                            remaining:
                                remainingAmount,
                        },
                        HttpStatus.INTERNAL_SERVER_ERROR,
                    );
                }

                // ========================================================
                // RECALCULER referralPoints
                // ========================================================

                const totalAllCurrencies =
                    (
                        userWithReferrals.referralHistory ||
                        []
                    ).reduce(
                        (
                            total,
                            referral,
                        ) =>
                            total +
                            Number(
                                referral.rewardAmount ||
                                0,
                            ),
                        0,
                    );

                userWithReferrals.referralPoints =
                    Number(
                        totalAllCurrencies.toFixed(
                            2,
                        ),
                    );

                await this.userRepository.save(
                    userWithReferrals,
                );

                this.logger.log(
                    `✅ Balance diminuée automatiquement de ${totalDeducted} ${currency}`,
                );

                this.logger.log(
                    `💰 Nouvelle balance totale: ${totalAllCurrencies}`,
                );
            } catch (error: any) {
                if (
                    error instanceof
                    HttpException
                ) {
                    throw error;
                }

                this.logger.error(
                    `❌ Erreur déduction balance: ${error.message}`,
                );

                throw new HttpException(
                    {
                        statusCode:
                            HttpStatus.INTERNAL_SERVER_ERROR,

                        message:
                            'Erreur lors de la mise à jour de la balance de parrainage.',

                        code:
                            'REFERRAL_BALANCE_ERROR',
                    },
                    HttpStatus.INTERNAL_SERVER_ERROR,
                );
            }

            // ============================================================
            // ÉTAPE 4 : APPEL FPAY AVEC userIdFpay
            // ============================================================

            const url =
                `${this.fpayApiUrl}/wallet/deposit/request`;

            const payload = {
                userId: dto.userId,  // ✅ userIdFpay pour l'API FPay
                amount,
                currency,
                apiKey: this.parrainageApiKey,
            };

            const headers = {
                'Content-Type':
                    'application/json',

                Accept:
                    'application/json',
            };

            let response: any;

            try {
                this.logger.log(
                    `📤 Appel FPay avec userIdFpay: ${dto.userId}`,
                );
                this.logger.log(
                    `📤 Payload: ${JSON.stringify(payload)}`,
                );

                response =
                    await firstValueFrom(
                        this.httpService.post(
                            url,
                            payload,
                            {
                                headers,
                            },
                        ),
                    );

                const reference =
                    response?.data?.data
                        ?.transaction
                        ?.reference;

                this.logger.log(
                    `✅ Dépôt FPay enregistré: ${reference || 'OK'
                    }`,
                );
            } catch (error: any) {
                this.logger.error(
                    `❌ Erreur FPay: ${error.message}`,
                );

                if (error.response) {
                    this.logger.error(
                        `📦 Réponse FPay: ${JSON.stringify(
                            error.response.data,
                        )}`,
                    );
                }

                // ========================================================
                // REMBOURSEMENT AUTOMATIQUE
                // ========================================================

                if (
                    deductedReferrals.length >
                    0
                ) {
                    this.logger.warn(
                        `🔄 FPay a échoué. Remboursement de ${totalDeducted} ${currency}`,
                    );

                    try {
                        const userForRefund =
                            await this.userRepository.findOne(
                                {
                                    where: {
                                        id: user.id,
                                    },
                                    relations: [
                                        'referralHistory',
                                    ],
                                },
                            );

                        if (!userForRefund) {
                            throw new Error(
                                'Utilisateur introuvable pour remboursement.',
                            );
                        }

                        for (
                            const deducted
                            of deductedReferrals
                        ) {
                            const referral =
                                (
                                    userForRefund.referralHistory ||
                                    []
                                ).find(
                                    (item) =>
                                        item.id ===
                                        deducted.id,
                                );

                            if (!referral) {
                                this.logger.error(
                                    `❌ Referral ${deducted.id} introuvable.`,
                                );

                                continue;
                            }

                            const currentBalance =
                                Number(
                                    referral.rewardAmount ||
                                    0,
                                );

                            const newBalance =
                                Number(
                                    (
                                        currentBalance +
                                        deducted.amount
                                    ).toFixed(2),
                                );

                            // ============================================
                            // RESTAURATION DE LA BALANCE
                            // ============================================

                            referral.rewardAmount =
                                newBalance;

                            // ============================================
                            // HISTORIQUE REFUND
                            // ============================================

                            const existingMetadata =
                                referral.metadata &&
                                    typeof referral.metadata ===
                                    'object'
                                    ? referral.metadata
                                    : {};

                            const history =
                                Array.isArray(
                                    existingMetadata.history,
                                )
                                    ? existingMetadata.history
                                    : [];

                            const refundOperation = {
                                type: 'REFUND',

                                amount:
                                    deducted.amount,

                                currency,

                                balanceBefore:
                                    currentBalance,

                                balanceAfter:
                                    newBalance,

                                reason:
                                    'FPAY_DEPOSIT_REQUEST_FAILED',

                                userId:
                                    user.id,

                                fpayUserId:
                                    dto.userId,

                                createdAt:
                                    new Date().toISOString(),
                            };

                            referral.metadata = {
                                ...existingMetadata,

                                history: [
                                    ...history,
                                    refundOperation,
                                ],

                                lastOperation:
                                    refundOperation,
                            };

                            await this.referralRepository.save(
                                referral,
                            );

                            this.logger.log(
                                `✅ Balance restaurée: ${currentBalance} → ${newBalance} ${currency}`,
                            );
                        }

                        // ================================================
                        // RECALCUL TOTAL
                        // ================================================

                        const newTotal =
                            (
                                userForRefund.referralHistory ||
                                []
                            ).reduce(
                                (
                                    total,
                                    referral,
                                ) =>
                                    total +
                                    Number(
                                        referral.rewardAmount ||
                                        0,
                                    ),
                                0,
                            );

                        userForRefund.referralPoints =
                            Number(
                                newTotal.toFixed(
                                    2,
                                ),
                            );

                        await this.userRepository.save(
                            userForRefund,
                        );

                        this.logger.log(
                            `💰 Balance totale après remboursement: ${newTotal}`,
                        );
                    } catch (refundError: any) {
                        this.logger.error(
                            `❌ ERREUR CRITIQUE REMBOURSEMENT: ${refundError.message}`,
                        );
                    }
                }

                // ========================================================
                // ERREUR FPAY
                // ========================================================

                if (error.response) {
                    const errorResponse =
                        error.response.data;

                    const statusCode =
                        error.response.status ||
                        HttpStatus.INTERNAL_SERVER_ERROR;

                    const errorMessage =
                        errorResponse?.message ||
                        errorResponse?.error ||
                        'Erreur lors de la demande de dépôt';

                    throw new HttpException(
                        {
                            statusCode,

                            message:
                                errorMessage,

                            fpayError:
                                errorResponse,
                        },
                        statusCode,
                    );
                }

                throw new HttpException(
                    {
                        statusCode:
                            HttpStatus.INTERNAL_SERVER_ERROR,

                        message:
                            'Erreur lors de la demande de dépôt FPay.',

                        code:
                            'FPAY_SERVICE_ERROR',
                    },
                    HttpStatus.INTERNAL_SERVER_ERROR,
                );
            }

            // ============================================================
            // SUCCÈS
            // ============================================================

            const transaction =
                response?.data?.data
                    ?.transaction;

            return {
                status: 'success',

                message:
                    `Demande de dépôt de ${amount} ${currency} enregistrée avec succès. Référence: ${transaction?.reference ||
                    'N/A'
                    }`,

                data:
                    response?.data?.data,

                requiresOtp:
                    false,
            };
        } catch (error: any) {
            this.logger.error(
                `❌ Erreur demande de dépôt: ${error.message}`,
            );

            if (error.response) {
                this.logger.error(
                    `📦 Réponse erreur: ${JSON.stringify(
                        error.response.data,
                    )}`,
                );
            }

            throw this.handleError(error);
        }
    }

    private handleError(error: any): HttpException {
        // ✅ Si l'erreur est déjà une HttpException, on la retourne
        if (error instanceof HttpException) {
            return error;
        }

        // ✅ Si c'est une erreur avec réponse HTTP (API FPay)
        if (error.response) {
            const status = error.response.status || HttpStatus.INTERNAL_SERVER_ERROR;
            const errorData = error.response.data;

            // ✅ Extraire le message de l'API FPay
            let message = errorData?.message || errorData?.error || 'FPAY API error';

            // ✅ Si l'API FPay retourne une structure avec data.message
            if (errorData?.data?.message) {
                message = errorData.data.message;
            }

            // ✅ Si l'API FPay retourne une structure avec message
            if (errorData?.message) {
                message = errorData.message;
            }

            this.logger.error(`❌ FPAY API Error: ${status} - ${message}`);

            // ✅ Retourner l'erreur avec le message original de l'API
            return new HttpException(
                {
                    statusCode: status,
                    message: message,  // ✅ Message original de l'API
                    error: errorData,
                    timestamp: new Date().toISOString(),
                },
                status,
            );
        }

        // ✅ Si c'est une erreur avec un message personnalisé
        if (error.message) {
            if (error.code === 'INVALID_OTP' || error.message.includes('OTP')) {
                return new HttpException(
                    {
                        statusCode: HttpStatus.BAD_REQUEST,
                        message: error.message,
                        code: error.code || 'INVALID_OTP',
                        canResend: true,
                        timestamp: new Date().toISOString(),
                    },
                    HttpStatus.BAD_REQUEST,
                );
            }

            return new HttpException(
                {
                    statusCode: HttpStatus.BAD_REQUEST,
                    message: error.message,
                    timestamp: new Date().toISOString(),
                },
                HttpStatus.BAD_REQUEST,
            );
        }

        // ✅ Service indisponible
        if (error.request) {
            this.logger.error('❌ Service FPay indisponible');
            return new HttpException(
                {
                    statusCode: HttpStatus.SERVICE_UNAVAILABLE,
                    message: 'Service FPay indisponible',
                    timestamp: new Date().toISOString(),
                },
                HttpStatus.SERVICE_UNAVAILABLE,
            );
        }

        // ✅ Erreur interne par défaut
        return new HttpException(
            {
                statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                message: error.message || 'Erreur interne',
                timestamp: new Date().toISOString(),
            },
            HttpStatus.INTERNAL_SERVER_ERROR,
        );
    }
}