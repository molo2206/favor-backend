export class CreateCompanyHasResourceDto {}
