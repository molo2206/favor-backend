export class CreateOtpDto {
    
}
